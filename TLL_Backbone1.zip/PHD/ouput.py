import torch
import traceback

print("=" * 80)
print("MEMBER-D MODULE MANUAL TEST")
print("=" * 80)

# -------------------------------------------------------
# 1. Test LLM Backbone
# -------------------------------------------------------
try:
    print("\n[1] Testing LLM Backbone...")

    from llm_module.backbone.llm_backbone import LLMBackbone

    backbone = LLMBackbone(
        model_name="TinyLlama/TinyLlama-1.1B-Chat-v1.0"
    )

    print("✅ Backbone Loaded")
    print(backbone)

except Exception as e:
    print("❌ Backbone Failed")
    traceback.print_exc()


# -------------------------------------------------------
# 2. Test MultiModal Understanding
# -------------------------------------------------------
try:
    print("\n[2] Testing MultiModalUnderstanding...")

    from llm_module.understanding.multimodal_understanding import (
        MultiModalUnderstanding
    )

    understanding = MultiModalUnderstanding(
        d_model=64,
        num_heads=8,
        d_ff=128,
        num_layers=2
    )

    hidden_states = torch.randn(2,10,64)

    output = understanding(hidden_states)

    print("✅ Understanding Output Shape:")
    print(output.shape)

    print(output)

except Exception as e:
    print("❌ MultiModalUnderstanding Failed")
    traceback.print_exc()


# -------------------------------------------------------
# 3. Test Expert Router
# -------------------------------------------------------
try:
    print("\n[3] Testing ExpertRouter...")

    from llm_module.routing.expert_router import ExpertRouter

    router = ExpertRouter(
        d_hidden=64,
        num_experts=4,
        top_k=2
    )

    x = torch.randn(2,64)

    output = router(x)

    print("✅ Router Output")

    print(output)

except Exception as e:
    print("❌ ExpertRouter Failed")
    traceback.print_exc()


# -------------------------------------------------------
# 4. Test MemberDModule
# -------------------------------------------------------
try:
    print("\n[4] Testing MemberDModule...")

    from llm_module.member_d_module import MemberDModule

    model = MemberDModule(
        model_name="TinyLlama/TinyLlama-1.1B-Chat-v1.0"
    )

    print("✅ MemberDModule Loaded")

except Exception as e:
    print("❌ MemberDModule Failed")
    traceback.print_exc()


# -------------------------------------------------------
# 5. Parameter Count
# -------------------------------------------------------
try:
    print("\n[5] Parameter Count...")

    total = sum(
        p.numel()
        for p in model.parameters()
    )

    trainable = sum(
        p.numel()
        for p in model.parameters()
        if p.requires_grad
    )

    print("Total Parameters :", total)
    print("Trainable Parameters :", trainable)

except Exception as e:
    print("❌ Parameter Count Failed")
    traceback.print_exc()


# -------------------------------------------------------
# 6. CUDA Check
# -------------------------------------------------------
print("\n[6] CUDA CHECK")

print("CUDA Available :", torch.cuda.is_available())

if torch.cuda.is_available():
    print("GPU :", torch.cuda.get_device_name(0))
    print("CUDA Version :", torch.version.cuda)
else:
    print("Running on CPU")


# -------------------------------------------------------
# 7. Forward Pass (Dummy Input)
# -------------------------------------------------------
try:
    print("\n[7] Forward Pass Test")

    hidden = torch.randn(1,20,4096)

    mask = torch.ones(1,20)

    if hasattr(model, "forward"):
        print("Forward function exists ✅")
    else:
        print("Forward function not found ❌")

except Exception as e:
    print("❌ Forward Test Failed")
    traceback.print_exc()


print("\n")
print("=" * 80)
print("MANUAL TEST COMPLETED")
print("=" * 80)