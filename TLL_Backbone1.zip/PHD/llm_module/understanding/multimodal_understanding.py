"""
multimodal_understanding.py

Multi-modal Feature Understanding block for RF-AI2MMUM — Member D.

Implements `MultiModalUnderstanding`, a transformer encoder block that
refines the LLM backbone's hidden states (derived from `z_fused` +
`task_instruction_ids`) into a single pooled multi-modal representation
suitable for the context-aware dynamic expert router.

Architecture:
  - Multi-Head Self-Attention (with residual connection + LayerNorm)
  - Position-wise FeedForward network (with residual connection + LayerNorm)
  - Mean-pooling over the sequence dimension to produce a fixed-size
    representation for routing.

Author: Member D — LLM Backbone & Multi-modal Understanding Engineer
"""

from __future__ import annotations

import logging
import math
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)


class MultiModalUnderstandingError(Exception):
    """Raised on invalid configuration or forward-pass errors."""


class MultiHeadAttention(nn.Module):
    """
    Standard scaled dot-product multi-head self-attention.

    Parameters
    ----------
    d_model : int
        Model (hidden) dimensionality.
    num_heads : int
        Number of attention heads. Must evenly divide `d_model`.
    dropout : float, default 0.1
        Dropout applied to attention weights.

    Raises
    ------
    MultiModalUnderstandingError
        If `d_model` is not divisible by `num_heads`.
    """

    def __init__(self, d_model: int, num_heads: int, dropout: float = 0.1) -> None:
        super().__init__()
        if d_model % num_heads != 0:
            raise MultiModalUnderstandingError(
                f"d_model ({d_model}) must be divisible by num_heads ({num_heads})."
            )

        self.d_model = d_model
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads

        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.out_proj = nn.Linear(d_model, d_model)

        self.dropout = nn.Dropout(dropout)
        self.scale = math.sqrt(self.head_dim)

    def forward(
        self, x: torch.Tensor, attention_mask: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        Apply multi-head self-attention.

        Parameters
        ----------
        x : torch.Tensor
            Input tensor of shape (B, L, d_model).
        attention_mask : Optional[torch.Tensor]
            Optional mask of shape (B, L) where 1 indicates a valid token
            and 0 indicates padding. Padding positions are excluded from
            attention.

        Returns
        -------
        torch.Tensor
            Output tensor of shape (B, L, d_model).
        """
        batch_size, seq_len, _ = x.shape

        q = self.q_proj(x).view(batch_size, seq_len, self.num_heads, self.head_dim)
        k = self.k_proj(x).view(batch_size, seq_len, self.num_heads, self.head_dim)
        v = self.v_proj(x).view(batch_size, seq_len, self.num_heads, self.head_dim)

        q = q.transpose(1, 2)  # (B, H, L, Dh)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)

        scores = torch.matmul(q, k.transpose(-2, -1)) / self.scale  # (B, H, L, L)

        if attention_mask is not None:
            # (B, L) -> (B, 1, 1, L) so it broadcasts over heads and queries
            mask = attention_mask[:, None, None, :].to(device=scores.device, dtype=torch.bool)
            scores = scores.masked_fill(~mask, float("-inf"))

        attn_weights = F.softmax(scores, dim=-1)
        attn_weights = torch.nan_to_num(attn_weights, nan=0.0)  # guard against all-masked rows
        attn_weights = self.dropout(attn_weights)

        context = torch.matmul(attn_weights, v)  # (B, H, L, Dh)
        context = context.transpose(1, 2).contiguous().view(batch_size, seq_len, self.d_model)

        return self.out_proj(context)


class FeedForward(nn.Module):
    """
    Position-wise feed-forward network with GELU activation.

    Parameters
    ----------
    d_model : int
        Input/output dimensionality.
    d_ff : int
        Hidden dimensionality of the feed-forward layer.
    dropout : float, default 0.1
        Dropout probability applied after the activation and after the
        second linear layer.
    """

    def __init__(self, d_model: int, d_ff: int, dropout: float = 0.1) -> None:
        super().__init__()
        self.linear1 = nn.Linear(d_model, d_ff)
        self.linear2 = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = nn.GELU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Apply the feed-forward transformation to `x` of shape (B, L, d_model)."""
        x = self.dropout(self.activation(self.linear1(x)))
        return self.linear2(x)


class TransformerEncoderBlock(nn.Module):
    """
    A single pre-norm transformer encoder block.

    Consists of: LayerNorm -> MultiHeadAttention -> residual,
    followed by LayerNorm -> FeedForward -> residual.

    Parameters
    ----------
    d_model : int
        Model dimensionality.
    num_heads : int
        Number of attention heads.
    d_ff : int
        Feed-forward hidden dimensionality.
    dropout : float, default 0.1
        Dropout probability used throughout the block.
    """

    def __init__(self, d_model: int, num_heads: int, d_ff: int, dropout: float = 0.1) -> None:
        super().__init__()
        self.norm1 = nn.LayerNorm(d_model)
        self.attention = MultiHeadAttention(d_model, num_heads, dropout)
        self.dropout1 = nn.Dropout(dropout)

        self.norm2 = nn.LayerNorm(d_model)
        self.feed_forward = FeedForward(d_model, d_ff, dropout)
        self.dropout2 = nn.Dropout(dropout)

    def forward(
        self, x: torch.Tensor, attention_mask: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        Apply the transformer encoder block to `x`.

        Parameters
        ----------
        x : torch.Tensor
            Input tensor of shape (B, L, d_model).
        attention_mask : Optional[torch.Tensor]
            Optional padding mask of shape (B, L).

        Returns
        -------
        torch.Tensor
            Output tensor of shape (B, L, d_model).
        """
        # Self-attention sub-layer with pre-norm and residual connection
        residual = x
        x_norm = self.norm1(x)
        attn_out = self.attention(x_norm, attention_mask)
        x = residual + self.dropout1(attn_out)

        # Feed-forward sub-layer with pre-norm and residual connection
        residual = x
        x_norm = self.norm2(x)
        ff_out = self.feed_forward(x_norm)
        x = residual + self.dropout2(ff_out)

        return x


class MultiModalUnderstanding(nn.Module):
    """
    Multi-modal Feature Understanding module.

    Stacks `num_layers` `TransformerEncoderBlock`s on top of the LLM
    backbone's hidden states, then mean-pools over the sequence dimension
    (respecting padding via `attention_mask`) to produce a single fused
    representation `z_understood` of shape (B, d_model), ready for the
    expert router.

    Parameters
    ----------
    d_model : int, default 4096
        Hidden dimensionality, matching the LLM backbone's hidden size
        (and `z_fused`'s feature dimension).
    num_heads : int, default 8
        Number of self-attention heads per encoder block.
    d_ff : int, default 8192
        Feed-forward hidden dimensionality per encoder block.
    num_layers : int, default 2
        Number of stacked transformer encoder blocks.
    dropout : float, default 0.1
        Dropout probability used throughout the module.

    Raises
    ------
    MultiModalUnderstandingError
        If `num_layers` is non-positive or other configuration values are
        invalid.
    """

    def __init__(
        self,
        d_model: int = 4096,
        num_heads: int = 8,
        d_ff: int = 8192,
        num_layers: int = 2,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()

        if num_layers <= 0:
            raise MultiModalUnderstandingError(
                f"num_layers must be positive, got {num_layers}."
            )
        if d_model <= 0 or num_heads <= 0 or d_ff <= 0:
            raise MultiModalUnderstandingError(
                "d_model, num_heads, and d_ff must all be positive integers."
            )

        self.d_model = d_model

        self.layers = nn.ModuleList(
            [
                TransformerEncoderBlock(d_model, num_heads, d_ff, dropout)
                for _ in range(num_layers)
            ]
        )
        self.final_norm = nn.LayerNorm(d_model)

        logger.info(
            "MultiModalUnderstanding initialized: d_model=%d, num_heads=%d, "
            "d_ff=%d, num_layers=%d, dropout=%.3f",
            d_model,
            num_heads,
            d_ff,
            num_layers,
            dropout,
        )

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Run the multi-modal understanding stack and pool to a fixed vector.

        Parameters
        ----------
        hidden_states : torch.Tensor
            Hidden states from the LLM backbone of shape (B, L, d_model).
        attention_mask : Optional[torch.Tensor]
            Optional mask of shape (B, L) where 1 = valid token, 0 = padding.
            Used both inside self-attention and for masked mean pooling.

        Returns
        -------
        torch.Tensor
            Pooled multi-modal representation `z_understood` of shape
            (B, d_model).

        Raises
        ------
        MultiModalUnderstandingError
            If `hidden_states` does not have shape (B, L, d_model) matching
            the configured `d_model`.
        """
        if hidden_states.dim() != 3:
            raise MultiModalUnderstandingError(
                "hidden_states must have shape (B, L, d_model), got shape "
                f"{tuple(hidden_states.shape)}."
            )

        if hidden_states.size(-1) != self.d_model:
            raise MultiModalUnderstandingError(
                f"Last dimension of hidden_states ({hidden_states.size(-1)}) "
                f"does not match configured d_model ({self.d_model})."
            )

        x = hidden_states
        for layer in self.layers:
            x = layer(x, attention_mask)

        x = self.final_norm(x)

        # Masked mean pooling over the sequence dimension
        if attention_mask is not None:
            mask = attention_mask.unsqueeze(-1).to(device=x.device, dtype=x.dtype)  # (B, L, 1)
            summed = (x * mask).sum(dim=1)  # (B, d_model)
            counts = mask.sum(dim=1).clamp(min=1.0)  # (B, 1)
            pooled = summed / counts
        else:
            pooled = x.mean(dim=1)

        return pooled