"""
task_tokenizer.py
=================
RF-AI2MMUM Language Processing Module — Member B

Implements a BERT-based tokenizer extended with telecom-domain vocabulary
for the RF-AI2MMUM unified multi-modal framework. Supports:
  - Telecom-domain vocabulary extension via new token injection
  - Special task-conditioning tokens (e.g., [TASK], [RF], [CHANNEL], etc.)
  - Whole-word masking data collation for MLM training
  - Batch tokenization with configurable padding and truncation
  - Save / load from disk for reproducibility

Usage:
    from language_module.task_tokenizer import TelecomTaskTokenizer

    tokenizer = TelecomTaskTokenizer.from_pretrained(
        base_model="bert-base-uncased",
        telecom_vocab_path="data/telecom_corpus/telecom_vocab.txt"
    )

    encoding = tokenizer.encode_task(
        "Optimize OFDM subcarrier spacing for mmWave 5G NR beamforming"
    )
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import torch
from transformers import BertTokenizer, BertTokenizerFast
from transformers import DataCollatorForLanguageModeling, DataCollatorForWholeWordMask

logger = logging.getLogger(__name__)


# ─── Constants ────────────────────────────────────────────────────────────────

SPECIAL_TOKENS: Dict[str, str] = {
    "task_start":  "[TASK]",
    "task_end":    "[/TASK]",
    "rf_signal":   "[RF]",
    "channel":     "[CHANNEL]",
    "modulation":  "[MOD]",
    "frequency":   "[FREQ]",
    "antenna":     "[ANT]",
    "beamform":    "[BEAM]",
}

DEFAULT_MAX_LENGTH: int = 512


# ─── TelecomTaskTokenizer ─────────────────────────────────────────────────────

class TelecomTaskTokenizer:
    """
    BERT-based tokenizer extended with telecom-domain vocabulary.

    Wraps HuggingFace's BertTokenizerFast and injects domain-specific
    tokens (from a vocabulary file) and custom special tokens for RF
    task conditioning.

    Attributes:
        tokenizer (BertTokenizerFast): The underlying HuggingFace tokenizer.
        max_length (int): Maximum token sequence length.
        num_added_tokens (int): Number of new tokens added to the vocabulary.
    """

    def __init__(
        self,
        tokenizer: BertTokenizerFast,
        max_length: int = DEFAULT_MAX_LENGTH,
    ) -> None:
        """
        Initialise TelecomTaskTokenizer (prefer using `from_pretrained`).

        Args:
            tokenizer: Pre-constructed BertTokenizerFast instance.
            max_length: Maximum tokenized sequence length.
        """
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.num_added_tokens: int = 0
        logger.debug(
            "TelecomTaskTokenizer initialized | vocab_size=%d | max_length=%d",
            self.vocab_size,
            self.max_length,
        )

    # ── Factory Methods ────────────────────────────────────────────────────

    @classmethod
    def from_pretrained(
        cls,
        base_model: str = "bert-base-uncased",
        telecom_vocab_path: Optional[Union[str, Path]] = None,
        max_length: int = DEFAULT_MAX_LENGTH,
        do_lower_case: bool = True,
    ) -> "TelecomTaskTokenizer":
        """
        Create a TelecomTaskTokenizer from a pretrained BERT tokenizer.

        Downloads (or loads from cache) the base BERT tokenizer, then injects
        telecom-domain vocabulary tokens and task-conditioning special tokens.

        Args:
            base_model: HuggingFace model ID or local path.
            telecom_vocab_path: Path to the telecom vocabulary .txt file.
                Each non-empty, non-comment line is added as a new token.
            max_length: Maximum tokenized sequence length.
            do_lower_case: Whether to lowercase input text.

        Returns:
            Initialized TelecomTaskTokenizer instance.
        """
        logger.info("Loading base tokenizer: %s", base_model)
        tokenizer = BertTokenizerFast.from_pretrained(
            base_model,
            do_lower_case=do_lower_case,
        )

        instance = cls(tokenizer=tokenizer, max_length=max_length)

        # Inject special task-conditioning tokens
        instance._add_special_tokens(list(SPECIAL_TOKENS.values()))

        # Inject telecom vocabulary tokens
        if telecom_vocab_path is not None:
            vocab_tokens = instance._load_vocab_file(Path(telecom_vocab_path))
            instance._add_vocab_tokens(vocab_tokens)

        logger.info(
            "TelecomTaskTokenizer ready | vocab_size=%d | added=%d",
            instance.vocab_size,
            instance.num_added_tokens,
        )
        return instance

    @classmethod
    def load(cls, save_directory: Union[str, Path]) -> "TelecomTaskTokenizer":
        """
        Load a previously saved TelecomTaskTokenizer from disk.

        Args:
            save_directory: Directory created by `save()`.

        Returns:
            Restored TelecomTaskTokenizer instance.
        """
        save_dir = Path(save_directory)
        logger.info("Loading TelecomTaskTokenizer from: %s", save_dir)

        tokenizer = BertTokenizerFast.from_pretrained(str(save_dir))

        # Load metadata
        meta_path = save_dir / "telecom_tokenizer_meta.json"
        max_length = DEFAULT_MAX_LENGTH
        num_added = 0
        if meta_path.exists():
            with open(meta_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
            max_length = meta.get("max_length", DEFAULT_MAX_LENGTH)
            num_added = meta.get("num_added_tokens", 0)

        instance = cls(tokenizer=tokenizer, max_length=max_length)
        instance.num_added_tokens = num_added
        logger.info("TelecomTaskTokenizer loaded | vocab_size=%d", instance.vocab_size)
        return instance

    # ── Encoding Methods ───────────────────────────────────────────────────

    def encode_task(
        self,
        task_description: str,
        add_special_tokens: bool = True,
        padding: Union[bool, str] = False,
        truncation: bool = True,
        return_tensors: Optional[str] = "pt",
    ) -> Dict[str, torch.Tensor]:
        """
        Tokenize a single RF task description string.

        Wraps the input with [TASK]...[/TASK] delimiters before tokenization
        to signal the model that this input is a task conditioning directive.

        Args:
            task_description: Free-text RF task specification.
            add_special_tokens: Whether to add [CLS] and [SEP].
            padding: Padding strategy ("max_length", True, False).
            truncation: Whether to truncate to max_length.
            return_tensors: Return format ("pt", "np", None).

        Returns:
            Dict with keys: input_ids, attention_mask, token_type_ids.
        """
        wrapped = f"{SPECIAL_TOKENS['task_start']} {task_description} {SPECIAL_TOKENS['task_end']}"
        encoding = self.tokenizer(
            wrapped,
            add_special_tokens=add_special_tokens,
            max_length=self.max_length,
            padding=padding,
            truncation=truncation,
            return_tensors=return_tensors,
        )
        return encoding

    def encode_batch(
        self,
        texts: List[str],
        padding: Union[bool, str] = True,
        truncation: bool = True,
        return_tensors: str = "pt",
        wrap_with_task_tokens: bool = False,
    ) -> Dict[str, torch.Tensor]:
        """
        Tokenize a batch of texts.

        Args:
            texts: List of input strings.
            padding: Padding strategy.
            truncation: Whether to truncate to max_length.
            return_tensors: Return format.
            wrap_with_task_tokens: If True, wrap each text with [TASK]...[/TASK].

        Returns:
            Dict with keys: input_ids, attention_mask, token_type_ids.
        """
        if wrap_with_task_tokens:
            texts = [
                f"{SPECIAL_TOKENS['task_start']} {t} {SPECIAL_TOKENS['task_end']}"
                for t in texts
            ]
        encoding = self.tokenizer(
            texts,
            add_special_tokens=True,
            max_length=self.max_length,
            padding=padding,
            truncation=truncation,
            return_tensors=return_tensors,
        )
        return encoding

    def decode(
        self,
        token_ids: Union[List[int], torch.Tensor],
        skip_special_tokens: bool = True,
    ) -> str:
        """
        Decode token IDs back to a string.

        Args:
            token_ids: Sequence of token IDs.
            skip_special_tokens: Whether to remove special tokens.

        Returns:
            Decoded string.
        """
        if isinstance(token_ids, torch.Tensor):
            token_ids = token_ids.tolist()
        return self.tokenizer.decode(token_ids, skip_special_tokens=skip_special_tokens)

    def tokenize(self, text: str) -> List[str]:
        """
        Return the list of token strings for input text (no IDs).

        Args:
            text: Input string.

        Returns:
            List of WordPiece tokens.
        """
        return self.tokenizer.tokenize(text)

    def get_mlm_data_collator(
        self,
        mlm_probability: float = 0.15,
        whole_word_masking: bool = False,
    ) -> DataCollatorForLanguageModeling:
        """
        Build a data collator for Masked Language Modeling training.

        Args:
            mlm_probability: Probability of masking each token.
            whole_word_masking: If True, use DataCollatorForWholeWordMask which
                requires batches to include ``offset_mapping`` (returned by the
                tokenizer when ``return_offsets_mapping=True``).  Defaults to
                False, which uses the simpler DataCollatorForLanguageModeling
                that works with plain ``input_ids`` lists.

        Returns:
            DataCollatorForLanguageModeling or DataCollatorForWholeWordMask
            instance, depending on *whole_word_masking*.
        """
        if whole_word_masking:
            return DataCollatorForWholeWordMask(
                tokenizer=self.tokenizer,
                mlm=True,
                mlm_probability=mlm_probability,
            )
        return DataCollatorForLanguageModeling(
            tokenizer=self.tokenizer,
            mlm=True,
            mlm_probability=mlm_probability,
        )

    # ── Vocabulary & Token Management ─────────────────────────────────────

    def get_special_token_ids(self) -> Dict[str, int]:
        """
        Return a mapping of special token names to their IDs.

        Returns:
            Dict[str, int] — e.g., {"task_start": 30522, ...}
        """
        result: Dict[str, int] = {}
        for name, token in SPECIAL_TOKENS.items():
            tid = self.tokenizer.convert_tokens_to_ids(token)
            if tid != self.tokenizer.unk_token_id:
                result[name] = tid
        return result

    def is_telecom_token(self, token: str) -> bool:
        """
        Check if a token string is part of the telecom extension vocabulary.

        Args:
            token: Token string to check.

        Returns:
            True if the token was added as a telecom domain token.
        """
        tid = self.tokenizer.convert_tokens_to_ids(token)
        original_vocab_size = self.vocab_size - self.num_added_tokens
        return tid >= original_vocab_size

    # ── Save / Load ────────────────────────────────────────────────────────

    def save(self, save_directory: Union[str, Path]) -> None:
        """
        Save the tokenizer and metadata to disk.

        Args:
            save_directory: Target directory path.
        """
        save_dir = Path(save_directory)
        save_dir.mkdir(parents=True, exist_ok=True)
        self.tokenizer.save_pretrained(str(save_dir))

        meta = {
            "max_length": self.max_length,
            "num_added_tokens": self.num_added_tokens,
            "special_tokens": SPECIAL_TOKENS,
            "vocab_size": self.vocab_size,
        }
        meta_path = save_dir / "telecom_tokenizer_meta.json"
        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2)

        logger.info("TelecomTaskTokenizer saved to: %s", save_dir)

    # ── Properties ────────────────────────────────────────────────────────

    @property
    def vocab_size(self) -> int:
        """Total vocabulary size (base + added tokens)."""
        return len(self.tokenizer)

    @property
    def pad_token_id(self) -> int:
        """ID of the [PAD] token."""
        return self.tokenizer.pad_token_id  # type: ignore[return-value]

    @property
    def mask_token_id(self) -> int:
        """ID of the [MASK] token."""
        return self.tokenizer.mask_token_id  # type: ignore[return-value]

    @property
    def cls_token_id(self) -> int:
        """ID of the [CLS] token."""
        return self.tokenizer.cls_token_id  # type: ignore[return-value]

    @property
    def sep_token_id(self) -> int:
        """ID of the [SEP] token."""
        return self.tokenizer.sep_token_id  # type: ignore[return-value]

    def __repr__(self) -> str:
        return (
            f"TelecomTaskTokenizer("
            f"vocab_size={self.vocab_size}, "
            f"max_length={self.max_length}, "
            f"num_added_tokens={self.num_added_tokens})"
        )

    def __len__(self) -> int:
        return self.vocab_size

    # ── Private Helpers ────────────────────────────────────────────────────

    def _add_special_tokens(self, special_token_list: List[str]) -> int:
        """
        Add custom special tokens to the tokenizer.

        Args:
            special_token_list: List of special token strings.

        Returns:
            Number of new tokens added.
        """
        existing = set(self.tokenizer.all_special_tokens)
        new_tokens = [t for t in special_token_list if t not in existing]
        if new_tokens:
            n_added = self.tokenizer.add_special_tokens(
                {"additional_special_tokens": new_tokens}
            )
            self.num_added_tokens += n_added
            logger.debug("Added %d special tokens: %s", n_added, new_tokens)
        return len(new_tokens)

    def _add_vocab_tokens(self, new_tokens: List[str]) -> int:
        """
        Add regular (non-special) vocabulary tokens.

        Args:
            new_tokens: List of new token strings.

        Returns:
            Number of new tokens actually added.
        """
        existing_vocab = set(self.tokenizer.get_vocab().keys())
        tokens_to_add = [t for t in new_tokens if t not in existing_vocab]
        if tokens_to_add:
            n_added = self.tokenizer.add_tokens(tokens_to_add)
            self.num_added_tokens += n_added
            logger.debug("Added %d telecom vocab tokens", n_added)
        return len(tokens_to_add)

    @staticmethod
    def _load_vocab_file(vocab_path: Path) -> List[str]:
        """
        Load vocabulary tokens from a .txt file.

        Lines starting with '#' and empty lines are skipped.

        Args:
            vocab_path: Path to the vocabulary file.

        Returns:
            List of token strings.
        """
        if not vocab_path.exists():
            logger.warning("Vocab file not found: %s — skipping extension", vocab_path)
            return []

        tokens: List[str] = []
        with open(vocab_path, "r", encoding="utf-8") as f:
            for line in f:
                token = line.strip()
                if token and not token.startswith("#") and not token.startswith("─"):
                    tokens.append(token)

        logger.info("Loaded %d tokens from vocab file: %s", len(tokens), vocab_path)
        return tokens
