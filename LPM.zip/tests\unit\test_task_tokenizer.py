"""
test_task_tokenizer.py
======================
RF-AI2MMUM Language Processing Module — Unit Tests
Member B: NLP Engineer & Language Module Developer

Unit tests for TelecomTaskTokenizer:
  - Vocabulary size after extension
  - Special token injection
  - Single task encoding
  - Batch encoding
  - Save / load round-trip
  - Telecom token detection
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import torch

# ── Path setup so tests run from any directory ────────────────────────────────
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from language_module.task_tokenizer import TelecomTaskTokenizer, SPECIAL_TOKENS


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def base_tokenizer() -> TelecomTaskTokenizer:
    """Load a base TelecomTaskTokenizer (no telecom vocab) once per test module."""
    return TelecomTaskTokenizer.from_pretrained(
        base_model="bert-base-uncased",
        telecom_vocab_path=None,
        max_length=128,
    )


@pytest.fixture(scope="module")
def extended_tokenizer(tmp_path_factory) -> TelecomTaskTokenizer:
    """Load a TelecomTaskTokenizer with a small telecom vocabulary."""
    vocab_dir = tmp_path_factory.mktemp("vocab")
    vocab_file = vocab_dir / "telecom_vocab.txt"
    vocab_file.write_text(
        "ofdm\nmimo\nbeamforming\n5gnr\nmmwave\nldpc\npolar-code\n",
        encoding="utf-8",
    )
    return TelecomTaskTokenizer.from_pretrained(
        base_model="bert-base-uncased",
        telecom_vocab_path=str(vocab_file),
        max_length=128,
    )


# ─── Tests: Initialization ───────────────────────────────────────────────────

class TestInitialization:
    def test_base_vocab_size_is_positive(self, base_tokenizer):
        """Vocabulary size must be positive after base model loading."""
        assert base_tokenizer.vocab_size > 0

    def test_special_tokens_added(self, base_tokenizer):
        """All RF task special tokens must be present in the vocabulary."""
        for name, token in SPECIAL_TOKENS.items():
            token_id = base_tokenizer.tokenizer.convert_tokens_to_ids(token)
            assert token_id != base_tokenizer.tokenizer.unk_token_id, (
                f"Special token '{token}' was not added to vocabulary"
            )

    def test_extended_vocab_larger_than_base(self, base_tokenizer, extended_tokenizer):
        """Extended tokenizer must have larger vocabulary than base."""
        assert extended_tokenizer.vocab_size > base_tokenizer.vocab_size

    def test_num_added_tokens_positive(self, extended_tokenizer):
        """num_added_tokens should be > 0 after vocabulary extension."""
        assert extended_tokenizer.num_added_tokens > 0

    def test_repr_string(self, base_tokenizer):
        """repr() must include key info."""
        r = repr(base_tokenizer)
        assert "TelecomTaskTokenizer" in r
        assert "vocab_size" in r
        assert "max_length" in r

    def test_len_equals_vocab_size(self, base_tokenizer):
        """len() should equal vocab_size."""
        assert len(base_tokenizer) == base_tokenizer.vocab_size


# ─── Tests: encode_task ───────────────────────────────────────────────────────

class TestEncodeTask:
    SAMPLE_TASK = "Configure OFDM subcarrier spacing for 5G NR FR2 band"

    def test_returns_dict_with_required_keys(self, base_tokenizer):
        encoding = base_tokenizer.encode_task(self.SAMPLE_TASK)
        assert "input_ids" in encoding
        assert "attention_mask" in encoding

    def test_input_ids_shape(self, base_tokenizer):
        encoding = base_tokenizer.encode_task(self.SAMPLE_TASK)
        # Should be 2D: [1, seq_len]
        assert encoding["input_ids"].dim() == 2
        assert encoding["input_ids"].shape[0] == 1

    def test_input_ids_dtype_is_long(self, base_tokenizer):
        encoding = base_tokenizer.encode_task(self.SAMPLE_TASK)
        assert encoding["input_ids"].dtype == torch.long

    def test_cls_token_is_first(self, base_tokenizer):
        encoding = base_tokenizer.encode_task(self.SAMPLE_TASK)
        first_id = encoding["input_ids"][0, 0].item()
        assert first_id == base_tokenizer.cls_token_id

    def test_sep_token_at_end(self, base_tokenizer):
        encoding = base_tokenizer.encode_task(self.SAMPLE_TASK)
        # Find the last non-pad token
        ids = encoding["input_ids"][0].tolist()
        last_real = ids[-1]
        assert last_real == base_tokenizer.sep_token_id

    def test_truncates_long_input(self, base_tokenizer):
        long_text = "beamforming " * 200
        encoding = base_tokenizer.encode_task(long_text)
        assert encoding["input_ids"].shape[1] <= base_tokenizer.max_length

    def test_task_special_tokens_in_encoding(self, base_tokenizer):
        """[TASK] token should appear in the encoded sequence."""
        task_token_id = base_tokenizer.tokenizer.convert_tokens_to_ids(
            SPECIAL_TOKENS["task_start"]
        )
        encoding = base_tokenizer.encode_task(self.SAMPLE_TASK)
        ids = encoding["input_ids"][0].tolist()
        assert task_token_id in ids, "[TASK] token not found in encoded output"

    def test_empty_string(self, base_tokenizer):
        """Empty string should still encode without error."""
        encoding = base_tokenizer.encode_task("")
        assert encoding["input_ids"] is not None


# ─── Tests: encode_batch ─────────────────────────────────────────────────────

class TestEncodeBatch:
    SAMPLE_TEXTS = [
        "Massive MIMO beamforming optimization",
        "LDPC channel coding for 5G NR",
        "Channel estimation using pilot signals",
    ]

    def test_batch_returns_correct_shape(self, base_tokenizer):
        encoding = base_tokenizer.encode_batch(self.SAMPLE_TEXTS)
        assert encoding["input_ids"].shape[0] == len(self.SAMPLE_TEXTS)

    def test_batch_with_task_tokens(self, base_tokenizer):
        encoding = base_tokenizer.encode_batch(
            self.SAMPLE_TEXTS, wrap_with_task_tokens=True
        )
        assert encoding["input_ids"].shape[0] == len(self.SAMPLE_TEXTS)

    def test_single_item_batch(self, base_tokenizer):
        encoding = base_tokenizer.encode_batch(["OFDM signal processing"])
        assert encoding["input_ids"].shape[0] == 1

    def test_attention_mask_shape_matches_input_ids(self, base_tokenizer):
        encoding = base_tokenizer.encode_batch(self.SAMPLE_TEXTS)
        assert encoding["input_ids"].shape == encoding["attention_mask"].shape


# ─── Tests: decode ───────────────────────────────────────────────────────────

class TestDecode:
    def test_decode_ids_returns_string(self, base_tokenizer):
        encoding = base_tokenizer.encode_task("OFDM beamforming")
        ids = encoding["input_ids"][0].tolist()
        decoded = base_tokenizer.decode(ids)
        assert isinstance(decoded, str)
        assert len(decoded) > 0

    def test_decode_tensor(self, base_tokenizer):
        encoding = base_tokenizer.encode_task("channel estimation")
        decoded = base_tokenizer.decode(encoding["input_ids"][0])
        assert isinstance(decoded, str)


# ─── Tests: Special Tokens ────────────────────────────────────────────────────

class TestSpecialTokens:
    def test_get_special_token_ids_returns_dict(self, base_tokenizer):
        ids = base_tokenizer.get_special_token_ids()
        assert isinstance(ids, dict)
        assert len(ids) > 0

    def test_pad_token_id_is_int(self, base_tokenizer):
        assert isinstance(base_tokenizer.pad_token_id, int)

    def test_mask_token_id_is_int(self, base_tokenizer):
        assert isinstance(base_tokenizer.mask_token_id, int)

    def test_cls_token_id_is_int(self, base_tokenizer):
        assert isinstance(base_tokenizer.cls_token_id, int)

    def test_sep_token_id_is_int(self, base_tokenizer):
        assert isinstance(base_tokenizer.sep_token_id, int)


# ─── Tests: MLM Data Collator ─────────────────────────────────────────────────

class TestMLMDataCollator:
    def test_data_collator_created(self, base_tokenizer):
        collator = base_tokenizer.get_mlm_data_collator(mlm_probability=0.15)
        assert collator is not None

    def test_data_collator_masks_tokens(self, base_tokenizer):
        """Data collator should produce masked input_ids different from labels."""
        collator = base_tokenizer.get_mlm_data_collator(mlm_probability=0.5)
        encoding = base_tokenizer.encode_task("MIMO beamforming", return_tensors="pt")
        batch = [{
            "input_ids": encoding["input_ids"][0].tolist(),
            "attention_mask": encoding["attention_mask"][0].tolist()
            }]
        collated = collator(batch)
        # With 50% masking, at least some tokens should differ
        assert "input_ids" in collated
        assert "labels" in collated


# ─── Tests: Save and Load ─────────────────────────────────────────────────────

class TestSaveLoad:
    def test_save_creates_files(self, base_tokenizer, tmp_path):
        save_dir = tmp_path / "tokenizer_save"
        base_tokenizer.save(str(save_dir))
        assert save_dir.exists()
        assert (save_dir / "tokenizer_config.json").exists()
        assert (save_dir / "telecom_tokenizer_meta.json").exists()

    def test_load_restores_vocab_size(self, base_tokenizer, tmp_path):
        save_dir = tmp_path / "tokenizer_roundtrip"
        base_tokenizer.save(str(save_dir))
        loaded = TelecomTaskTokenizer.load(str(save_dir))
        assert loaded.vocab_size == base_tokenizer.vocab_size

    def test_load_restores_max_length(self, base_tokenizer, tmp_path):
        save_dir = tmp_path / "tokenizer_maxlen"
        base_tokenizer.save(str(save_dir))
        loaded = TelecomTaskTokenizer.load(str(save_dir))
        assert loaded.max_length == base_tokenizer.max_length


# ─── Tests: Vocab File Loading ────────────────────────────────────────────────

class TestVocabFileLoading:
    def test_missing_vocab_file_does_not_raise(self):
        """from_pretrained with missing vocab file should log warning, not crash."""
        tokenizer = TelecomTaskTokenizer.from_pretrained(
            base_model="bert-base-uncased",
            telecom_vocab_path="/nonexistent/path/vocab.txt",
            max_length=64,
        )
        assert tokenizer.vocab_size > 0

    def test_vocab_file_tokens_added(self, tmp_path):
        vocab_file = tmp_path / "test_vocab.txt"
        vocab_file.write_text("ofdm\nbeamsteering\nthz-band\n", encoding="utf-8")
        tokenizer = TelecomTaskTokenizer.from_pretrained(
            base_model="bert-base-uncased",
            telecom_vocab_path=str(vocab_file),
            max_length=64,
        )
        # Vocab should be larger than standard bert-base-uncased (30522 + specials)
        assert tokenizer.num_added_tokens > 0
