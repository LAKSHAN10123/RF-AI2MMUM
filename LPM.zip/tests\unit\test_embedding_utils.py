"""
test_embedding_utils.py
========================
RF-AI2MMUM Language Processing Module — Unit Tests
Member B: NLP Engineer & Language Module Developer

Unit tests for embedding utility functions:
  - compute_cosine_similarity_matrix
  - reduce_dimensionality (PCA)
  - cluster_embeddings (KMeans)
  - EmbeddingStore: add, get, search, save/load
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from language_module.utils.embedding_utils import (
    EmbeddingStore,
    compute_cosine_similarity_matrix,
    reduce_dimensionality,
    cluster_embeddings,
)


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def random_embeddings() -> torch.Tensor:
    """Random normalized embeddings [10, 768]."""
    embs = torch.randn(10, 768)
    return embs / embs.norm(dim=-1, keepdim=True)


@pytest.fixture
def populated_store(random_embeddings) -> EmbeddingStore:
    """An EmbeddingStore with 10 named embeddings."""
    store = EmbeddingStore()
    names = [f"task_{i}" for i in range(10)]
    store.add_batch(names, random_embeddings)
    return store


# ─── Tests: compute_cosine_similarity_matrix ──────────────────────────────────

class TestCosineSimilarityMatrix:
    def test_self_similarity_shape(self, random_embeddings):
        sim = compute_cosine_similarity_matrix(random_embeddings)
        assert sim.shape == (10, 10)

    def test_diagonal_is_one_for_normalized(self, random_embeddings):
        sim = compute_cosine_similarity_matrix(random_embeddings)
        diag = sim.diagonal()
        assert torch.allclose(diag, torch.ones(10), atol=1e-5)

    def test_cross_similarity_shape(self, random_embeddings):
        other = torch.randn(5, 768)
        sim = compute_cosine_similarity_matrix(random_embeddings, other)
        assert sim.shape == (10, 5)

    def test_values_in_range_minus1_to_1(self, random_embeddings):
        sim = compute_cosine_similarity_matrix(random_embeddings)
        assert sim.min() >= -1.0 - 1e-5
        assert sim.max() <= 1.0 + 1e-5

    def test_symmetric(self, random_embeddings):
        sim = compute_cosine_similarity_matrix(random_embeddings)
        assert torch.allclose(sim, sim.T, atol=1e-5)


# ─── Tests: reduce_dimensionality ────────────────────────────────────────────

class TestReduceDimensionality:
    def test_pca_output_shape(self, random_embeddings):
        reduced = reduce_dimensionality(random_embeddings, method="pca", n_components=2)
        assert reduced.shape == (10, 2)

    def test_pca_from_numpy(self, random_embeddings):
        np_embs = random_embeddings.numpy()
        reduced = reduce_dimensionality(np_embs, method="pca", n_components=3)
        assert reduced.shape == (10, 3)

    def test_tsne_output_shape(self, random_embeddings):
        reduced = reduce_dimensionality(
            random_embeddings, method="tsne", n_components=2, random_state=42
        )
        assert reduced.shape == (10, 2)

    def test_unknown_method_raises(self, random_embeddings):
        with pytest.raises(ValueError, match="Unknown reduction method"):
            reduce_dimensionality(random_embeddings, method="invalid")


# ─── Tests: cluster_embeddings ────────────────────────────────────────────────

class TestClusterEmbeddings:
    def test_kmeans_output_labels_shape(self, random_embeddings):
        labels, centers = cluster_embeddings(random_embeddings, n_clusters=3)
        assert labels.shape == (10,)

    def test_kmeans_output_centers_shape(self, random_embeddings):
        labels, centers = cluster_embeddings(random_embeddings, n_clusters=3)
        assert centers.shape == (3, 768)

    def test_kmeans_label_values_in_range(self, random_embeddings):
        n_clusters = 4
        labels, _ = cluster_embeddings(random_embeddings, n_clusters=n_clusters)
        assert labels.min() >= 0
        assert labels.max() < n_clusters

    def test_agglomerative_clustering(self, random_embeddings):
        labels, centers = cluster_embeddings(
            random_embeddings, n_clusters=3, method="agglomerative"
        )
        assert labels.shape == (10,)
        assert centers.shape == (3, 768)

    def test_unknown_method_raises(self, random_embeddings):
        with pytest.raises(ValueError, match="Unknown clustering method"):
            cluster_embeddings(random_embeddings, n_clusters=3, method="dbscan")


# ─── Tests: EmbeddingStore ────────────────────────────────────────────────────

class TestEmbeddingStore:
    def test_initial_store_is_empty(self):
        store = EmbeddingStore()
        assert len(store) == 0

    def test_add_single_embedding(self):
        store = EmbeddingStore()
        emb = torch.randn(768)
        store.add("task_1", emb)
        assert len(store) == 1
        assert "task_1" in store

    def test_get_returns_correct_embedding(self):
        store = EmbeddingStore()
        emb = torch.randn(768)
        store.add("my_task", emb)
        retrieved = store.get("my_task")
        assert torch.allclose(retrieved, emb)

    def test_get_missing_key_raises(self):
        store = EmbeddingStore()
        with pytest.raises(KeyError):
            store.get("nonexistent")

    def test_add_batch(self, random_embeddings):
        store = EmbeddingStore()
        names = [f"t_{i}" for i in range(10)]
        store.add_batch(names, random_embeddings)
        assert len(store) == 10

    def test_add_batch_length_mismatch_raises(self, random_embeddings):
        store = EmbeddingStore()
        with pytest.raises(ValueError, match="Length mismatch"):
            store.add_batch(["only_one"], random_embeddings)

    def test_contains(self, populated_store):
        assert "task_0" in populated_store
        assert "nonexistent" not in populated_store

    def test_repr(self, populated_store):
        r = repr(populated_store)
        assert "EmbeddingStore" in r
        assert "10" in r

    def test_get_all_embeddings_shape(self, populated_store):
        names, stacked = populated_store.get_all_embeddings()
        assert len(names) == 10
        assert stacked.shape == (10, 768)

    def test_get_all_embeddings_empty_store(self):
        store = EmbeddingStore()
        names, stacked = store.get_all_embeddings()
        assert names == []
        assert stacked.shape == (0, 768)


# ─── Tests: EmbeddingStore.search ────────────────────────────────────────────

class TestEmbeddingStoreSearch:
    def test_search_returns_top_k_results(self, populated_store, random_embeddings):
        query = random_embeddings[0]
        results = populated_store.search(query, top_k=3)
        assert len(results) == 3

    def test_search_returns_names_and_scores(self, populated_store, random_embeddings):
        query = random_embeddings[0]
        results = populated_store.search(query, top_k=3)
        for name, score in results:
            assert isinstance(name, str)
            assert isinstance(score, float)
            assert -1.0 <= score <= 1.0

    def test_search_first_result_is_most_similar(self, populated_store):
        # Add a known embedding and search for it
        store = EmbeddingStore()
        target = torch.randn(768)
        target_norm = target / target.norm()
        store.add("target_task", target_norm)
        for i in range(5):
            other = torch.randn(768)
            store.add(f"other_{i}", other / other.norm())

        results = store.search(target_norm, top_k=1)
        assert results[0][0] == "target_task"
        assert results[0][1] == pytest.approx(1.0, abs=1e-5)

    def test_search_empty_store(self):
        store = EmbeddingStore()
        query = torch.randn(768)
        results = store.search(query, top_k=5)
        assert results == []

    def test_search_top_k_clipped_to_store_size(self, populated_store, random_embeddings):
        query = random_embeddings[0]
        results = populated_store.search(query, top_k=100)  # Store has only 10
        assert len(results) == 10


# ─── Tests: EmbeddingStore Save / Load ───────────────────────────────────────

class TestEmbeddingStoreSaveLoad:
    def test_save_creates_pt_file(self, populated_store, tmp_path):
        save_dir = tmp_path / "store_save"
        populated_store.save(str(save_dir))
        pt_files = list(save_dir.glob("*.pt"))
        assert len(pt_files) > 0

    def test_save_creates_meta_json(self, populated_store, tmp_path):
        save_dir = tmp_path / "store_save_meta"
        populated_store.save(str(save_dir))
        meta_files = list(save_dir.glob("*_meta.json"))
        assert len(meta_files) > 0

    def test_load_restores_count(self, populated_store, tmp_path):
        save_dir = tmp_path / "store_roundtrip"
        populated_store.save(str(save_dir))
        loaded = EmbeddingStore.load(str(save_dir))
        assert len(loaded) == len(populated_store)

    def test_load_restores_embeddings(self, tmp_path):
        store = EmbeddingStore()
        emb = torch.randn(768)
        store.add("test_task", emb, metadata={"source": "unit_test"})

        save_dir = tmp_path / "store_embed"
        store.save(str(save_dir))
        loaded = EmbeddingStore.load(str(save_dir))

        assert "test_task" in loaded
        assert torch.allclose(loaded.get("test_task"), emb)
