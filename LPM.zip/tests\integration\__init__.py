"""RF-AI2MMUM — Integration Tests Package"""
