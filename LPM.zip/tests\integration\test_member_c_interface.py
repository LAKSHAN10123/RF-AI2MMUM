"""
test_member_c_interface.py
===========================
RF-AI2MMUM Language Processing Module — Integration Tests
Member B: NLP Engineer & Language Module Developer

Tests that simulate Member C (RF Signal Module) consuming the
LanguageEmbeddingInterface API. Validates the contract between
Member B's language module and Member C's RF fusion module.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Dict, Any

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from language_module import LanguageEmbeddingInterface


# ─── Simulated Member C Consumer ──────────────────────────────────────────────

class MockRFFusionModule:
    """
    Mock implementation of Member C's RF Fusion Module.

    Simulates how Member C would consume embeddings from Member B's
    LanguageEmbeddingInterface. This validates the API contract.
    """

    def __init__(self, lang_interface: LanguageEmbeddingInterface) -> None:
        self.lang_interface = lang_interface
        self.embedding_dim = 768  # Expected from Member B's spec

    def process_task_command(
        self,
        task_text: str,
        rf_signal_features: torch.Tensor,
    ) -> Dict[str, Any]:
        """
        Process an RF task by fusing language embedding with RF features.

        Simulates the multi-modal fusion that Member C will implement.

        Args:
            task_text: Natural language task description from operator.
            rf_signal_features: RF signal feature tensor [feature_dim].

        Returns:
            Dict with 'language_embedding', 'rf_features', 'fusion_ready' flag.
        """
        # Get language embedding from Member B's interface
        lang_emb = self.lang_interface.get_task_embedding(task_text)

        return {
            "language_embedding": lang_emb,
            "rf_signal_features": rf_signal_features,
            "fusion_ready": True,
            "embedding_dim": lang_emb.shape[-1],
        }

    def batch_process_tasks(
        self,
        tasks: list,
        rf_batch: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """
        Batch process multiple RF tasks.

        Args:
            tasks: List of task description strings.
            rf_batch: Batch of RF signal features [batch, feature_dim].

        Returns:
            Dict with 'lang_embeddings' [batch, 768] and 'rf_features' [batch, feature_dim].
        """
        lang_embeddings = self.lang_interface.get_batch_embeddings(tasks)
        return {
            "lang_embeddings": lang_embeddings,
            "rf_features": rf_batch,
        }


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def interface() -> LanguageEmbeddingInterface:
    return LanguageEmbeddingInterface(
        model_name_or_path="bert-base-uncased",
        device="cpu",
        max_seq_length=128,
    )


@pytest.fixture(scope="module")
def mock_rf_module(interface) -> MockRFFusionModule:
    return MockRFFusionModule(lang_interface=interface)


# ─── RF Task Scenarios ────────────────────────────────────────────────────────

RF_TASK_SCENARIOS = [
    {
        "task": "Configure OFDM for high-speed vehicular channel",
        "rf_context": {"snr_db": 15.0, "channel_type": "Rayleigh", "doppler_hz": 500},
        "expected_processing": "OFDM",
    },
    {
        "task": "Optimize massive MIMO beamforming weights for cell-edge user",
        "rf_context": {"snr_db": 5.0, "num_antennas": 64, "channel_type": "Rician"},
        "expected_processing": "MIMO",
    },
    {
        "task": "Apply NOMA power allocation for two users",
        "rf_context": {"snr_db": 20.0, "num_users": 2, "bandwidth_mhz": 20},
        "expected_processing": "NOMA",
    },
]


# ─── Tests: Member C API Contract ─────────────────────────────────────────────

class TestMemberCAPIContract:
    """Validates that LanguageEmbeddingInterface satisfies Member C's requirements."""

    def test_embedding_dim_is_768(self, interface):
        """Member C expects exactly 768-dimensional embeddings."""
        emb = interface.get_task_embedding("Configure 5G NR beamforming")
        assert emb.shape[-1] == 768, (
            f"Member C contract violation: expected dim=768, got {emb.shape[-1]}"
        )

    def test_embedding_is_torch_tensor(self, interface):
        """Member C expects torch.Tensor for direct use in neural network fusion."""
        emb = interface.get_task_embedding("OFDM channel estimation")
        assert isinstance(emb, torch.Tensor), "Member C requires torch.Tensor output"

    def test_embedding_is_float32(self, interface):
        """Member C's fusion layer expects float32 inputs."""
        emb = interface.get_task_embedding("Adaptive modulation for SNR")
        assert emb.dtype == torch.float32, f"Expected float32, got {emb.dtype}"

    def test_batch_embeddings_type_and_shape(self, interface):
        """Batch API must return [N, 768] torch.Tensor."""
        tasks = [s["task"] for s in RF_TASK_SCENARIOS]
        embs = interface.get_batch_embeddings(tasks)
        assert isinstance(embs, torch.Tensor)
        assert embs.shape == (len(tasks), 768)

    def test_embedding_on_cpu_by_default(self, interface):
        """Member C loads embeddings to CPU for flexible device placement."""
        emb = interface.get_task_embedding("LDPC channel coding for 5G NR")
        assert emb.device.type == "cpu"

    def test_interface_is_deterministic(self, interface):
        """Calling with the same text must always produce the same embedding."""
        task = "Configure OFDM subcarrier spacing for 5G NR"
        emb1 = interface.get_task_embedding(task)
        emb2 = interface.get_task_embedding(task)
        assert torch.allclose(emb1, emb2, atol=1e-7), "Non-deterministic embeddings!"


# ─── Tests: Mock RF Fusion Module ────────────────────────────────────────────

class TestMockRFModule:
    def test_single_task_fusion_returns_dict(self, mock_rf_module):
        rf_features = torch.randn(128)
        result = mock_rf_module.process_task_command(
            "Configure beamforming for mmWave MIMO",
            rf_features,
        )
        assert isinstance(result, dict)

    def test_fusion_result_contains_required_keys(self, mock_rf_module):
        rf_features = torch.randn(128)
        result = mock_rf_module.process_task_command(
            "OFDM channel estimation with MMSE",
            rf_features,
        )
        assert "language_embedding" in result
        assert "rf_signal_features" in result
        assert "fusion_ready" in result

    def test_fusion_ready_flag(self, mock_rf_module):
        result = mock_rf_module.process_task_command(
            "Adaptive coding for high SNR",
            torch.randn(64),
        )
        assert result["fusion_ready"] is True

    def test_language_embedding_shape_in_fusion(self, mock_rf_module):
        result = mock_rf_module.process_task_command(
            "Beamforming weight optimization",
            torch.randn(256),
        )
        assert result["language_embedding"].shape == (768,)

    def test_batch_processing(self, mock_rf_module):
        tasks = [s["task"] for s in RF_TASK_SCENARIOS]
        rf_batch = torch.randn(len(tasks), 128)
        result = mock_rf_module.batch_process_tasks(tasks, rf_batch)

        assert "lang_embeddings" in result
        assert "rf_features" in result
        assert result["lang_embeddings"].shape == (len(tasks), 768)


# ─── Tests: RF Context Scenarios ─────────────────────────────────────────────

class TestRFContextScenarios:
    @pytest.mark.parametrize("scenario", RF_TASK_SCENARIOS)
    def test_scenario_produces_valid_embedding(self, interface, scenario):
        result = interface.process_rf_task(
            scenario["task"],
            rf_context=scenario["rf_context"],
        )
        assert result.embedding.shape == (768,)
        assert not torch.isnan(result.embedding).any()

    @pytest.mark.parametrize("scenario", RF_TASK_SCENARIOS)
    def test_context_changes_embedding(self, interface, scenario):
        """Adding RF context should produce different embedding from no context."""
        emb_no_ctx = interface.get_task_embedding(scenario["task"])
        result_with_ctx = interface.process_rf_task(
            scenario["task"],
            rf_context=scenario["rf_context"],
        )
        # Embeddings should be different (context enriches the prompt)
        # Note: may be similar if context has little impact, so just check shape
        assert result_with_ctx.embedding.shape == emb_no_ctx.shape


# ─── Tests: Member C Data Exchange Format ────────────────────────────────────

class TestDataExchangeFormat:
    def test_embedding_serializable_to_list(self, interface):
        """Member C may need to serialize embeddings for network transfer."""
        emb = interface.get_task_embedding("5G NR channel estimation")
        as_list = emb.tolist()
        assert isinstance(as_list, list)
        assert len(as_list) == 768

    def test_embedding_reconstructable_from_list(self, interface):
        """Embedding should be recoverable from list serialization."""
        emb = interface.get_task_embedding("Beamforming for massive MIMO")
        as_list = emb.tolist()
        reconstructed = torch.tensor(as_list)
        assert torch.allclose(emb, reconstructed, atol=1e-7)

    def test_process_rf_task_dict_serializable(self, interface):
        """TaskEmbeddingResult.to_dict() must return JSON-serializable types."""
        import json
        result = interface.process_rf_task(
            "Configure HARQ for reliable transmission",
            rf_context={"snr_db": 12.0},
        )
        d = result.to_dict()
        # Should not raise
        json_str = json.dumps(d)
        assert len(json_str) > 0
