"""
test_text_encoder.py
====================
RF-AI2MMUM Language Processing Module — Unit Tests
Member B: NLP Engineer & Language Module Developer

Unit tests for TextEncoder:
  - Embedding shape (768-dimensional output)
  - All pooling modes (CLS, MEAN, MAX, MEAN_SQRT_LEN)
  - Normalization
  - Batch encoding
  - Device management
  - Save / load round-trip
  - Parameter count
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import pytest
import torch
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from language_module.text_encoder import TextEncoder, PoolingMode
from language_module.task_tokenizer import TelecomTaskTokenizer


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def tokenizer() -> TelecomTaskTokenizer:
    return TelecomTaskTokenizer.from_pretrained(
        base_model="bert-base-uncased",
        max_length=64,
    )


@pytest.fixture(scope="module")
def mean_encoder() -> TextEncoder:
    return TextEncoder.from_pretrained(
        "bert-base-uncased",
        pooling_mode=PoolingMode.MEAN,
        normalize=True,
    )


@pytest.fixture(scope="module")
def cls_encoder() -> TextEncoder:
    return TextEncoder.from_pretrained(
        "bert-base-uncased",
        pooling_mode=PoolingMode.CLS,
        normalize=False,
    )


# ─── Helper ────────────────────────────────────────────────────────────────────

def _tokenize(tokenizer: TelecomTaskTokenizer, text: str) -> dict:
    return tokenizer.encode_batch([text], padding=True, truncation=True, return_tensors="pt")


def _tokenize_batch(tokenizer: TelecomTaskTokenizer, texts: list) -> dict:
    return tokenizer.encode_batch(texts, padding=True, truncation=True, return_tensors="pt")


# ─── Tests: Initialization ────────────────────────────────────────────────────

class TestInitialization:
    def test_embedding_dim_is_768(self, mean_encoder):
        assert mean_encoder.embedding_dim == 768

    def test_num_parameters_positive(self, mean_encoder):
        assert mean_encoder.num_parameters > 0

    def test_repr_contains_key_info(self, mean_encoder):
        r = repr(mean_encoder)
        assert "TextEncoder" in r
        assert "mean" in r

    def test_config_attribute(self, mean_encoder):
        assert mean_encoder.config is not None
        assert mean_encoder.config.hidden_size == 768


# ─── Tests: forward() Output Shape ────────────────────────────────────────────

class TestForwardOutputShape:
    SAMPLE_TEXT = "Beamforming optimization for massive MIMO 5G NR downlink"

    def test_single_input_shape(self, mean_encoder, tokenizer):
        enc = _tokenize(tokenizer, self.SAMPLE_TEXT)
        with torch.no_grad():
            out = mean_encoder(enc["input_ids"], enc["attention_mask"])
        assert out.shape == (1, 768), f"Expected (1, 768), got {out.shape}"

    def test_batch_input_shape(self, mean_encoder, tokenizer):
        texts = [
            "OFDM channel estimation",
            "Adaptive modulation with SNR feedback",
            "NOMA successive interference cancellation",
        ]
        enc = _tokenize_batch(tokenizer, texts)
        with torch.no_grad():
            out = mean_encoder(enc["input_ids"], enc["attention_mask"])
        assert out.shape == (3, 768), f"Expected (3, 768), got {out.shape}"

    def test_cls_pooling_shape(self, cls_encoder, tokenizer):
        enc = _tokenize(tokenizer, self.SAMPLE_TEXT)
        with torch.no_grad():
            out = cls_encoder(enc["input_ids"], enc["attention_mask"])
        assert out.shape == (1, 768)

    def test_max_pooling_shape(self, tokenizer):
        encoder = TextEncoder.from_pretrained(
            "bert-base-uncased", pooling_mode=PoolingMode.MAX, normalize=False
        )
        enc = _tokenize(tokenizer, self.SAMPLE_TEXT)
        with torch.no_grad():
            out = encoder(enc["input_ids"], enc["attention_mask"])
        assert out.shape == (1, 768)

    def test_mean_sqrt_len_pooling_shape(self, tokenizer):
        encoder = TextEncoder.from_pretrained(
            "bert-base-uncased", pooling_mode=PoolingMode.MEAN_SQRT_LEN, normalize=False
        )
        enc = _tokenize(tokenizer, self.SAMPLE_TEXT)
        with torch.no_grad():
            out = encoder(enc["input_ids"], enc["attention_mask"])
        assert out.shape == (1, 768)


# ─── Tests: Normalization ─────────────────────────────────────────────────────

class TestNormalization:
    def test_normalized_embedding_has_unit_norm(self, mean_encoder, tokenizer):
        enc = _tokenize(tokenizer, "OFDM beamforming")
        with torch.no_grad():
            emb = mean_encoder(enc["input_ids"], enc["attention_mask"])
        norms = emb.norm(dim=-1)
        assert torch.allclose(norms, torch.ones_like(norms), atol=1e-5), (
            f"Expected unit norm, got: {norms}"
        )

    def test_unnormalized_embedding_is_not_unit(self, cls_encoder, tokenizer):
        enc = _tokenize(tokenizer, "OFDM channel estimation with pilots")
        with torch.no_grad():
            emb = cls_encoder(enc["input_ids"], enc["attention_mask"])
        norms = emb.norm(dim=-1)
        # Without normalization, norms should not all be 1.0
        assert not torch.allclose(norms, torch.ones_like(norms), atol=1e-2)


# ─── Tests: encode() (no_grad wrapper) ───────────────────────────────────────

class TestEncodeMethod:
    def test_encode_single_returns_2d(self, mean_encoder, tokenizer):
        enc = _tokenize(tokenizer, "Massive MIMO precoding")
        emb = mean_encoder.encode(enc["input_ids"], enc["attention_mask"])
        assert emb.dim() == 2
        assert emb.shape == (1, 768)

    def test_encode_consistency_with_forward(self, mean_encoder, tokenizer):
        """encode() should give same result as forward() under no_grad."""
        enc = _tokenize(tokenizer, "LDPC polar code")
        with torch.no_grad():
            fwd_out = mean_encoder(enc["input_ids"], enc["attention_mask"])
        enc_out = mean_encoder.encode(enc["input_ids"], enc["attention_mask"])
        assert torch.allclose(fwd_out, enc_out, atol=1e-6)

    def test_different_texts_give_different_embeddings(self, mean_encoder, tokenizer):
        enc1 = _tokenize(tokenizer, "OFDM subcarrier spacing configuration")
        enc2 = _tokenize(tokenizer, "Power amplifier linearization via DPD")
        emb1 = mean_encoder.encode(enc1["input_ids"], enc1["attention_mask"])
        emb2 = mean_encoder.encode(enc2["input_ids"], enc2["attention_mask"])
        assert not torch.allclose(emb1, emb2, atol=1e-4), (
            "Different texts should produce different embeddings"
        )

    def test_same_text_gives_same_embedding(self, mean_encoder, tokenizer):
        text = "Beamforming for 5G NR"
        enc = _tokenize(tokenizer, text)
        emb1 = mean_encoder.encode(enc["input_ids"], enc["attention_mask"])
        emb2 = mean_encoder.encode(enc["input_ids"], enc["attention_mask"])
        assert torch.allclose(emb1, emb2, atol=1e-7)


# ─── Tests: Cosine Similarity ─────────────────────────────────────────────────

class TestCosineSimilarity:
    def test_similar_tasks_have_high_similarity(self, mean_encoder, tokenizer):
        texts = [
            "Configure OFDM subcarrier spacing for 5G NR",
            "Set OFDM numerology and subcarrier spacing in 5G NR system",
            "Power amplifier hardware calibration routine",
        ]
        enc = _tokenize_batch(tokenizer, texts)
        embs = mean_encoder.encode(enc["input_ids"], enc["attention_mask"])

        # Similar pair
        sim_similar = F.cosine_similarity(embs[0:1], embs[1:2]).item()
        # Different pair
        sim_different = F.cosine_similarity(embs[0:1], embs[2:3]).item()

        assert sim_similar > sim_different, (
            f"Similar tasks should have higher similarity: "
            f"sim_similar={sim_similar:.4f}, sim_different={sim_different:.4f}"
        )


# ─── Tests: Hidden States ─────────────────────────────────────────────────────

class TestHiddenStates:
    def test_get_hidden_states_returns_list(self, mean_encoder, tokenizer):
        enc = _tokenize(tokenizer, "Channel estimation")
        hidden = mean_encoder.get_hidden_states(
            enc["input_ids"], enc["attention_mask"]
        )
        assert isinstance(hidden, list)
        assert len(hidden) > 0

    def test_layer_selection(self, mean_encoder, tokenizer):
        enc = _tokenize(tokenizer, "Interference cancellation")
        hidden = mean_encoder.get_hidden_states(
            enc["input_ids"], enc["attention_mask"], layer_indices=[0, -1]
        )
        assert len(hidden) == 2


# ─── Tests: Token Embedding Resize ───────────────────────────────────────────

class TestTokenEmbeddingResize:
    def test_resize_does_not_crash(self):
        encoder = TextEncoder.from_pretrained("bert-base-uncased")
        new_size = encoder.config.vocab_size + 10
        encoder.resize_token_embeddings(new_size)
        # Check the embedding layer has been resized
        actual_size = encoder.bert.embeddings.word_embeddings.num_embeddings
        assert actual_size == new_size


# ─── Tests: Save / Load Round-trip ────────────────────────────────────────────

class TestSaveLoad:
    def test_save_creates_directory(self, mean_encoder, tmp_path):
        save_dir = tmp_path / "encoder_save"
        mean_encoder.save(str(save_dir))
        assert save_dir.exists()
        assert (save_dir / "encoder_meta.json").exists()

    def test_load_restores_pooling_mode(self, mean_encoder, tmp_path):
        save_dir = tmp_path / "encoder_roundtrip"
        mean_encoder.save(str(save_dir))
        loaded = TextEncoder.load(str(save_dir))
        assert loaded.pooling_mode == mean_encoder.pooling_mode

    def test_load_restores_normalize(self, mean_encoder, tmp_path):
        save_dir = tmp_path / "encoder_norm"
        mean_encoder.save(str(save_dir))
        loaded = TextEncoder.load(str(save_dir))
        assert loaded.normalize == mean_encoder.normalize

    def test_loaded_encoder_produces_same_embeddings(self, mean_encoder, tokenizer, tmp_path):
        save_dir = tmp_path / "encoder_consistency"
        mean_encoder.save(str(save_dir))
        loaded = TextEncoder.load(str(save_dir))

        enc = _tokenize(tokenizer, "5G NR OFDM numerology")
        original_emb = mean_encoder.encode(enc["input_ids"], enc["attention_mask"])
        loaded_emb = loaded.encode(enc["input_ids"], enc["attention_mask"])

        assert torch.allclose(original_emb, loaded_emb, atol=1e-5)
