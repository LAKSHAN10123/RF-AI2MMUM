"""
run_dapt.py
===========
RF-AI2MMUM Language Processing Module — Scripts
Member B: NLP Engineer & Language Module Developer

Launch script for Domain Adaptive Pre-Training (DAPT) on the telecom corpus.

Usage (from project root):
    python scripts/run_dapt.py --config configs/training_config.yaml
    python scripts/run_dapt.py --corpus_path data/telecom_corpus/sample_corpus.txt \\
                               --output_dir outputs/dapt_model \\
                               --num_epochs 3 \\
                               --device cuda

Run with --help to see all options.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

# ── Add project root to path ──────────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from language_module.dapt_trainer import DAPTTrainer, DAPTConfig
from language_module.task_tokenizer import TelecomTaskTokenizer
from language_module.utils.logging_utils import setup_logging

logger = logging.getLogger("language_module.scripts.run_dapt")


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description=(
            "RF-AI2MMUM DAPT Training — Domain Adaptive Pre-Training "
            "for BERT on telecom corpus using Masked Language Modeling."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # ── Data arguments ─────────────────────────────────────────────────────
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="Path to training_config.yaml. If provided, overrides defaults.",
    )
    parser.add_argument(
        "--corpus_path",
        type=str,
        default="data/telecom_corpus/sample_corpus.txt",
        help="Path to the domain corpus text file.",
    )
    parser.add_argument(
        "--vocab_path",
        type=str,
        default="data/telecom_corpus/telecom_vocab.txt",
        help="Path to the telecom vocabulary extension file.",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="outputs/dapt_model",
        help="Directory to save the DAPT model.",
    )

    # ── Model arguments ───────────────────────────────────────────────────
    parser.add_argument(
        "--base_model",
        type=str,
        default="bert-base-uncased",
        help="HuggingFace model ID or local path for base BERT model.",
    )
    parser.add_argument(
        "--max_seq_length",
        type=int,
        default=512,
        help="Maximum tokenized sequence length.",
    )

    # ── Training arguments ────────────────────────────────────────────────
    parser.add_argument(
        "--num_epochs",
        type=int,
        default=5,
        help="Number of DAPT training epochs.",
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=8,
        help="Training batch size per device.",
    )
    parser.add_argument(
        "--learning_rate",
        type=float,
        default=2e-5,
        help="Initial learning rate.",
    )
    parser.add_argument(
        "--mlm_probability",
        type=float,
        default=0.15,
        help="Probability of masking each token during MLM.",
    )
    parser.add_argument(
        "--validation_split",
        type=float,
        default=0.1,
        help="Fraction of corpus to use as validation set.",
    )
    parser.add_argument(
        "--gradient_accumulation_steps",
        type=int,
        default=4,
        help="Number of gradient accumulation steps.",
    )

    # ── Device arguments ──────────────────────────────────────────────────
    parser.add_argument(
        "--device",
        type=str,
        default="cuda",
        choices=["cuda", "cpu", "mps"],
        help="Computation device.",
    )
    parser.add_argument(
        "--fp16",
        action="store_true",
        default=False,
        help="Enable mixed precision (fp16) training.",
    )

    # ── Logging arguments ─────────────────────────────────────────────────
    parser.add_argument(
        "--log_level",
        type=str,
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging verbosity level.",
    )
    parser.add_argument(
        "--log_file",
        type=str,
        default="outputs/logs/dapt_training.log",
        help="Path to write training logs.",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility.",
    )

    return parser.parse_args()


def load_config_from_yaml(config_path: str) -> dict:
    """Load training configuration from a YAML file."""
    try:
        import yaml
        with open(config_path, "r") as f:
            cfg = yaml.safe_load(f)
        logger.info("Loaded config from: %s", config_path)
        return cfg
    except ImportError:
        logger.warning("PyYAML not available — using command-line args only.")
        return {}
    except FileNotFoundError:
        logger.warning("Config file not found: %s — using defaults.", config_path)
        return {}


def main() -> None:
    """Main entry point for DAPT training."""
    args = parse_args()

    # Setup logging
    setup_logging(level=args.log_level, log_file=args.log_file)

    logger.info("=" * 65)
    logger.info("RF-AI2MMUM DAPT Training")
    logger.info("Member B: NLP Engineer & Language Module Developer")
    logger.info("=" * 65)

    # Load YAML config if provided
    yaml_config: dict = {}
    if args.config is not None:
        yaml_config = load_config_from_yaml(args.config)

    # Extract hyperparameters from YAML (nested under 'hyperparams', 'training', etc.)
    hp = yaml_config.get("hyperparams", {})
    training_cfg = yaml_config.get("training", {})
    data_cfg = yaml_config.get("data", {})
    mlm_cfg = yaml_config.get("mlm", {})

    # Build DAPTConfig (CLI args take precedence over YAML)
    config = DAPTConfig(
        corpus_path=data_cfg.get("corpus_path", args.corpus_path),
        output_dir=training_cfg.get("output_dir", args.output_dir),
        num_epochs=hp.get("num_train_epochs", args.num_epochs),
        per_device_train_batch_size=hp.get("per_device_train_batch_size", args.batch_size),
        learning_rate=float(hp.get("learning_rate", args.learning_rate)),
        mlm_probability=mlm_cfg.get("mlm_probability", args.mlm_probability),
        validation_split=data_cfg.get("validation_split", args.validation_split),
        max_seq_length=args.max_seq_length,
        device=training_cfg.get("device", args.device),
        fp16=training_cfg.get("fp16", args.fp16),
        gradient_accumulation_steps=hp.get(
            "gradient_accumulation_steps", args.gradient_accumulation_steps
        ),
        seed=training_cfg.get("seed", args.seed),
    )

    logger.info("Configuration:")
    logger.info("  Corpus     : %s", config.corpus_path)
    logger.info("  Output     : %s", config.output_dir)
    logger.info("  Epochs     : %d", config.num_epochs)
    logger.info("  Batch size : %d", config.per_device_train_batch_size)
    logger.info("  LR         : %.2e", config.learning_rate)
    logger.info("  MLM prob   : %.2f", config.mlm_probability)
    logger.info("  Device     : %s", config.device)
    logger.info("  FP16       : %s", config.fp16)
    logger.info("")

    # Build tokenizer with telecom vocabulary
    logger.info("Building TelecomTaskTokenizer...")
    tokenizer = TelecomTaskTokenizer.from_pretrained(
        base_model=args.base_model,
        telecom_vocab_path=args.vocab_path if Path(args.vocab_path).exists() else None,
        max_length=args.max_seq_length,
    )
    logger.info("Tokenizer ready | vocab_size=%d", tokenizer.vocab_size)

    # Initialize trainer
    trainer = DAPTTrainer(
        model_name=args.base_model,
        tokenizer=tokenizer,
        config=config,
    )

    # Run training
    logger.info("Starting DAPT training...")
    metrics = trainer.train()

    logger.info("")
    logger.info("Training complete!")
    logger.info("Final metrics:")
    for k, v in metrics.items():
        logger.info("  %s: %s", k, v)

    # Save model
    logger.info("")
    logger.info("Saving DAPT model...")
    save_path = trainer.save_model()
    logger.info("Model saved to: %s", save_path)

    # Final evaluation
    logger.info("")
    logger.info("Running final evaluation...")
    try:
        eval_results = trainer.evaluate()
        logger.info("Evaluation results:")
        for k, v in eval_results.items():
            logger.info("  %s: %.4f" if isinstance(v, float) else "  %s: %s", k, v)
    except Exception as e:
        logger.warning("Evaluation skipped: %s", e)

    logger.info("")
    logger.info("DAPT training complete!")
    logger.info("Next steps:")
    logger.info("  1. Generate embeddings: python scripts/generate_embeddings.py \\")
    logger.info("         --model_path %s", config.output_dir)
    logger.info("  2. Run tests: python -m pytest tests/ -v")


if __name__ == "__main__":
    main()
