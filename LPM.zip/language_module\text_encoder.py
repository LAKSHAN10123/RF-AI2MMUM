"""
text_encoder.py
===============
RF-AI2MMUM Language Processing Module — Member B

Implements a BERT/SBERT-based text encoder producing 768-dimensional
dense embeddings for RF task descriptions. Supports:
  - [CLS]-token embedding extraction
  - Mean pooling over token embeddings (SBERT-style)
  - Max pooling over token embeddings
  - Optional L2 normalization for cosine similarity search
  - Batch encoding with configurable batch sizes
  - Model fine-tuning mode with embedding layer resize (post-DAPT)

Usage:
    from language_module.text_encoder import TextEncoder

    encoder = TextEncoder.from_pretrained("bert-base-uncased")
    embedding = encoder.encode("Configure beamforming for mmWave MIMO")
    # Returns torch.Tensor of shape [768]

    batch = encoder.encode_batch([
        "OFDM channel estimation with pilot symbols",
        "Adaptive modulation based on SNR feedback",
    ])
    # Returns torch.Tensor of shape [2, 768]
"""

from __future__ import annotations

import logging
import os
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import BertConfig, BertModel, BertPreTrainedModel

logger = logging.getLogger(__name__)


# ─── Enumerations ─────────────────────────────────────────────────────────────

class PoolingMode(str, Enum):
    """Pooling strategy for converting token embeddings to sentence embedding."""
    CLS = "cls"
    MEAN = "mean"
    MAX = "max"
    MEAN_SQRT_LEN = "mean_sqrt_len"


# ─── Pooling Layer ────────────────────────────────────────────────────────────

class MeanPooling(nn.Module):
    """
    Mean pooling over BERT token embeddings, respecting attention masks.

    Computes the mean of all non-padding token embeddings to produce a
    fixed-size sentence embedding.
    """

    def forward(
        self,
        token_embeddings: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute mean-pooled sentence embedding.

        Args:
            token_embeddings: Token-level embeddings [batch, seq_len, hidden].
            attention_mask: Binary mask [batch, seq_len].

        Returns:
            Sentence embedding tensor [batch, hidden].
        """
        mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        sum_embeddings = torch.sum(token_embeddings * mask_expanded, dim=1)
        sum_mask = torch.clamp(mask_expanded.sum(dim=1), min=1e-9)
        return sum_embeddings / sum_mask


class MaxPooling(nn.Module):
    """Max pooling over BERT token embeddings, replacing padding positions with -inf."""

    def forward(
        self,
        token_embeddings: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute max-pooled sentence embedding.

        Args:
            token_embeddings: Token-level embeddings [batch, seq_len, hidden].
            attention_mask: Binary mask [batch, seq_len].

        Returns:
            Sentence embedding tensor [batch, hidden].
        """
        mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        # Set padding positions to large negative value before max
        token_embeddings_masked = token_embeddings.clone()
        token_embeddings_masked[mask_expanded == 0] = -1e9
        max_embeddings, _ = torch.max(token_embeddings_masked, dim=1)
        return max_embeddings


class MeanSqrtLenPooling(nn.Module):
    """Mean pooling scaled by square root of sequence length."""

    def forward(
        self,
        token_embeddings: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute mean-sqrt-len pooled sentence embedding.

        Args:
            token_embeddings: Token-level embeddings [batch, seq_len, hidden].
            attention_mask: Binary mask [batch, seq_len].

        Returns:
            Sentence embedding tensor [batch, hidden].
        """
        mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        sum_embeddings = torch.sum(token_embeddings * mask_expanded, dim=1)
        sum_mask = torch.clamp(mask_expanded.sum(dim=1), min=1e-9)
        return sum_embeddings / torch.sqrt(sum_mask)


# ─── TextEncoder ─────────────────────────────────────────────────────────────

class TextEncoder(nn.Module):
    """
    BERT/SBERT-based text encoder producing 768-dimensional dense embeddings.

    Wraps a HuggingFace BertModel and applies configurable pooling to produce
    fixed-size sentence/task embeddings suitable for multi-modal fusion with
    the RF signal processing module (Member C).

    Attributes:
        bert (BertModel): Underlying BERT transformer model.
        pooling_mode (PoolingMode): Strategy for aggregating token embeddings.
        normalize (bool): Whether to L2-normalize output embeddings.
        embedding_dim (int): Dimensionality of output embeddings (768).
        device (torch.device): Computation device.
    """

    EMBEDDING_DIM: int = 768  # BERT-base hidden size

    def __init__(
        self,
        bert_model: BertModel,
        pooling_mode: Union[PoolingMode, str] = PoolingMode.MEAN,
        normalize: bool = True,
    ) -> None:
        """
        Initialize TextEncoder (prefer using `from_pretrained`).

        Args:
            bert_model: Pre-loaded BertModel instance.
            pooling_mode: Pooling strategy.
            normalize: Whether to normalize output embeddings.
        """
        super().__init__()
        self.bert = bert_model
        self.pooling_mode = PoolingMode(pooling_mode)
        self.normalize = normalize

        # Register pooling modules
        self._poolers: Dict[str, nn.Module] = {
            PoolingMode.MEAN: MeanPooling(),
            PoolingMode.MAX: MaxPooling(),
            PoolingMode.MEAN_SQRT_LEN: MeanSqrtLenPooling(),
        }

        self.embedding_dim: int = self.bert.config.hidden_size

        logger.debug(
            "TextEncoder initialized | pooling=%s | normalize=%s | dim=%d",
            self.pooling_mode,
            self.normalize,
            self.embedding_dim,
        )

    # ── Factory Methods ────────────────────────────────────────────────────

    @classmethod
    def from_pretrained(
        cls,
        model_name_or_path: str = "bert-base-uncased",
        pooling_mode: Union[PoolingMode, str] = PoolingMode.MEAN,
        normalize: bool = True,
        new_vocab_size: Optional[int] = None,
    ) -> "TextEncoder":
        """
        Load a TextEncoder from a pretrained BERT model.

        Args:
            model_name_or_path: HuggingFace model ID or local path.
            pooling_mode: Pooling strategy for sentence embeddings.
            normalize: Whether to L2-normalize output embeddings.
            new_vocab_size: If provided, resizes the token embedding matrix
                (required after adding new tokens to the tokenizer).

        Returns:
            Initialized TextEncoder.
        """
        logger.info("Loading BERT model: %s", model_name_or_path)
        bert_model = BertModel.from_pretrained(
            model_name_or_path,
            output_hidden_states=False,
        )

        # Resize embedding if vocabulary was extended
        if new_vocab_size is not None:
            bert_model.resize_token_embeddings(new_vocab_size)
            logger.info("Resized token embeddings to %d", new_vocab_size)

        instance = cls(
            bert_model=bert_model,
            pooling_mode=pooling_mode,
            normalize=normalize,
        )
        logger.info(
            "TextEncoder ready | model=%s | dim=%d",
            model_name_or_path,
            instance.embedding_dim,
        )
        return instance

    @classmethod
    def load(cls, save_directory: Union[str, Path]) -> "TextEncoder":
        """
        Load a previously saved TextEncoder from disk.

        Args:
            save_directory: Directory created by `save()`.

        Returns:
            Restored TextEncoder instance.
        """
        import json

        save_dir = Path(save_directory)
        logger.info("Loading TextEncoder from: %s", save_dir)

        bert_model = BertModel.from_pretrained(str(save_dir))

        meta_path = save_dir / "encoder_meta.json"
        pooling_mode = PoolingMode.MEAN
        normalize = True
        if meta_path.exists():
            with open(meta_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
            pooling_mode = PoolingMode(meta.get("pooling_mode", "mean"))
            normalize = meta.get("normalize", True)

        return cls(bert_model=bert_model, pooling_mode=pooling_mode, normalize=normalize)

    # ── Forward / Encoding ─────────────────────────────────────────────────

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Forward pass: encode tokenized input to sentence embedding.

        Args:
            input_ids: Token IDs [batch, seq_len].
            attention_mask: Attention mask [batch, seq_len].
            token_type_ids: Optional segment IDs [batch, seq_len].

        Returns:
            Sentence embeddings [batch, embedding_dim].
        """
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )

        if self.pooling_mode == PoolingMode.CLS:
            # [CLS] token embedding (first token)
            embeddings = outputs.last_hidden_state[:, 0, :]
        else:
            pooler = self._poolers[self.pooling_mode]
            embeddings = pooler(outputs.last_hidden_state, attention_mask)

        if self.normalize:
            embeddings = F.normalize(embeddings, p=2, dim=-1)

        return embeddings

    @torch.no_grad()
    def encode(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Encode tokenized input without gradient computation.

        Args:
            input_ids: Token IDs [batch, seq_len] or [seq_len] for single input.
            attention_mask: Attention mask tensor.
            token_type_ids: Optional segment IDs.

        Returns:
            Embedding tensor [batch, 768] or [768] for single input.
        """
        was_single = input_ids.dim() == 1
        if was_single:
            input_ids = input_ids.unsqueeze(0)
            attention_mask = attention_mask.unsqueeze(0)
            if token_type_ids is not None:
                token_type_ids = token_type_ids.unsqueeze(0)

        self.eval()
        embedding = self.forward(input_ids, attention_mask, token_type_ids)

        if was_single:
            embedding = embedding.squeeze(0)
        return embedding

    def get_hidden_states(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        token_type_ids: Optional[torch.Tensor] = None,
        layer_indices: Optional[List[int]] = None,
    ) -> List[torch.Tensor]:
        """
        Extract hidden states from specified layers of BERT.

        Args:
            input_ids: Token IDs [batch, seq_len].
            attention_mask: Attention mask.
            token_type_ids: Optional segment IDs.
            layer_indices: Indices of layers to return (default: all).

        Returns:
            List of hidden state tensors [batch, seq_len, hidden_size].
        """
        self.bert.config.output_hidden_states = True
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )
        self.bert.config.output_hidden_states = False

        all_hidden = outputs.hidden_states  # Tuple of (num_layers+1) tensors
        if layer_indices is not None:
            return [all_hidden[i] for i in layer_indices]
        return list(all_hidden)

    # ── Model Management ───────────────────────────────────────────────────

    def resize_token_embeddings(self, new_num_tokens: int) -> None:
        """
        Resize the token embedding layer for extended vocabulary.

        Must be called after adding new tokens to the tokenizer.

        Args:
            new_num_tokens: Total vocabulary size after token addition.
        """
        self.bert.resize_token_embeddings(new_num_tokens)
        logger.info("Token embeddings resized to %d", new_num_tokens)

    def save(self, save_directory: Union[str, Path]) -> None:
        """
        Save the BERT model and encoder metadata to disk.

        Args:
            save_directory: Target directory path.
        """
        import json

        save_dir = Path(save_directory)
        save_dir.mkdir(parents=True, exist_ok=True)
        self.bert.save_pretrained(str(save_dir))

        meta = {
            "pooling_mode": self.pooling_mode.value,
            "normalize": self.normalize,
            "embedding_dim": self.embedding_dim,
        }
        with open(save_dir / "encoder_meta.json", "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2)

        logger.info("TextEncoder saved to: %s", save_dir)

    def to(self, device: Union[str, torch.device]) -> "TextEncoder":  # type: ignore[override]
        """Move encoder to specified device."""
        super().to(device)
        return self

    # ── Properties ────────────────────────────────────────────────────────

    @property
    def num_parameters(self) -> int:
        """Total number of trainable parameters."""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    @property
    def config(self) -> BertConfig:
        """BERT model configuration."""
        return self.bert.config

    def __repr__(self) -> str:
        return (
            f"TextEncoder("
            f"pooling={self.pooling_mode.value}, "
            f"normalize={self.normalize}, "
            f"dim={self.embedding_dim}, "
            f"params={self.num_parameters:,})"
        )
