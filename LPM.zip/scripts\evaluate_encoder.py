"""
evaluate_encoder.py
===================
RF-AI2MMUM Language Processing Module — Scripts
Member B: NLP Engineer & Language Module Developer

Evaluate the text encoder on:
  - Perplexity on the evaluation corpus
  - Semantic similarity coherence (intra-domain vs cross-domain similarity)
  - Embedding space analysis (mean norm, variance, clustering quality)
  - Top-K retrieval accuracy for known similar pairs

Usage:
    python scripts/evaluate_encoder.py \\
        --model_path bert-base-uncased \\
        --eval_corpus data/telecom_corpus/sample_corpus.txt

    python scripts/evaluate_encoder.py \\
        --model_path outputs/dapt_model \\
        --eval_corpus data/telecom_corpus/sample_corpus.txt \\
        --compare_base bert-base-uncased
"""

from __future__ import annotations

import argparse
import json
import logging
import math
import sys
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import torch
import torch.nn.functional as F

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from language_module import LanguageEmbeddingInterface
from language_module.utils.corpus_utils import load_corpus_lines
from language_module.utils.embedding_utils import (
    compute_cosine_similarity_matrix,
    reduce_dimensionality,
)
from language_module.utils.logging_utils import setup_logging

logger = logging.getLogger("language_module.scripts.evaluate_encoder")


# ─── Known Similar Pairs for Retrieval Evaluation ────────────────────────────

KNOWN_SIMILAR_PAIRS = [
    (
        "Configure OFDM subcarrier spacing for 5G NR",
        "Set OFDM numerology parameters in NR system",
    ),
    (
        "Massive MIMO beamforming optimization",
        "Beamforming weight design for large antenna arrays",
    ),
    (
        "Channel estimation using pilot signals",
        "Estimate CSI from pilot observations in OFDM",
    ),
    (
        "LDPC channel coding for error correction",
        "Low-density parity-check encoding for reliable transmission",
    ),
    (
        "Non-orthogonal multiple access power allocation",
        "NOMA user power splitting for simultaneous transmission",
    ),
]

DOMAIN_SPECIFIC_TERMS = [
    "OFDM", "MIMO", "beamforming", "5G NR", "mmWave", "LDPC",
    "polar code", "HARQ", "NOMA", "precoding", "channel estimation",
]

GENERAL_TERMS = [
    "weather forecast", "cooking recipe", "stock market", "traffic jam",
    "movie review", "restaurant recommendation",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="RF-AI2MMUM Encoder Evaluation",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--model_path",
        type=str,
        default="bert-base-uncased",
        help="Path to the encoder to evaluate.",
    )
    parser.add_argument(
        "--compare_base",
        type=str,
        default=None,
        help="Optional: base model to compare against (e.g., bert-base-uncased).",
    )
    parser.add_argument(
        "--eval_corpus",
        type=str,
        default="data/telecom_corpus/sample_corpus.txt",
        help="Path to evaluation corpus.",
    )
    parser.add_argument(
        "--output_file",
        type=str,
        default="outputs/evaluation_results.json",
        help="Path to save evaluation results JSON.",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cpu",
        choices=["cuda", "cpu", "mps"],
    )
    parser.add_argument(
        "--log_level",
        type=str,
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
    )
    return parser.parse_args()


def evaluate_similarity_coherence(
    interface: LanguageEmbeddingInterface,
    similar_pairs: List[Tuple[str, str]],
) -> Dict[str, float]:
    """
    Evaluate cosine similarity on known similar text pairs.

    Args:
        interface: Language embedding interface.
        similar_pairs: List of (text_a, text_b) similar pairs.

    Returns:
        Dict with mean_similar_pair_similarity.
    """
    similarities = []
    for text_a, text_b in similar_pairs:
        emb_a = interface.get_task_embedding(text_a)
        emb_b = interface.get_task_embedding(text_b)
        sim = interface.compute_similarity(emb_a, emb_b)
        similarities.append(sim)
        logger.debug("  Pair similarity: %.4f | '%s'", sim, text_a[:40])

    return {
        "mean_similar_pair_similarity": float(np.mean(similarities)),
        "min_similar_pair_similarity": float(np.min(similarities)),
        "max_similar_pair_similarity": float(np.max(similarities)),
        "std_similar_pair_similarity": float(np.std(similarities)),
    }


def evaluate_domain_specificity(
    interface: LanguageEmbeddingInterface,
    domain_terms: List[str],
    general_terms: List[str],
) -> Dict[str, float]:
    """
    Evaluate how well embeddings separate domain-specific from general text.

    Computes mean intra-domain similarity vs mean cross-domain similarity.

    Args:
        interface: Language embedding interface.
        domain_terms: Domain-specific text samples.
        general_terms: General/out-of-domain text samples.

    Returns:
        Dict with intra/cross-domain similarity metrics.
    """
    domain_embs = interface.get_batch_embeddings(domain_terms)
    general_embs = interface.get_batch_embeddings(general_terms)

    # Intra-domain similarity
    intra_sim = compute_cosine_similarity_matrix(domain_embs)
    n = intra_sim.shape[0]
    mask = ~torch.eye(n, dtype=torch.bool)
    mean_intra = intra_sim[mask].mean().item()

    # Cross-domain similarity
    cross_sim = compute_cosine_similarity_matrix(domain_embs, general_embs)
    mean_cross = cross_sim.mean().item()

    return {
        "mean_intra_domain_similarity": float(mean_intra),
        "mean_cross_domain_similarity": float(mean_cross),
        "domain_separation_score": float(mean_intra - mean_cross),
    }


def evaluate_embedding_statistics(
    interface: LanguageEmbeddingInterface,
    corpus: List[str],
) -> Dict[str, float]:
    """
    Compute statistics of the embedding space over the corpus.

    Args:
        interface: Language embedding interface.
        corpus: List of corpus sentences.

    Returns:
        Dict with embedding space statistics.
    """
    embeddings = interface.get_batch_embeddings(corpus[:50])  # Sample 50 sentences

    norms = embeddings.norm(dim=-1).numpy()
    # Compute mean pairwise similarity
    sim_matrix = compute_cosine_similarity_matrix(embeddings)
    n = sim_matrix.shape[0]
    mask = ~torch.eye(n, dtype=torch.bool)
    mean_sim = sim_matrix[mask].mean().item()
    std_sim = sim_matrix[mask].std().item()

    return {
        "mean_embedding_norm": float(norms.mean()),
        "std_embedding_norm": float(norms.std()),
        "mean_pairwise_similarity": float(mean_sim),
        "std_pairwise_similarity": float(std_sim),
        "num_evaluated_sentences": len(corpus[:50]),
    }


def main() -> None:
    """Main evaluation entry point."""
    args = parse_args()
    setup_logging(level=args.log_level)

    logger.info("=" * 65)
    logger.info("RF-AI2MMUM Encoder Evaluation")
    logger.info("=" * 65)
    logger.info("Model: %s", args.model_path)

    # Load interface
    interface = LanguageEmbeddingInterface(
        model_name_or_path=args.model_path,
        device=args.device,
        normalize_embeddings=True,
    )

    # Load corpus
    corpus = load_corpus_lines(args.eval_corpus, min_length=20)
    logger.info("Corpus loaded: %d sentences", len(corpus))

    results: Dict = {
        "model_path": args.model_path,
        "num_corpus_sentences": len(corpus),
        "model_info": interface.get_model_info(),
    }

    # 1. Similarity Coherence
    logger.info("")
    logger.info("1. Evaluating similarity coherence on known similar pairs...")
    coherence = evaluate_similarity_coherence(interface, KNOWN_SIMILAR_PAIRS)
    results["similarity_coherence"] = coherence
    logger.info("   Mean similar-pair similarity: %.4f", coherence["mean_similar_pair_similarity"])

    # 2. Domain Specificity
    logger.info("")
    logger.info("2. Evaluating domain specificity...")
    domain_spec = evaluate_domain_specificity(interface, DOMAIN_SPECIFIC_TERMS, GENERAL_TERMS)
    results["domain_specificity"] = domain_spec
    logger.info("   Intra-domain similarity:  %.4f", domain_spec["mean_intra_domain_similarity"])
    logger.info("   Cross-domain similarity:  %.4f", domain_spec["mean_cross_domain_similarity"])
    logger.info("   Domain separation score:  %.4f", domain_spec["domain_separation_score"])

    # 3. Embedding Space Statistics
    logger.info("")
    logger.info("3. Computing embedding space statistics...")
    emb_stats = evaluate_embedding_statistics(interface, corpus)
    results["embedding_statistics"] = emb_stats
    logger.info("   Mean embedding norm:       %.4f", emb_stats["mean_embedding_norm"])
    logger.info("   Mean pairwise similarity:  %.4f", emb_stats["mean_pairwise_similarity"])

    # 4. Optional: Compare with base model
    if args.compare_base is not None:
        logger.info("")
        logger.info("4. Comparing with base model: %s", args.compare_base)
        base_interface = LanguageEmbeddingInterface(
            model_name_or_path=args.compare_base,
            device=args.device,
            normalize_embeddings=True,
        )
        base_coherence = evaluate_similarity_coherence(base_interface, KNOWN_SIMILAR_PAIRS)
        base_domain = evaluate_domain_specificity(base_interface, DOMAIN_SPECIFIC_TERMS, GENERAL_TERMS)

        results["base_model_comparison"] = {
            "base_model": args.compare_base,
            "base_mean_similar_pair_sim": base_coherence["mean_similar_pair_similarity"],
            "adapted_mean_similar_pair_sim": coherence["mean_similar_pair_similarity"],
            "improvement_similarity": (
                coherence["mean_similar_pair_similarity"]
                - base_coherence["mean_similar_pair_similarity"]
            ),
            "base_domain_separation": base_domain["domain_separation_score"],
            "adapted_domain_separation": domain_spec["domain_separation_score"],
        }
        comp = results["base_model_comparison"]
        logger.info("   Base similar-pair sim:     %.4f", comp["base_mean_similar_pair_sim"])
        logger.info("   Adapted similar-pair sim:  %.4f", comp["adapted_mean_similar_pair_sim"])
        logger.info("   Improvement:               %+.4f", comp["improvement_similarity"])

    # Save results
    out_path = Path(args.output_file)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(results, f, indent=2)

    logger.info("")
    logger.info("Evaluation complete!")
    logger.info("Results saved to: %s", out_path)


if __name__ == "__main__":
    main()
