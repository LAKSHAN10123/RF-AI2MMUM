"""
test_dapt_trainer.py
====================
RF-AI2MMUM Language Processing Module — Unit Tests
Member B: NLP Engineer & Language Module Developer

Unit tests for DAPTTrainer:
  - DAPTConfig defaults and field overrides
  - Corpus loading and preprocessing
  - Training arguments construction
  - Device resolution
  - Perplexity computation
  - Model saving
"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch, call

import pytest
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from language_module.dapt_trainer import DAPTTrainer, DAPTConfig, DAPTProgressCallback


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def sample_corpus(tmp_path) -> Path:
    """Create a minimal corpus file for testing."""
    corpus_path = tmp_path / "test_corpus.txt"
    corpus_path.write_text(
        "# Header comment — should be ignored\n"
        "Orthogonal frequency division multiplexing is used in 5G NR systems.\n"
        "Massive MIMO systems deploy large antenna arrays at base stations.\n"
        "LDPC codes achieve near-Shannon capacity for forward error correction.\n"
        "Beamforming concentrates radiated power toward intended receivers.\n"
        "Channel estimation uses pilot signals for accurate CSI acquisition.\n"
        "The Doppler effect causes frequency shifts due to user mobility.\n"
        "Path loss increases with distance and frequency in wireless channels.\n"
        "Adaptive modulation selects MCS based on received SNR feedback.\n"
        "Interference management improves cell-edge user throughput.\n"
        "Non-orthogonal multiple access enables higher spectral efficiency.\n",
        encoding="utf-8",
    )
    return corpus_path


@pytest.fixture
def minimal_config(tmp_path, sample_corpus) -> DAPTConfig:
    """Minimal DAPTConfig for fast unit testing."""
    return DAPTConfig(
        corpus_path=str(sample_corpus),
        output_dir=str(tmp_path / "dapt_output"),
        num_epochs=1,
        per_device_train_batch_size=2,
        per_device_eval_batch_size=2,
        max_seq_length=64,
        save_steps=1000,
        eval_steps=1000,
        logging_steps=1000,
        device="cpu",
        fp16=False,
        early_stopping_enabled=False,
        gradient_accumulation_steps=1,
    )


@pytest.fixture
def trainer(minimal_config) -> DAPTTrainer:
    return DAPTTrainer(
        model_name="bert-base-uncased",
        config=minimal_config,
    )


# ─── Tests: DAPTConfig ───────────────────────────────────────────────────────

class TestDAPTConfig:
    def test_default_values(self):
        config = DAPTConfig()
        assert config.num_epochs == 5
        assert config.mlm_probability == 0.15
        assert config.learning_rate == pytest.approx(2e-5)
        assert config.validation_split == pytest.approx(0.1)

    def test_custom_values(self, sample_corpus, tmp_path):
        config = DAPTConfig(
            corpus_path=str(sample_corpus),
            num_epochs=10,
            mlm_probability=0.2,
            learning_rate=1e-4,
        )
        assert config.num_epochs == 10
        assert config.mlm_probability == pytest.approx(0.2)
        assert config.learning_rate == pytest.approx(1e-4)

    def test_whole_word_masking_default(self):
        config = DAPTConfig()
        assert config.whole_word_masking is True

    def test_seed_default(self):
        config = DAPTConfig()
        assert config.seed == 42


# ─── Tests: DAPTTrainer Initialization ────────────────────────────────────────

class TestDAPTTrainerInit:
    def test_trainer_initializes(self, trainer):
        assert trainer is not None

    def test_model_is_bert_for_masked_lm(self, trainer):
        from transformers import BertForMaskedLM
        assert isinstance(trainer.model, BertForMaskedLM)

    def test_device_is_cpu(self, trainer):
        assert trainer.device.type == "cpu"

    def test_tokenizer_is_set(self, trainer):
        from language_module.task_tokenizer import TelecomTaskTokenizer
        assert isinstance(trainer.tokenizer, TelecomTaskTokenizer)

    def test_model_on_correct_device(self, trainer):
        param = next(trainer.model.parameters())
        assert param.device.type == trainer.device.type

    def test_config_corpus_path_valid(self, trainer, sample_corpus):
        assert trainer.config.corpus_path == str(sample_corpus)


# ─── Tests: Dataset Preparation ─────────────────────────────────────────────

class TestDatasetPreparation:
    def test_prepare_datasets_returns_dataset_dict(self, trainer):
        from datasets import DatasetDict
        dataset = trainer._prepare_datasets()
        assert isinstance(dataset, DatasetDict)

    def test_train_split_exists(self, trainer):
        dataset = trainer._prepare_datasets()
        assert "train" in dataset

    def test_validation_split_exists(self, trainer):
        dataset = trainer._prepare_datasets()
        assert "validation" in dataset

    def test_train_split_non_empty(self, trainer):
        dataset = trainer._prepare_datasets()
        assert len(dataset["train"]) > 0

    def test_tokenized_input_ids_present(self, trainer):
        dataset = trainer._prepare_datasets()
        assert "input_ids" in dataset["train"].column_names

    def test_attention_mask_present(self, trainer):
        dataset = trainer._prepare_datasets()
        assert "attention_mask" in dataset["train"].column_names

    def test_missing_corpus_raises(self, minimal_config):
        config = DAPTConfig(
            corpus_path="/nonexistent/corpus.txt",
            num_epochs=1,
            device="cpu",
            fp16=False,
        )
        trainer = DAPTTrainer(model_name="bert-base-uncased", config=config)
        with pytest.raises(FileNotFoundError):
            trainer._prepare_datasets()


# ─── Tests: Training Arguments ────────────────────────────────────────────────

class TestTrainingArguments:
    def test_build_training_args(self, trainer):
        args = trainer._build_training_arguments()
        assert args is not None

    def test_output_dir_set(self, trainer):
        args = trainer._build_training_arguments()
        assert args.output_dir == trainer.config.output_dir

    def test_num_epochs_set(self, trainer):
        args = trainer._build_training_arguments()
        assert args.num_train_epochs == trainer.config.num_epochs

    def test_fp16_false_on_cpu(self, trainer):
        """FP16 should be disabled when device is CPU."""
        args = trainer._build_training_arguments()
        assert args.fp16 is False


# ─── Tests: Device Resolution ─────────────────────────────────────────────────

class TestDeviceResolution:
    def test_cpu_device(self):
        device = DAPTTrainer._resolve_device("cpu")
        assert device.type == "cpu"

    def test_cuda_fallback_to_cpu(self):
        """When CUDA unavailable, should fall back to CPU without raising."""
        with patch("torch.cuda.is_available", return_value=False):
            device = DAPTTrainer._resolve_device("cuda")
            assert device.type == "cpu"

    def test_cuda_when_available(self):
        with patch("torch.cuda.is_available", return_value=True):
            device = DAPTTrainer._resolve_device("cuda")
            assert device.type == "cuda"


# ─── Tests: Perplexity Computation ───────────────────────────────────────────

class TestPerplexityComputation:
    def test_perplexity_is_positive_float(self, trainer):
        texts = [
            "Orthogonal frequency division multiplexing uses cyclic prefix.",
            "Massive MIMO exploits spatial diversity through large antenna arrays.",
        ]
        ppl = trainer.compute_perplexity(texts)
        assert isinstance(ppl, float)
        assert ppl > 0.0

    def test_perplexity_finite(self, trainer):
        """Perplexity should not be infinity or NaN."""
        texts = ["LDPC codes provide near-capacity performance for 5G NR."]
        ppl = trainer.compute_perplexity(texts)
        import math
        assert math.isfinite(ppl)


# ─── Tests: Save Model ───────────────────────────────────────────────────────

class TestSaveModel:
    def test_save_model_creates_directory(self, trainer, tmp_path):
        save_dir = tmp_path / "saved_dapt"
        trainer.save_model(str(save_dir))
        assert save_dir.exists()

    def test_save_model_creates_config_json(self, trainer, tmp_path):
        save_dir = tmp_path / "saved_dapt_check"
        trainer.save_model(str(save_dir))
        assert (save_dir / "config.json").exists()

    def test_save_model_creates_dapt_meta(self, trainer, tmp_path):
        save_dir = tmp_path / "saved_dapt_meta"
        trainer.save_model(str(save_dir))
        assert (save_dir / "dapt_meta.json").exists()

    def test_dapt_meta_contains_corpus_path(self, trainer, tmp_path):
        save_dir = tmp_path / "saved_dapt_meta2"
        trainer.save_model(str(save_dir))
        with open(save_dir / "dapt_meta.json") as f:
            meta = json.load(f)
        assert "dapt_config" in meta
        assert "corpus_path" in meta["dapt_config"]

    def test_save_model_saves_tokenizer(self, trainer, tmp_path):
        save_dir = tmp_path / "saved_dapt_tok"
        trainer.save_model(str(save_dir))
        assert (save_dir / "tokenizer").exists()


# ─── Tests: DAPTProgressCallback ─────────────────────────────────────────────

class TestDAPTProgressCallback:
    def test_callback_computes_perplexity(self):
        callback = DAPTProgressCallback()
        mock_args = MagicMock()
        mock_state = MagicMock()
        mock_state.global_step = 100
        mock_control = MagicMock()
        logs = {"eval_loss": 3.0}

        callback.on_log(mock_args, mock_state, mock_control, logs=logs)
        assert "eval_perplexity" in logs
        assert logs["eval_perplexity"] == pytest.approx(20.086, rel=1e-2)

    def test_callback_handles_none_logs(self):
        """Callback should handle None logs gracefully."""
        callback = DAPTProgressCallback()
        mock_args = MagicMock()
        mock_state = MagicMock()
        mock_control = MagicMock()
        # Should not raise
        callback.on_log(mock_args, mock_state, mock_control, logs=None)
