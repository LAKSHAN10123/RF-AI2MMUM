"""
embedding_utils.py
==================
RF-AI2MMUM Language Processing Module — Member B

Utilities for managing, manipulating, and analyzing dense embedding vectors
produced by the TextEncoder. Includes storage, similarity computation,
dimensionality reduction, and clustering.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
import torch
import torch.nn.functional as F

logger = logging.getLogger(__name__)


# ─── Standalone Functions ─────────────────────────────────────────────────────

def compute_cosine_similarity_matrix(
    embeddings_a: torch.Tensor,
    embeddings_b: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """
    Compute pairwise cosine similarity matrix between two sets of embeddings.

    If `embeddings_b` is None, computes self-similarity of `embeddings_a`.

    Args:
        embeddings_a: Tensor of shape [N, dim].
        embeddings_b: Optional tensor of shape [M, dim]. If None, uses `a`.

    Returns:
        Cosine similarity matrix of shape [N, M] or [N, N].
    """
    a = F.normalize(embeddings_a.float(), p=2, dim=-1)
    if embeddings_b is None:
        return torch.mm(a, a.T)
    b = F.normalize(embeddings_b.float(), p=2, dim=-1)
    return torch.mm(a, b.T)


def reduce_dimensionality(
    embeddings: Union[torch.Tensor, np.ndarray],
    method: str = "pca",
    n_components: int = 2,
    random_state: int = 42,
) -> np.ndarray:
    """
    Reduce embedding dimensionality for visualization or analysis.

    Args:
        embeddings: Embedding matrix [N, dim] (torch.Tensor or np.ndarray).
        method: Reduction method: "pca", "tsne", or "umap".
        n_components: Target dimensionality.
        random_state: Random seed for reproducibility.

    Returns:
        Reduced embedding array of shape [N, n_components].
    """
    if isinstance(embeddings, torch.Tensor):
        emb_np = embeddings.cpu().numpy()
    else:
        emb_np = embeddings

    if method == "pca":
        from sklearn.decomposition import PCA
        reducer = PCA(n_components=n_components, random_state=random_state)
    elif method == "tsne":
        from sklearn.manifold import TSNE
        reducer = TSNE(n_components=n_components, random_state=random_state, perplexity=min(30, len(emb_np) - 1))
    elif method == "umap":
        try:
            import umap
            reducer = umap.UMAP(n_components=n_components, random_state=random_state)
        except ImportError:
            logger.warning("UMAP not installed. Falling back to PCA.")
            from sklearn.decomposition import PCA
            reducer = PCA(n_components=n_components, random_state=random_state)
    else:
        raise ValueError(f"Unknown reduction method: {method}. Use 'pca', 'tsne', or 'umap'.")

    return reducer.fit_transform(emb_np)


def cluster_embeddings(
    embeddings: Union[torch.Tensor, np.ndarray],
    n_clusters: int = 5,
    method: str = "kmeans",
    random_state: int = 42,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Cluster embeddings using sklearn clustering algorithms.

    Args:
        embeddings: Embedding matrix [N, dim].
        n_clusters: Number of clusters.
        method: Clustering method: "kmeans" or "agglomerative".
        random_state: Random seed.

    Returns:
        Tuple of (cluster_labels [N], cluster_centers [n_clusters, dim]).
    """
    if isinstance(embeddings, torch.Tensor):
        emb_np = embeddings.cpu().numpy()
    else:
        emb_np = embeddings

    if method == "kmeans":
        from sklearn.cluster import KMeans
        clusterer = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=10)
        labels = clusterer.fit_predict(emb_np)
        centers = clusterer.cluster_centers_
    elif method == "agglomerative":
        from sklearn.cluster import AgglomerativeClustering
        clusterer = AgglomerativeClustering(n_clusters=n_clusters)
        labels = clusterer.fit_predict(emb_np)
        # Compute cluster centroids
        centers = np.array([
            emb_np[labels == k].mean(axis=0) for k in range(n_clusters)
        ])
    else:
        raise ValueError(f"Unknown clustering method: {method}. Use 'kmeans' or 'agglomerative'.")

    return labels, centers


# ─── EmbeddingStore ───────────────────────────────────────────────────────────

class EmbeddingStore:
    """
    Persistent storage for named embedding vectors.

    Supports save/load to disk, similarity search, and metadata tracking.
    Designed for building task embedding libraries for the RF module.

    Attributes:
        embeddings (Dict[str, torch.Tensor]): Name-to-embedding mapping.
        metadata (Dict[str, dict]): Optional metadata for each embedding.
    """

    def __init__(self) -> None:
        """Initialize an empty EmbeddingStore."""
        self.embeddings: Dict[str, torch.Tensor] = {}
        self.metadata: Dict[str, dict] = {}

    def add(
        self,
        name: str,
        embedding: torch.Tensor,
        metadata: Optional[dict] = None,
    ) -> None:
        """
        Add a named embedding to the store.

        Args:
            name: Unique identifier for this embedding.
            embedding: Embedding tensor [dim].
            metadata: Optional metadata dict (e.g., source text, timestamp).
        """
        self.embeddings[name] = embedding.cpu()
        self.metadata[name] = metadata or {}

    def add_batch(
        self,
        names: List[str],
        embeddings: torch.Tensor,
        metadata_list: Optional[List[dict]] = None,
    ) -> None:
        """
        Add multiple named embeddings from a batch tensor.

        Args:
            names: List of unique identifiers.
            embeddings: Batch of embeddings [N, dim].
            metadata_list: Optional list of metadata dicts.
        """
        if len(names) != embeddings.shape[0]:
            raise ValueError(
                f"Length mismatch: {len(names)} names but {embeddings.shape[0]} embeddings"
            )
        for i, name in enumerate(names):
            meta = metadata_list[i] if metadata_list else {}
            self.add(name, embeddings[i], meta)

    def get(self, name: str) -> torch.Tensor:
        """
        Retrieve an embedding by name.

        Args:
            name: Key to look up.

        Returns:
            Embedding tensor [dim].

        Raises:
            KeyError if name not in store.
        """
        if name not in self.embeddings:
            raise KeyError(f"Embedding '{name}' not found in store.")
        return self.embeddings[name]

    def search(
        self,
        query: torch.Tensor,
        top_k: int = 5,
        return_scores: bool = True,
    ) -> List[Tuple[str, float]]:
        """
        Find the top-k most similar stored embeddings to a query.

        Args:
            query: Query embedding tensor [dim].
            top_k: Number of results to return.
            return_scores: Whether to include similarity scores.

        Returns:
            List of (name, similarity_score) tuples.
        """
        if not self.embeddings:
            return []

        names = list(self.embeddings.keys())
        stored = torch.stack([self.embeddings[n] for n in names])

        q = F.normalize(query.float().unsqueeze(0), p=2, dim=-1)
        s = F.normalize(stored.float(), p=2, dim=-1)
        sims = torch.mm(q, s.T).squeeze(0)

        k = min(top_k, len(names))
        top_vals, top_idxs = torch.topk(sims, k)

        # Clamp to valid cosine similarity range [-1, 1].
        # Float32 dot-products on pre-normalized vectors can produce values
        # like 1.0000000238 due to rounding — clamping corrects this.
        top_vals = top_vals.clamp(-1.0, 1.0)

        return [(names[i], float(top_vals[j])) for j, i in enumerate(top_idxs.tolist())]

    def get_all_embeddings(self) -> Tuple[List[str], torch.Tensor]:
        """
        Return all embeddings as a stacked tensor.

        Returns:
            Tuple of (list_of_names, stacked_embeddings [N, dim]).
        """
        names = list(self.embeddings.keys())
        if not names:
            return [], torch.zeros(0, 768)
        stacked = torch.stack([self.embeddings[n] for n in names])
        return names, stacked

    def save(self, save_path: Union[str, Path]) -> None:
        """
        Save the EmbeddingStore to disk.

        Creates two files:
          - `embeddings.pt` — PyTorch tensor archive
          - `metadata.json` — JSON metadata

        Args:
            save_path: Directory or file path.
        """
        save_path = Path(save_path)
        if save_path.suffix:  # File path given — use parent dir
            save_dir = save_path.parent
            base_name = save_path.stem
        else:
            save_dir = save_path
            base_name = "embedding_store"

        save_dir.mkdir(parents=True, exist_ok=True)

        torch.save(
            {name: emb for name, emb in self.embeddings.items()},
            save_dir / f"{base_name}.pt",
        )

        meta_out = {
            name: {"meta": self.metadata.get(name, {})}
            for name in self.embeddings
        }
        with open(save_dir / f"{base_name}_meta.json", "w") as f:
            json.dump(meta_out, f, indent=2)

        logger.info("EmbeddingStore saved: %d embeddings to %s", len(self.embeddings), save_dir)

    @classmethod
    def load(cls, save_path: Union[str, Path]) -> "EmbeddingStore":
        """
        Load an EmbeddingStore from disk.

        Args:
            save_path: Directory or file path (same as passed to save()).

        Returns:
            Restored EmbeddingStore instance.
        """
        save_path = Path(save_path)
        if save_path.suffix == ".pt":
            pt_path = save_path
            base_name = save_path.stem
            meta_path = save_path.parent / f"{base_name}_meta.json"
        else:
            # Directory — find .pt file
            pt_files = list(save_path.glob("*.pt"))
            if not pt_files:
                raise FileNotFoundError(f"No .pt file found in {save_path}")
            pt_path = pt_files[0]
            base_name = pt_path.stem
            meta_path = save_path / f"{base_name}_meta.json"

        instance = cls()
        instance.embeddings = torch.load(pt_path, map_location="cpu")

        if meta_path.exists():
            with open(meta_path) as f:
                meta_data = json.load(f)
            instance.metadata = {name: v.get("meta", {}) for name, v in meta_data.items()}

        logger.info("EmbeddingStore loaded: %d embeddings", len(instance.embeddings))
        return instance

    def __len__(self) -> int:
        return len(self.embeddings)

    def __contains__(self, name: str) -> bool:
        return name in self.embeddings

    def __repr__(self) -> str:
        return f"EmbeddingStore(n_embeddings={len(self.embeddings)})"
