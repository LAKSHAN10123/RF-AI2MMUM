"""
generate_embeddings.py
======================
RF-AI2MMUM Language Processing Module — Scripts
Member B: NLP Engineer & Language Module Developer

Script to generate 768-dimensional embeddings from text files or
command-line text inputs using the trained (or base) language model.

Usage:
    # From a text file
    python scripts/generate_embeddings.py \\
        --input_file data/telecom_corpus/sample_corpus.txt \\
        --output_file outputs/embeddings.pt \\
        --model_path bert-base-uncased

    # From command-line text
    python scripts/generate_embeddings.py \\
        --text "Configure OFDM for 5G NR FR2 mmWave band" \\
        --model_path bert-base-uncased

    # From a text file with DAPT model
    python scripts/generate_embeddings.py \\
        --input_file data/telecom_corpus/sample_corpus.txt \\
        --model_path outputs/dapt_model \\
        --output_file outputs/dapt_embeddings.pt \\
        --batch_size 16 \\
        --device cuda
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import torch

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from language_module import LanguageEmbeddingInterface
from language_module.utils.corpus_utils import load_corpus_lines
from language_module.utils.embedding_utils import EmbeddingStore
from language_module.utils.logging_utils import setup_logging, RichProgressLogger

logger = logging.getLogger("language_module.scripts.generate_embeddings")


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description=(
            "RF-AI2MMUM Embedding Generator — "
            "Generate 768-dim BERT embeddings for RF task descriptions."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # ── Input ─────────────────────────────────────────────────────────────
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument(
        "--input_file",
        type=str,
        help="Path to a text file (one sentence per line).",
    )
    input_group.add_argument(
        "--text",
        type=str,
        help="Single text string to embed (enclose in quotes).",
    )

    # ── Output ────────────────────────────────────────────────────────────
    parser.add_argument(
        "--output_file",
        type=str,
        default="outputs/embeddings.pt",
        help="Output file path for saved embeddings (.pt or .npy).",
    )
    parser.add_argument(
        "--output_format",
        type=str,
        default="pt",
        choices=["pt", "npy", "store"],
        help=(
            "Output format: 'pt' (PyTorch tensor), "
            "'npy' (NumPy array), 'store' (EmbeddingStore)."
        ),
    )

    # ── Model ─────────────────────────────────────────────────────────────
    parser.add_argument(
        "--model_path",
        type=str,
        default="bert-base-uncased",
        help="HuggingFace model ID or path to a DAPT-trained model.",
    )
    parser.add_argument(
        "--tokenizer_path",
        type=str,
        default=None,
        help="Path to saved TelecomTaskTokenizer (optional).",
    )
    parser.add_argument(
        "--vocab_path",
        type=str,
        default="data/telecom_corpus/telecom_vocab.txt",
        help="Path to telecom vocabulary file.",
    )
    parser.add_argument(
        "--pooling_mode",
        type=str,
        default="mean",
        choices=["mean", "cls", "max", "mean_sqrt_len"],
        help="Embedding pooling strategy.",
    )
    parser.add_argument(
        "--normalize",
        action="store_true",
        default=True,
        help="L2-normalize output embeddings.",
    )
    parser.add_argument(
        "--max_seq_length",
        type=int,
        default=512,
        help="Maximum tokenized sequence length.",
    )

    # ── Runtime ───────────────────────────────────────────────────────────
    parser.add_argument(
        "--device",
        type=str,
        default="cpu",
        choices=["cuda", "cpu", "mps"],
        help="Computation device.",
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=32,
        help="Batch size for processing.",
    )
    parser.add_argument(
        "--wrap_task_tokens",
        action="store_true",
        default=False,
        help="Wrap inputs with [TASK]...[/TASK] delimiters.",
    )

    # ── Logging ───────────────────────────────────────────────────────────
    parser.add_argument(
        "--log_level",
        type=str,
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
    )

    return parser.parse_args()


def main() -> None:
    """Main entry point for embedding generation."""
    args = parse_args()
    setup_logging(level=args.log_level)

    logger.info("=" * 60)
    logger.info("RF-AI2MMUM Embedding Generator")
    logger.info("=" * 60)

    # Initialize interface
    logger.info("Loading model: %s", args.model_path)
    vocab_path = args.vocab_path if Path(args.vocab_path).exists() else None

    interface = LanguageEmbeddingInterface(
        model_name_or_path=args.model_path,
        tokenizer_path=args.tokenizer_path,
        telecom_vocab_path=vocab_path,
        device=args.device,
        pooling_mode=args.pooling_mode,
        normalize_embeddings=args.normalize,
        max_seq_length=args.max_seq_length,
        batch_size=args.batch_size,
    )

    logger.info("Model loaded | vocab_size=%d | dim=%d",
                interface.tokenizer.vocab_size, interface.embedding_dim)

    # ── Single text mode ───────────────────────────────────────────────────
    if args.text is not None:
        logger.info("Encoding: '%s'", args.text[:80])
        embedding = interface.get_task_embedding(
            args.text, wrap_task_tokens=args.wrap_task_tokens
        )
        logger.info("Embedding shape: %s", tuple(embedding.shape))
        logger.info("Embedding norm: %.6f", embedding.norm().item())
        logger.info("First 10 dims: %s", embedding[:10].tolist())

        # Save
        out_path = Path(args.output_file)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        if args.output_format == "npy":
            import numpy as np
            np.save(str(out_path), embedding.numpy())
        else:
            torch.save(embedding, str(out_path))
        logger.info("Embedding saved to: %s", out_path)
        return

    # ── File mode ─────────────────────────────────────────────────────────
    logger.info("Loading corpus: %s", args.input_file)
    texts = load_corpus_lines(args.input_file, min_length=10)
    logger.info("Loaded %d sentences", len(texts))

    if not texts:
        logger.error("No valid sentences found in input file!")
        sys.exit(1)

    # Generate embeddings
    logger.info("Generating embeddings (batch_size=%d)...", args.batch_size)
    with RichProgressLogger("Encoding", total=len(texts), unit="sentence") as pbar:
        all_embeddings = interface.get_batch_embeddings(
            texts,
            wrap_task_tokens=args.wrap_task_tokens,
            show_progress=False,
        )
        pbar.update(len(texts))

    logger.info("Embeddings shape: %s", tuple(all_embeddings.shape))

    # Save
    out_path = Path(args.output_file)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if args.output_format == "npy":
        import numpy as np
        np.save(str(out_path), all_embeddings.numpy())
        logger.info("Saved NumPy array to: %s", out_path)

    elif args.output_format == "store":
        store = EmbeddingStore()
        store.add_batch(
            names=[f"sentence_{i}" for i in range(len(texts))],
            embeddings=all_embeddings,
            metadata_list=[{"text": t} for t in texts],
        )
        store.save(str(out_path))
        logger.info("Saved EmbeddingStore to: %s", out_path)

    else:  # "pt"
        torch.save(all_embeddings, str(out_path))
        logger.info("Saved PyTorch tensor to: %s", out_path)

    logger.info("")
    logger.info("Summary:")
    logger.info("  Texts processed : %d", len(texts))
    logger.info("  Embedding shape : %s", tuple(all_embeddings.shape))
    logger.info("  Output file     : %s", out_path)
    logger.info("  Output format   : %s", args.output_format)
    logger.info("")
    logger.info("Done! Embeddings are ready for Member C integration.")


if __name__ == "__main__":
    main()
