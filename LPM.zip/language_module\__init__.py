"""
RF-AI2MMUM Language Processing Module
======================================
Member B: NLP Engineer & Language Module Developer

Project: RF-AI2MMUM — A Unified RF–Language Multi-Modal Framework for
Intelligent and Generalizable PHY-Layer Processing in 6G Networks

This package provides:
  - TelecomTaskTokenizer   : BERT tokenizer extended with telecom vocabulary
  - TextEncoder            : BERT/SBERT-based 768-dim text encoder
  - DAPTTrainer            : Domain Adaptive Pre-Training via MLM
  - LanguageEmbeddingInterface : Clean API for Member C integration
"""

from language_module.task_tokenizer import TelecomTaskTokenizer
from language_module.text_encoder import TextEncoder
from language_module.dapt_trainer import DAPTTrainer
from language_module.language_embedding_interface import LanguageEmbeddingInterface

__version__ = "1.0.0"
__author__ = "Member B — NLP Engineer & Language Module Developer"
__project__ = "RF-AI2MMUM: Unified RF-Language Multi-Modal Framework for 6G"

__all__ = [
    "TelecomTaskTokenizer",
    "TextEncoder",
    "DAPTTrainer",
    "LanguageEmbeddingInterface",
]
