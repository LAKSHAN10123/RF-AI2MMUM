"""
dapt_trainer.py
===============
RF-AI2MMUM Language Processing Module — Member B

Implements Domain Adaptive Pre-Training (DAPT) for BERT models on
telecom-domain text corpora using Masked Language Modeling (MLM).

Based on: Gururangan et al. (2020) "Don't Stop Pretraining:
Adapt Language Models to Domains and Tasks"

Features:
  - Whole-word masking with configurable mask probability
  - HuggingFace Trainer integration with custom callbacks
  - Training progress tracking and checkpoint management
  - Perplexity evaluation on held-out validation set
  - Early stopping support
  - TensorBoard and wandb logging integration

Usage:
    from language_module.dapt_trainer import DAPTTrainer
    from language_module.task_tokenizer import TelecomTaskTokenizer

    tokenizer = TelecomTaskTokenizer.from_pretrained("bert-base-uncased")

    trainer = DAPTTrainer(
        model_name="bert-base-uncased",
        tokenizer=tokenizer,
        corpus_path="data/telecom_corpus/sample_corpus.txt",
        output_dir="outputs/dapt_model",
    )
    trainer.train(num_epochs=3)
    trainer.save_model()
"""

from __future__ import annotations

import json
import logging
import math
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import numpy as np
import torch
from datasets import Dataset, DatasetDict
from transformers import (
    BertForMaskedLM,
    DataCollatorForLanguageModeling,
    DataCollatorForWholeWordMask,
    EarlyStoppingCallback,
    Trainer,
    TrainerCallback,
    TrainerControl,
    TrainerState,
    TrainingArguments,
)
from transformers import set_seed

from language_module.task_tokenizer import TelecomTaskTokenizer

logger = logging.getLogger(__name__)


# ─── Configuration Dataclass ─────────────────────────────────────────────────

@dataclass
class DAPTConfig:
    """
    Configuration for Domain Adaptive Pre-Training.

    All fields have sensible defaults for the RF-AI2MMUM project.
    Override via keyword arguments when instantiating DAPTTrainer.
    """

    # Paths
    corpus_path: str = "data/telecom_corpus/sample_corpus.txt"
    output_dir: str = "outputs/dapt_model"
    cache_dir: str = "data/processed"

    # Training hyperparameters
    num_epochs: int = 5
    per_device_train_batch_size: int = 8
    per_device_eval_batch_size: int = 16
    learning_rate: float = 2e-5
    weight_decay: float = 0.01
    warmup_ratio: float = 0.1
    lr_scheduler_type: str = "cosine"
    gradient_accumulation_steps: int = 4
    max_grad_norm: float = 1.0
    adam_epsilon: float = 1e-8
    adam_beta1: float = 0.9
    adam_beta2: float = 0.999

    # MLM settings
    mlm_probability: float = 0.15
    whole_word_masking: bool = True

    # Data settings
    max_seq_length: int = 512
    validation_split: float = 0.1
    max_train_samples: Optional[int] = None
    max_val_samples: Optional[int] = None

    # Device settings
    device: str = "cuda"
    fp16: bool = True
    seed: int = 42

    # Checkpointing and logging
    save_steps: int = 500
    eval_steps: int = 500
    logging_steps: int = 100
    save_total_limit: int = 3
    load_best_model_at_end: bool = True
    report_to: str = "none"

    # Early stopping
    early_stopping_patience: int = 5
    early_stopping_enabled: bool = True


# ─── Custom Callbacks ─────────────────────────────────────────────────────────

class DAPTProgressCallback(TrainerCallback):
    """
    Custom callback to log DAPT training progress and perplexity.

    Computes perplexity (exp(eval_loss)) at each evaluation step and
    logs it alongside training metrics for monitoring.
    """

    def on_log(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        logs: Optional[Dict[str, float]] = None,
        **kwargs: Any,
    ) -> None:
        if logs is None:
            return

        if "eval_loss" in logs:
            perplexity = math.exp(min(logs["eval_loss"], 100))
            logs["eval_perplexity"] = perplexity
            logger.info(
                "Step %d | eval_loss=%.4f | eval_perplexity=%.2f",
                state.global_step,
                logs["eval_loss"],
                perplexity,
            )

        if "loss" in logs:
            logger.info(
                "Step %d | train_loss=%.4f | lr=%.2e",
                state.global_step,
                logs["loss"],
                logs.get("learning_rate", 0.0),
            )


class CheckpointMetadataCallback(TrainerCallback):
    """Saves a JSON metadata file alongside each checkpoint."""

    def on_save(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        **kwargs: Any,
    ) -> None:
        checkpoint_dir = Path(args.output_dir) / f"checkpoint-{state.global_step}"
        if checkpoint_dir.exists():
            meta = {
                "global_step": state.global_step,
                "epoch": state.epoch,
                "best_metric": state.best_metric,
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            }
            with open(checkpoint_dir / "checkpoint_meta.json", "w") as f:
                json.dump(meta, f, indent=2)


# ─── DAPTTrainer ─────────────────────────────────────────────────────────────

class DAPTTrainer:
    """
    Domain Adaptive Pre-Training trainer for BERT on telecom corpora.

    Uses Masked Language Modeling (MLM) with whole-word masking to
    adapt a pre-trained BERT model to the telecommunications domain.

    Attributes:
        config (DAPTConfig): Training configuration.
        tokenizer (TelecomTaskTokenizer): Extended tokenizer.
        model (BertForMaskedLM): BERT model for MLM.
        device (torch.device): Computation device.
    """

    def __init__(
        self,
        model_name: str = "bert-base-uncased",
        tokenizer: Optional[TelecomTaskTokenizer] = None,
        corpus_path: Optional[str] = None,
        output_dir: Optional[str] = None,
        config: Optional[DAPTConfig] = None,
        **kwargs: Any,
    ) -> None:
        """
        Initialize DAPTTrainer.

        Args:
            model_name: HuggingFace model ID or local path.
            tokenizer: Pre-built TelecomTaskTokenizer. If None, builds
                a default tokenizer from `model_name`.
            corpus_path: Path to the domain corpus .txt file.
            output_dir: Directory to save trained model.
            config: DAPTConfig instance. If None, creates from defaults
                and `kwargs`.
            **kwargs: Override any DAPTConfig field by name.
        """
        # Build config
        if config is None:
            config_kwargs: Dict[str, Any] = {}
            if corpus_path is not None:
                config_kwargs["corpus_path"] = corpus_path
            if output_dir is not None:
                config_kwargs["output_dir"] = output_dir
            config_kwargs.update(kwargs)
            self.config = DAPTConfig(**config_kwargs)
        else:
            self.config = config

        set_seed(self.config.seed)

        # Resolve device
        self.device = self._resolve_device(self.config.device)
        logger.info("DAPT device: %s", self.device)

        # Tokenizer
        if tokenizer is None:
            logger.info("Building default TelecomTaskTokenizer from: %s", model_name)
            self.tokenizer = TelecomTaskTokenizer.from_pretrained(
                base_model=model_name,
                max_length=self.config.max_seq_length,
            )
        else:
            self.tokenizer = tokenizer

        # Model
        logger.info("Loading BertForMaskedLM: %s", model_name)
        self.model = BertForMaskedLM.from_pretrained(model_name)
        self.model.resize_token_embeddings(self.tokenizer.vocab_size)
        self.model.to(self.device)

        self._trainer: Optional[Trainer] = None
        self._datasets: Optional[DatasetDict] = None

        logger.info(
            "DAPTTrainer ready | model_params=%d | vocab_size=%d",
            sum(p.numel() for p in self.model.parameters()),
            self.tokenizer.vocab_size,
        )

    # ── Public API ─────────────────────────────────────────────────────────

    def train(self, num_epochs: Optional[int] = None) -> Dict[str, float]:
        """
        Run DAPT training.

        Prepares the dataset, configures the HuggingFace Trainer,
        and runs MLM training for the configured number of epochs.

        Args:
            num_epochs: Override number of training epochs from config.

        Returns:
            Dict of final training metrics.
        """
        if num_epochs is not None:
            self.config.num_epochs = num_epochs

        logger.info("=" * 60)
        logger.info("Starting DAPT | corpus=%s | epochs=%d",
                    self.config.corpus_path, self.config.num_epochs)
        logger.info("=" * 60)

        # Prepare datasets
        self._datasets = self._prepare_datasets()
        train_dataset = self._datasets["train"]
        eval_dataset = self._datasets.get("validation")

        # Data collator
        # DataCollatorForWholeWordMask requires offset_mapping in the batch.
        # When whole_word_masking is enabled, _prepare_datasets() already
        # stores offset_mapping columns (return_offsets_mapping=True).
        # Otherwise, fall back to the standard DataCollatorForLanguageModeling.
        if self.config.whole_word_masking:
            data_collator = DataCollatorForWholeWordMask(
                tokenizer=self.tokenizer.tokenizer,
                mlm=True,
                mlm_probability=self.config.mlm_probability,
            )
        else:
            data_collator = DataCollatorForLanguageModeling(
                tokenizer=self.tokenizer.tokenizer,
                mlm=True,
                mlm_probability=self.config.mlm_probability,
            )

        # Training arguments
        training_args = self._build_training_arguments()

        # Callbacks
        callbacks: List[TrainerCallback] = [
            DAPTProgressCallback(),
            CheckpointMetadataCallback(),
        ]
        if self.config.early_stopping_enabled and eval_dataset is not None:
            callbacks.append(
                EarlyStoppingCallback(
                    early_stopping_patience=self.config.early_stopping_patience
                )
            )

        # Build trainer
        self._trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
            data_collator=data_collator,
            callbacks=callbacks,
        )

        # Run training
        train_result = self._trainer.train()
        metrics = train_result.metrics
        metrics["train_samples"] = len(train_dataset)

        logger.info("Training complete | metrics=%s", metrics)
        return metrics

    def evaluate(self) -> Dict[str, float]:
        """
        Evaluate the model on the validation set and compute perplexity.

        Returns:
            Dict of evaluation metrics including perplexity.
        """
        if self._trainer is None or self._datasets is None:
            raise RuntimeError(
                "Call train() before evaluate(), or provide a pre-built Trainer."
            )

        logger.info("Running evaluation...")
        eval_results = self._trainer.evaluate()

        if "eval_loss" in eval_results:
            perplexity = math.exp(min(eval_results["eval_loss"], 100))
            eval_results["perplexity"] = perplexity
            logger.info("Perplexity: %.2f", perplexity)

        return eval_results

    def save_model(self, save_path: Optional[str] = None) -> Path:
        """
        Save the DAPT-adapted model and tokenizer.

        Args:
            save_path: Directory to save to. Defaults to config.output_dir.

        Returns:
            Path to the saved model directory.
        """
        save_dir = Path(save_path or self.config.output_dir)
        save_dir.mkdir(parents=True, exist_ok=True)

        logger.info("Saving DAPT model to: %s", save_dir)

        if self._trainer is not None:
            self._trainer.save_model(str(save_dir))
        else:
            self.model.save_pretrained(str(save_dir))

        # Save tokenizer
        self.tokenizer.save(save_dir / "tokenizer")

        # Save DAPT metadata
        dapt_meta = {
            "model_type": "bert-for-masked-lm",
            "dapt_config": {
                "corpus_path": self.config.corpus_path,
                "num_epochs": self.config.num_epochs,
                "mlm_probability": self.config.mlm_probability,
                "learning_rate": self.config.learning_rate,
            },
            "vocab_size": self.tokenizer.vocab_size,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        with open(save_dir / "dapt_meta.json", "w") as f:
            json.dump(dapt_meta, f, indent=2)

        logger.info("Model saved successfully.")
        return save_dir

    def compute_perplexity(self, texts: List[str]) -> float:
        """
        Compute model perplexity on a list of text strings.

        Args:
            texts: List of text strings.

        Returns:
            Perplexity score (lower is better).
        """
        self.model.eval()
        total_loss = 0.0
        num_batches = 0

        encodings = self.tokenizer.encode_batch(
            texts,
            padding=True,
            truncation=True,
            return_tensors="pt",
        )

        input_ids = encodings["input_ids"].to(self.device)
        attention_mask = encodings["attention_mask"].to(self.device)

        # Create masked labels
        labels = input_ids.clone()
        rand = torch.rand(labels.shape)
        mask_positions = (rand < self.config.mlm_probability) & (attention_mask == 1)
        labels[~mask_positions] = -100
        input_ids_masked = input_ids.clone()
        input_ids_masked[mask_positions] = self.tokenizer.mask_token_id

        with torch.no_grad():
            outputs = self.model(
                input_ids=input_ids_masked,
                attention_mask=attention_mask,
                labels=labels,
            )
            total_loss = outputs.loss.item()

        perplexity = math.exp(min(total_loss, 100))
        return perplexity

    # ── Private Methods ────────────────────────────────────────────────────

    def _prepare_datasets(self) -> DatasetDict:
        """
        Load and preprocess the domain corpus into HuggingFace Datasets.

        Returns:
            DatasetDict with "train" (and optionally "validation") splits.
        """
        corpus_path = Path(self.config.corpus_path)
        if not corpus_path.exists():
            raise FileNotFoundError(f"Corpus file not found: {corpus_path}")

        logger.info("Loading corpus: %s", corpus_path)

        # Load and filter corpus lines
        with open(corpus_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        sentences = [
            line.strip()
            for line in lines
            if line.strip() and not line.strip().startswith("#")
               and not line.strip().startswith("─")
               and len(line.strip()) > 20  # Skip very short lines
        ]

        logger.info("Loaded %d training sentences", len(sentences))

        # Tokenize
        # return_offsets_mapping=True is required by DataCollatorForWholeWordMask
        # to determine word boundaries for whole-word masking.
        def tokenize_function(examples: Dict[str, List[str]]) -> Dict:
            return self.tokenizer.tokenizer(
                examples["text"],
                truncation=True,
                max_length=self.config.max_seq_length,
                padding=False,
                return_special_tokens_mask=True,
                return_offsets_mapping=self.config.whole_word_masking,
            )

        # Create HuggingFace Dataset
        raw_dataset = Dataset.from_dict({"text": sentences})
        tokenized = raw_dataset.map(
            tokenize_function,
            batched=True,
            remove_columns=["text"],
            desc="Tokenizing corpus",
        )

        # Train/validation split
        if self.config.validation_split > 0:
            split = tokenized.train_test_split(
                test_size=self.config.validation_split,
                seed=self.config.seed,
            )
            dataset_dict = DatasetDict({
                "train": split["train"],
                "validation": split["test"],
            })
        else:
            dataset_dict = DatasetDict({"train": tokenized})

        # Apply sample limits
        if self.config.max_train_samples is not None:
            n = min(self.config.max_train_samples, len(dataset_dict["train"]))
            dataset_dict["train"] = dataset_dict["train"].select(range(n))

        if "validation" in dataset_dict and self.config.max_val_samples is not None:
            n = min(self.config.max_val_samples, len(dataset_dict["validation"]))
            dataset_dict["validation"] = dataset_dict["validation"].select(range(n))

        logger.info(
            "Dataset ready | train=%d | val=%d",
            len(dataset_dict["train"]),
            len(dataset_dict.get("validation", [])),
        )
        return dataset_dict

    def _build_training_arguments(self) -> TrainingArguments:
        """
        Build HuggingFace TrainingArguments from DAPTConfig.

        Returns:
            Configured TrainingArguments instance.
        """
        output_dir = Path(self.config.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        # Create log directory
        # logging_dir kwarg was removed in transformers v5.2; set via env-var instead.
        log_dir = output_dir.parent / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        os.environ.setdefault("TENSORBOARD_LOGGING_DIR", str(log_dir))

        use_fp16 = self.config.fp16 and self.device.type == "cuda"

        return TrainingArguments(
            output_dir=str(output_dir),
            num_train_epochs=self.config.num_epochs,
            per_device_train_batch_size=self.config.per_device_train_batch_size,
            per_device_eval_batch_size=self.config.per_device_eval_batch_size,
            learning_rate=self.config.learning_rate,
            weight_decay=self.config.weight_decay,
            warmup_ratio=self.config.warmup_ratio,   # note: deprecated in transformers v5.2 → warmup_steps
            lr_scheduler_type=self.config.lr_scheduler_type,
            gradient_accumulation_steps=self.config.gradient_accumulation_steps,
            max_grad_norm=self.config.max_grad_norm,
            adam_epsilon=self.config.adam_epsilon,
            fp16=use_fp16,
            save_strategy="steps",
            save_steps=self.config.save_steps,
            save_total_limit=self.config.save_total_limit,
            eval_strategy="steps",          # renamed from evaluation_strategy in transformers >=4.41
            eval_steps=self.config.eval_steps,
            logging_steps=self.config.logging_steps,
            load_best_model_at_end=self.config.load_best_model_at_end,
            metric_for_best_model="eval_loss",
            greater_is_better=False,
            report_to=self.config.report_to,
            seed=self.config.seed,
            dataloader_num_workers=0,  # 0 for Windows compatibility
            remove_unused_columns=True,
        )

    @staticmethod
    def _resolve_device(device_str: str) -> torch.device:
        """
        Resolve device string to torch.device, falling back to CPU.

        Args:
            device_str: "cuda", "cpu", or "mps".

        Returns:
            torch.device instance.
        """
        if device_str == "cuda" and torch.cuda.is_available():
            return torch.device("cuda")
        elif device_str == "mps" and torch.backends.mps.is_available():
            return torch.device("mps")
        else:
            if device_str == "cuda":
                logger.warning("CUDA requested but not available — falling back to CPU")
            return torch.device("cpu")
