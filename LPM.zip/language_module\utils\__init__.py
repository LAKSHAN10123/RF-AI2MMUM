"""
RF-AI2MMUM Language Processing Module — Utils Package
Member B: NLP Engineer & Language Module Developer
"""

from language_module.utils.corpus_utils import (
    CorpusLoader,
    CorpusPreprocessor,
    load_corpus_lines,
)
from language_module.utils.embedding_utils import (
    EmbeddingStore,
    compute_cosine_similarity_matrix,
    reduce_dimensionality,
    cluster_embeddings,
)
from language_module.utils.logging_utils import (
    setup_logging,
    get_logger,
    RichProgressLogger,
)

__all__ = [
    "CorpusLoader",
    "CorpusPreprocessor",
    "load_corpus_lines",
    "EmbeddingStore",
    "compute_cosine_similarity_matrix",
    "reduce_dimensionality",
    "cluster_embeddings",
    "setup_logging",
    "get_logger",
    "RichProgressLogger",
]
