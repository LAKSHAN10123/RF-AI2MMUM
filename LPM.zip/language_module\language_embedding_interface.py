"""
language_embedding_interface.py
================================
RF-AI2MMUM Language Processing Module — Member B

Provides a clean, stable API for Member C (RF Signal Module) to consume
768-dimensional language embeddings from the Language Processing Module.

This interface hides all internal complexity (tokenization, model loading,
device management) and exposes only the methods needed for multi-modal fusion.

Design Goals:
  - Single-call task embedding generation
  - Batch processing with automatic chunking for large inputs
  - RF-context-aware task encoding with structured metadata
  - Similarity search over task embedding libraries
  - Seamless CPU/GPU device management
  - Thread-safe for concurrent use in inference servers

Usage:
    from language_module import LanguageEmbeddingInterface

    interface = LanguageEmbeddingInterface(
        model_name_or_path="bert-base-uncased",
        device="cuda"
    )

    # Single task
    emb = interface.get_task_embedding("Configure beamforming for mmWave MIMO")
    # Returns: torch.Tensor shape [768]

    # Batch
    embs = interface.get_batch_embeddings([
        "OFDM channel estimation with pilot symbols",
        "NOMA power allocation optimization",
    ])
    # Returns: torch.Tensor shape [2, 768]

    # With RF context metadata
    result = interface.process_rf_task(
        "Optimize MCS for high SNR channel",
        rf_context={"snr_db": 25.0, "channel_type": "AWGN", "bandwidth_mhz": 100}
    )
"""

from __future__ import annotations

import json
import logging
import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import torch
import torch.nn.functional as F

from language_module.task_tokenizer import TelecomTaskTokenizer, SPECIAL_TOKENS
from language_module.text_encoder import TextEncoder, PoolingMode

logger = logging.getLogger(__name__)


# ─── Result Dataclass ─────────────────────────────────────────────────────────

class TaskEmbeddingResult:
    """
    Container for a processed RF task result.

    Attributes:
        task_description (str): Original task description string.
        embedding (torch.Tensor): 768-dim embedding vector.
        rf_context (dict): RF context metadata.
        tokens (list): Token strings from tokenization.
        token_ids (list): Integer token IDs.
    """

    def __init__(
        self,
        task_description: str,
        embedding: torch.Tensor,
        rf_context: Optional[Dict[str, Any]] = None,
        tokens: Optional[List[str]] = None,
        token_ids: Optional[List[int]] = None,
    ) -> None:
        self.task_description = task_description
        self.embedding = embedding
        self.rf_context = rf_context or {}
        self.tokens = tokens or []
        self.token_ids = token_ids or []

    def to_numpy(self) -> np.ndarray:
        """Convert embedding to NumPy array."""
        return self.embedding.cpu().numpy()

    def to_dict(self) -> Dict[str, Any]:
        """Serialize result to a JSON-compatible dictionary."""
        return {
            "task_description": self.task_description,
            "embedding": self.embedding.cpu().tolist(),
            "rf_context": self.rf_context,
            "embedding_dim": self.embedding.shape[-1],
        }

    def __repr__(self) -> str:
        return (
            f"TaskEmbeddingResult("
            f"task='{self.task_description[:50]}...', "
            f"embedding_shape={tuple(self.embedding.shape)}, "
            f"rf_context={self.rf_context})"
        )


# ─── LanguageEmbeddingInterface ───────────────────────────────────────────────

class LanguageEmbeddingInterface:
    """
    Clean API for consuming 768-dimensional language embeddings.

    This is the primary integration point between Member B's language module
    and Member C's RF signal processing module. All internal complexity is
    hidden behind simple, well-typed methods.

    Attributes:
        tokenizer (TelecomTaskTokenizer): Telecom-extended BERT tokenizer.
        encoder (TextEncoder): BERT/SBERT text encoder.
        device (torch.device): Active computation device.
        embedding_dim (int): Embedding vector dimensionality (768).
    """

    EMBEDDING_DIM: int = 768

    def __init__(
        self,
        model_name_or_path: str = "bert-base-uncased",
        tokenizer_path: Optional[str] = None,
        telecom_vocab_path: Optional[str] = None,
        device: Union[str, torch.device] = "cpu",
        pooling_mode: str = "mean",
        normalize_embeddings: bool = True,
        max_seq_length: int = 512,
        batch_size: int = 32,
    ) -> None:
        """
        Initialize the Language Embedding Interface.

        Args:
            model_name_or_path: HuggingFace model ID or path to a DAPT model.
            tokenizer_path: Path to saved TelecomTaskTokenizer. If None,
                builds from `model_name_or_path` with optional vocab extension.
            telecom_vocab_path: Path to telecom vocab .txt for on-the-fly
                vocabulary extension (used if tokenizer_path is None).
            device: Computation device ("cuda", "cpu", or torch.device).
            pooling_mode: Embedding pooling strategy ("mean", "cls", "max").
            normalize_embeddings: Whether to L2-normalize embeddings.
            max_seq_length: Maximum input sequence length.
            batch_size: Default batch size for batch encoding operations.
        """
        self.device = self._resolve_device(device)
        self.batch_size = batch_size
        self._model_name = model_name_or_path

        logger.info("Initializing LanguageEmbeddingInterface | device=%s", self.device)

        # Build tokenizer
        if tokenizer_path is not None and Path(tokenizer_path).exists():
            logger.info("Loading tokenizer from: %s", tokenizer_path)
            self.tokenizer = TelecomTaskTokenizer.load(tokenizer_path)
        else:
            logger.info("Building tokenizer from: %s", model_name_or_path)
            self.tokenizer = TelecomTaskTokenizer.from_pretrained(
                base_model=model_name_or_path,
                telecom_vocab_path=telecom_vocab_path,
                max_length=max_seq_length,
            )

        # Build encoder
        self.encoder = TextEncoder.from_pretrained(
            model_name_or_path=model_name_or_path,
            pooling_mode=PoolingMode(pooling_mode),
            normalize=normalize_embeddings,
            new_vocab_size=self.tokenizer.vocab_size,
        )
        self.encoder.to(self.device)
        self.encoder.eval()

        self.embedding_dim: int = self.encoder.embedding_dim
        logger.info(
            "LanguageEmbeddingInterface ready | dim=%d | vocab=%d",
            self.embedding_dim,
            self.tokenizer.vocab_size,
        )

    # ── Core Embedding Methods ─────────────────────────────────────────────

    @torch.no_grad()
    def get_task_embedding(
        self,
        task_description: str,
        wrap_task_tokens: bool = True,
    ) -> torch.Tensor:
        """
        Generate a 768-dimensional embedding for a single RF task description.

        This is the primary method for Member C integration. Takes a free-text
        task specification and returns a dense embedding vector.

        Args:
            task_description: Natural language RF processing task description.
                Examples:
                  - "Configure OFDM subcarrier spacing for 5G NR FR2 band"
                  - "Optimize beamforming weights for massive MIMO downlink"
                  - "Estimate channel using LS with pilot pattern A"
            wrap_task_tokens: Whether to prepend [TASK]...[/TASK] delimiters.

        Returns:
            torch.Tensor of shape [768] — normalized embedding on CPU.

        Example:
            >>> interface = LanguageEmbeddingInterface()
            >>> emb = interface.get_task_embedding("Configure 5G NR beamforming")
            >>> emb.shape
            torch.Size([768])
        """
        if wrap_task_tokens:
            encoding = self.tokenizer.encode_task(
                task_description,
                padding=False,
                truncation=True,
                return_tensors="pt",
            )
        else:
            encoding = self.tokenizer.encode_batch(
                [task_description],
                padding=False,
                truncation=True,
                return_tensors="pt",
            )

        input_ids = encoding["input_ids"].to(self.device)
        attention_mask = encoding["attention_mask"].to(self.device)
        token_type_ids = encoding.get("token_type_ids")
        if token_type_ids is not None:
            token_type_ids = token_type_ids.to(self.device)

        embedding = self.encoder.encode(input_ids, attention_mask, token_type_ids)

        # Ensure 1D output for single input
        if embedding.dim() == 2:
            embedding = embedding.squeeze(0)

        return embedding.cpu()

    @torch.no_grad()
    def get_batch_embeddings(
        self,
        texts: List[str],
        wrap_task_tokens: bool = False,
        show_progress: bool = False,
    ) -> torch.Tensor:
        """
        Generate 768-dimensional embeddings for a batch of texts.

        Automatically splits large batches into chunks to avoid OOM errors.

        Args:
            texts: List of text strings to embed.
            wrap_task_tokens: Whether to wrap each text with [TASK]...[/TASK].
            show_progress: Whether to display a progress bar.

        Returns:
            torch.Tensor of shape [len(texts), 768].

        Example:
            >>> embeddings = interface.get_batch_embeddings([
            ...     "OFDM beamforming optimization",
            ...     "Channel estimation with MMSE",
            ... ])
            >>> embeddings.shape
            torch.Size([2, 768])
        """
        if not texts:
            return torch.zeros(0, self.embedding_dim)

        all_embeddings: List[torch.Tensor] = []
        iterator = range(0, len(texts), self.batch_size)

        if show_progress:
            try:
                from tqdm import tqdm
                iterator = tqdm(iterator, desc="Encoding", unit="batch")
            except ImportError:
                pass

        for start_idx in iterator:
            batch = texts[start_idx : start_idx + self.batch_size]
            encoding = self.tokenizer.encode_batch(
                batch,
                padding=True,
                truncation=True,
                return_tensors="pt",
                wrap_with_task_tokens=wrap_task_tokens,
            )
            input_ids = encoding["input_ids"].to(self.device)
            attention_mask = encoding["attention_mask"].to(self.device)
            token_type_ids = encoding.get("token_type_ids")
            if token_type_ids is not None:
                token_type_ids = token_type_ids.to(self.device)

            batch_embs = self.encoder.encode(input_ids, attention_mask, token_type_ids)
            all_embeddings.append(batch_embs.cpu())

        return torch.cat(all_embeddings, dim=0)

    def process_rf_task(
        self,
        task_description: str,
        rf_context: Optional[Dict[str, Any]] = None,
        return_tokens: bool = False,
    ) -> TaskEmbeddingResult:
        """
        Process an RF task description with optional RF context metadata.

        Constructs an enriched task prompt by appending structured RF context
        (SNR, channel type, bandwidth, etc.) to the task description before
        encoding. This allows the embedding to be context-aware.

        Args:
            task_description: Natural language RF task specification.
            rf_context: Optional dict of RF parameters, e.g.:
                {
                    "snr_db": 25.0,
                    "channel_type": "AWGN",
                    "bandwidth_mhz": 100,
                    "modulation": "64QAM",
                    "num_antennas": 64,
                }
            return_tokens: Whether to include token strings in result.

        Returns:
            TaskEmbeddingResult containing embedding and metadata.

        Example:
            >>> result = interface.process_rf_task(
            ...     "Optimize MCS for current channel",
            ...     rf_context={"snr_db": 20.0, "channel_type": "Rayleigh"}
            ... )
            >>> result.embedding.shape
            torch.Size([768])
        """
        # Build enriched task prompt
        enriched_task = self._build_enriched_prompt(task_description, rf_context)

        # Tokenize
        encoding = self.tokenizer.encode_task(
            enriched_task,
            padding=False,
            truncation=True,
            return_tensors="pt",
        )

        # Get tokens if requested
        tokens: List[str] = []
        token_ids: List[int] = []
        if return_tokens:
            tokens = self.tokenizer.tokenize(enriched_task)
            token_ids = encoding["input_ids"].squeeze(0).tolist()

        # Encode
        embedding = self.get_task_embedding(enriched_task, wrap_task_tokens=False)

        return TaskEmbeddingResult(
            task_description=task_description,
            embedding=embedding,
            rf_context=rf_context or {},
            tokens=tokens,
            token_ids=token_ids,
        )

    # ── Similarity Methods ─────────────────────────────────────────────────

    def compute_similarity(
        self,
        embedding_a: torch.Tensor,
        embedding_b: torch.Tensor,
    ) -> float:
        """
        Compute cosine similarity between two embeddings.

        Args:
            embedding_a: First embedding [768].
            embedding_b: Second embedding [768].

        Returns:
            Cosine similarity score in [-1, 1].
        """
        a = F.normalize(embedding_a.unsqueeze(0).float(), p=2, dim=-1)
        b = F.normalize(embedding_b.unsqueeze(0).float(), p=2, dim=-1)
        return float(torch.mm(a, b.T).item())

    def find_most_similar(
        self,
        query: str,
        candidates: List[str],
        top_k: int = 5,
    ) -> List[Tuple[str, float]]:
        """
        Find the top-k most similar candidate tasks to a query task.

        Useful for task retrieval and few-shot learning in the RF module.

        Args:
            query: Query task description string.
            candidates: List of candidate task strings to compare against.
            top_k: Number of top results to return.

        Returns:
            List of (candidate_text, similarity_score) tuples, sorted by
            descending similarity.

        Example:
            >>> results = interface.find_most_similar(
            ...     "Configure OFDM for high mobility channel",
            ...     candidate_tasks,
            ...     top_k=3
            ... )
        """
        query_emb = self.get_task_embedding(query)
        candidate_embs = self.get_batch_embeddings(candidates)

        # Normalize
        q = F.normalize(query_emb.unsqueeze(0).float(), p=2, dim=-1)
        c = F.normalize(candidate_embs.float(), p=2, dim=-1)

        # Cosine similarities
        sims = torch.mm(q, c.T).squeeze(0)
        top_k_actual = min(top_k, len(candidates))
        top_indices = torch.topk(sims, top_k_actual).indices.tolist()

        return [(candidates[i], float(sims[i].item())) for i in top_indices]

    # ── Utility Methods ────────────────────────────────────────────────────

    def tokenize_inspect(self, text: str) -> Dict[str, Any]:
        """
        Inspect how a text string is tokenized.

        Useful for debugging vocabulary coverage and identifying OOV tokens.

        Args:
            text: Text to inspect.

        Returns:
            Dict with token strings, IDs, and vocabulary coverage stats.
        """
        tokens = self.tokenizer.tokenize(text)
        encoding = self.tokenizer.encode_task(text, return_tensors=None)
        token_ids = encoding["input_ids"]

        unk_id = self.tokenizer.tokenizer.unk_token_id
        num_unk = sum(1 for tid in token_ids if tid == unk_id)

        return {
            "text": text,
            "tokens": tokens,
            "token_ids": token_ids,
            "num_tokens": len(tokens),
            "num_unk_tokens": num_unk,
            "unk_rate": num_unk / max(len(tokens), 1),
            "vocab_size": self.tokenizer.vocab_size,
            "special_token_ids": self.tokenizer.get_special_token_ids(),
        }

    def get_model_info(self) -> Dict[str, Any]:
        """
        Return metadata about the loaded model and tokenizer.

        Returns:
            Dict containing model configuration details.
        """
        return {
            "model_name": self._model_name,
            "embedding_dim": self.embedding_dim,
            "vocab_size": self.tokenizer.vocab_size,
            "num_added_tokens": self.tokenizer.num_added_tokens,
            "max_seq_length": self.tokenizer.max_length,
            "pooling_mode": self.encoder.pooling_mode.value,
            "normalize_embeddings": self.encoder.normalize,
            "num_parameters": self.encoder.num_parameters,
            "device": str(self.device),
        }

    def save(self, save_directory: Union[str, Path]) -> None:
        """
        Save the encoder and tokenizer to disk for later loading.

        Args:
            save_directory: Target directory path.
        """
        save_dir = Path(save_directory)
        save_dir.mkdir(parents=True, exist_ok=True)

        self.encoder.save(save_dir / "encoder")
        self.tokenizer.save(save_dir / "tokenizer")

        # Save interface metadata
        meta = {
            "model_name": self._model_name,
            "embedding_dim": self.embedding_dim,
            "batch_size": self.batch_size,
        }
        with open(save_dir / "interface_meta.json", "w") as f:
            json.dump(meta, f, indent=2)

        logger.info("LanguageEmbeddingInterface saved to: %s", save_dir)

    @classmethod
    def load(
        cls,
        save_directory: Union[str, Path],
        device: Union[str, torch.device] = "cpu",
    ) -> "LanguageEmbeddingInterface":
        """
        Load a previously saved LanguageEmbeddingInterface.

        Args:
            save_directory: Directory created by `save()`.
            device: Device to load onto.

        Returns:
            Restored LanguageEmbeddingInterface instance.
        """
        save_dir = Path(save_directory)
        meta_path = save_dir / "interface_meta.json"

        model_name = str(save_dir / "encoder")
        batch_size = 32

        if meta_path.exists():
            with open(meta_path) as f:
                meta = json.load(f)
            batch_size = meta.get("batch_size", 32)

        instance = cls(
            model_name_or_path=model_name,
            tokenizer_path=str(save_dir / "tokenizer"),
            device=device,
            batch_size=batch_size,
        )
        logger.info("LanguageEmbeddingInterface loaded from: %s", save_dir)
        return instance

    # ── Private Helpers ────────────────────────────────────────────────────

    @staticmethod
    def _build_enriched_prompt(
        task_description: str,
        rf_context: Optional[Dict[str, Any]],
    ) -> str:
        """
        Build an enriched task prompt by combining task description and RF context.

        Args:
            task_description: Natural language task specification.
            rf_context: Optional dict of RF signal parameters.

        Returns:
            Enriched prompt string.
        """
        if not rf_context:
            return task_description

        context_parts: List[str] = []
        mapping = {
            "snr_db": ("SNR", "dB"),
            "sinr_db": ("SINR", "dB"),
            "channel_type": ("channel", ""),
            "bandwidth_mhz": ("bandwidth", "MHz"),
            "frequency_ghz": ("frequency", "GHz"),
            "modulation": ("modulation", ""),
            "num_antennas": ("antennas", ""),
            "num_users": ("users", ""),
            "delay_spread_ns": ("delay spread", "ns"),
            "doppler_hz": ("Doppler shift", "Hz"),
            "path_loss_db": ("path loss", "dB"),
        }

        for key, value in rf_context.items():
            if key in mapping:
                label, unit = mapping[key]
                suffix = f" {unit}" if unit else ""
                context_parts.append(f"{label}: {value}{suffix}")
            else:
                context_parts.append(f"{key}: {value}")

        context_str = ", ".join(context_parts)
        return f"{task_description} [{context_str}]"

    @staticmethod
    def _resolve_device(device: Union[str, torch.device]) -> torch.device:
        """Resolve device string to torch.device with fallback."""
        if isinstance(device, torch.device):
            return device
        if device == "cuda" and torch.cuda.is_available():
            return torch.device("cuda")
        elif device == "mps" and torch.backends.mps.is_available():
            return torch.device("mps")
        else:
            if device == "cuda":
                logger.warning("CUDA requested but unavailable — using CPU")
            return torch.device("cpu")

    def __repr__(self) -> str:
        return (
            f"LanguageEmbeddingInterface("
            f"model='{self._model_name}', "
            f"dim={self.embedding_dim}, "
            f"device={self.device})"
        )
