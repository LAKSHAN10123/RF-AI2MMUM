"""
test_pipeline_integration.py
==============================
RF-AI2MMUM Language Processing Module — Integration Tests
Member B: NLP Engineer & Language Module Developer

End-to-end integration tests verifying the full pipeline:
  Tokenizer → Encoder → EmbeddingInterface
  
Tests cover:
  - Full pipeline: text → tokenize → encode → 768-dim embedding
  - Batch pipeline consistency
  - Context-enriched task processing
  - Similarity search correctness
  - Interface save/load round-trip
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest
import torch
import torch.nn.functional as F

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from language_module import LanguageEmbeddingInterface


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def interface() -> LanguageEmbeddingInterface:
    """Shared LanguageEmbeddingInterface instance for all integration tests."""
    return LanguageEmbeddingInterface(
        model_name_or_path="bert-base-uncased",
        device="cpu",
        pooling_mode="mean",
        normalize_embeddings=True,
        max_seq_length=128,
        batch_size=4,
    )


# ─── Sample RF Task Descriptions ──────────────────────────────────────────────

SAMPLE_TASKS = [
    "Configure OFDM subcarrier spacing for 5G NR FR2 band",
    "Optimize beamforming weights for massive MIMO downlink transmission",
    "Estimate wireless channel using least squares with pilot pattern",
    "Select optimal modulation and coding scheme based on SNR feedback",
    "Configure HARQ with incremental redundancy for reliable transmission",
    "Apply successive interference cancellation for NOMA uplink detection",
    "Design adaptive precoder for multi-user MIMO with ZF beamforming",
    "Monitor spectrum occupancy for cognitive radio secondary access",
]

RF_CONTEXTS = [
    {"snr_db": 25.0, "channel_type": "AWGN", "bandwidth_mhz": 100},
    {"snr_db": 10.0, "channel_type": "Rayleigh", "num_antennas": 64},
    {"snr_db": 15.0, "channel_type": "Rician", "bandwidth_mhz": 200},
]


# ─── Tests: Full Pipeline ─────────────────────────────────────────────────────

class TestFullPipeline:
    def test_single_task_produces_768d_embedding(self, interface):
        emb = interface.get_task_embedding(SAMPLE_TASKS[0])
        assert emb.shape == (768,), f"Expected (768,), got {emb.shape}"

    def test_embedding_is_on_cpu(self, interface):
        emb = interface.get_task_embedding(SAMPLE_TASKS[0])
        assert emb.device.type == "cpu"

    def test_embedding_is_normalized(self, interface):
        emb = interface.get_task_embedding(SAMPLE_TASKS[0])
        norm = emb.norm().item()
        assert abs(norm - 1.0) < 1e-5, f"Expected unit norm, got {norm}"

    def test_embedding_contains_no_nan(self, interface):
        emb = interface.get_task_embedding(SAMPLE_TASKS[0])
        assert not torch.isnan(emb).any(), "Embedding contains NaN values"

    def test_embedding_contains_no_inf(self, interface):
        emb = interface.get_task_embedding(SAMPLE_TASKS[0])
        assert not torch.isinf(emb).any(), "Embedding contains Inf values"


# ─── Tests: Batch Pipeline ────────────────────────────────────────────────────

class TestBatchPipeline:
    def test_batch_shape_matches_input_count(self, interface):
        embs = interface.get_batch_embeddings(SAMPLE_TASKS)
        assert embs.shape == (len(SAMPLE_TASKS), 768)

    def test_empty_batch_returns_empty(self, interface):
        embs = interface.get_batch_embeddings([])
        assert embs.shape[0] == 0

    def test_single_item_batch(self, interface):
        embs = interface.get_batch_embeddings(["OFDM channel estimation"])
        assert embs.shape == (1, 768)

    def test_batch_embeddings_normalized(self, interface):
        embs = interface.get_batch_embeddings(SAMPLE_TASKS)
        norms = embs.norm(dim=-1)
        assert torch.allclose(norms, torch.ones(len(SAMPLE_TASKS)), atol=1e-5)

    def test_batch_consistency_with_single(self, interface):
        """Batch encoding should give same result as individual encoding."""
        texts = SAMPLE_TASKS[:3]
        batch_embs = interface.get_batch_embeddings(texts)
        single_embs = torch.stack([
            interface.get_task_embedding(t, wrap_task_tokens=False) for t in texts
        ])
        assert torch.allclose(batch_embs, single_embs, atol=1e-4)


# ─── Tests: Context-Enriched Task Processing ─────────────────────────────────

class TestContextEnrichedProcessing:
    def test_process_rf_task_returns_result(self, interface):
        from language_module.language_embedding_interface import TaskEmbeddingResult
        result = interface.process_rf_task(
            SAMPLE_TASKS[0],
            rf_context=RF_CONTEXTS[0],
        )
        assert isinstance(result, TaskEmbeddingResult)

    def test_result_embedding_shape(self, interface):
        result = interface.process_rf_task(
            SAMPLE_TASKS[1],
            rf_context=RF_CONTEXTS[1],
        )
        assert result.embedding.shape == (768,)

    def test_result_task_description_preserved(self, interface):
        task = SAMPLE_TASKS[2]
        result = interface.process_rf_task(task, rf_context=RF_CONTEXTS[2])
        assert result.task_description == task

    def test_result_rf_context_preserved(self, interface):
        ctx = RF_CONTEXTS[0]
        result = interface.process_rf_task(SAMPLE_TASKS[0], rf_context=ctx)
        assert result.rf_context == ctx

    def test_no_rf_context(self, interface):
        """process_rf_task with no context should still produce valid embedding."""
        result = interface.process_rf_task(SAMPLE_TASKS[0])
        assert result.embedding.shape == (768,)

    def test_to_numpy_conversion(self, interface):
        import numpy as np
        result = interface.process_rf_task(SAMPLE_TASKS[0])
        np_emb = result.to_numpy()
        assert isinstance(np_emb, np.ndarray)
        assert np_emb.shape == (768,)

    def test_to_dict_serializable(self, interface):
        result = interface.process_rf_task(SAMPLE_TASKS[0], rf_context=RF_CONTEXTS[0])
        d = result.to_dict()
        assert "task_description" in d
        assert "embedding" in d
        assert isinstance(d["embedding"], list)
        assert len(d["embedding"]) == 768


# ─── Tests: Similarity Search ─────────────────────────────────────────────────

class TestSimilaritySearch:
    def test_compute_similarity_returns_float(self, interface):
        emb_a = interface.get_task_embedding(SAMPLE_TASKS[0])
        emb_b = interface.get_task_embedding(SAMPLE_TASKS[1])
        sim = interface.compute_similarity(emb_a, emb_b)
        assert isinstance(sim, float)

    def test_self_similarity_is_one(self, interface):
        emb = interface.get_task_embedding(SAMPLE_TASKS[0])
        sim = interface.compute_similarity(emb, emb)
        assert abs(sim - 1.0) < 1e-5

    def test_find_most_similar_returns_correct_count(self, interface):
        results = interface.find_most_similar(
            SAMPLE_TASKS[0],
            candidates=SAMPLE_TASKS[1:],
            top_k=3,
        )
        assert len(results) == 3

    def test_find_most_similar_scores_are_sorted(self, interface):
        results = interface.find_most_similar(
            SAMPLE_TASKS[0],
            candidates=SAMPLE_TASKS[1:],
            top_k=5,
        )
        scores = [score for _, score in results]
        assert scores == sorted(scores, reverse=True)

    def test_similar_texts_have_higher_similarity(self, interface):
        """Semantically similar texts should have higher cosine similarity."""
        reference = "Configure OFDM subcarrier spacing numerology for 5G"
        similar = "Set 5G NR OFDM numerology and subcarrier spacing parameters"
        dissimilar = "Power amplifier nonlinearity compensation using DPD"

        emb_ref = interface.get_task_embedding(reference)
        emb_sim = interface.get_task_embedding(similar)
        emb_dis = interface.get_task_embedding(dissimilar)

        sim_similar = interface.compute_similarity(emb_ref, emb_sim)
        sim_dissimilar = interface.compute_similarity(emb_ref, emb_dis)

        assert sim_similar > sim_dissimilar, (
            f"Similar pair sim={sim_similar:.4f} should be > dissimilar={sim_dissimilar:.4f}"
        )


# ─── Tests: Tokenize Inspect ──────────────────────────────────────────────────

class TestTokenizeInspect:
    def test_inspect_returns_dict_with_required_keys(self, interface):
        result = interface.tokenize_inspect(SAMPLE_TASKS[0])
        required_keys = ["text", "tokens", "token_ids", "num_tokens", "unk_rate", "vocab_size"]
        for key in required_keys:
            assert key in result, f"Missing key: {key}"

    def test_tokens_are_non_empty(self, interface):
        result = interface.tokenize_inspect(SAMPLE_TASKS[0])
        assert len(result["tokens"]) > 0

    def test_unk_rate_is_in_range(self, interface):
        result = interface.tokenize_inspect(SAMPLE_TASKS[0])
        assert 0.0 <= result["unk_rate"] <= 1.0

    def test_vocab_size_is_positive(self, interface):
        result = interface.tokenize_inspect(SAMPLE_TASKS[0])
        assert result["vocab_size"] > 30000


# ─── Tests: Model Info ────────────────────────────────────────────────────────

class TestModelInfo:
    def test_get_model_info_returns_dict(self, interface):
        info = interface.get_model_info()
        assert isinstance(info, dict)

    def test_model_info_embedding_dim(self, interface):
        info = interface.get_model_info()
        assert info["embedding_dim"] == 768

    def test_model_info_num_parameters(self, interface):
        info = interface.get_model_info()
        assert info["num_parameters"] > 0

    def test_model_info_device(self, interface):
        info = interface.get_model_info()
        assert info["device"] == "cpu"


# ─── Tests: Save / Load Round-trip ────────────────────────────────────────────

class TestInterfaceSaveLoad:
    def test_save_creates_directory(self, interface, tmp_path):
        save_dir = tmp_path / "interface_save"
        interface.save(str(save_dir))
        assert save_dir.exists()
        assert (save_dir / "interface_meta.json").exists()

    def test_save_includes_encoder_dir(self, interface, tmp_path):
        save_dir = tmp_path / "interface_save2"
        interface.save(str(save_dir))
        assert (save_dir / "encoder").exists()

    def test_save_includes_tokenizer_dir(self, interface, tmp_path):
        save_dir = tmp_path / "interface_save3"
        interface.save(str(save_dir))
        assert (save_dir / "tokenizer").exists()
