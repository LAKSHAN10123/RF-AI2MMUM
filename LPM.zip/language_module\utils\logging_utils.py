"""
logging_utils.py
================
RF-AI2MMUM Language Processing Module — Member B

Logging setup utilities for the language module, providing rich console
output and file-based logging for training and inference runs.
"""

from __future__ import annotations

import logging
import logging.config
import os
import sys
from pathlib import Path
from typing import Optional


def setup_logging(
    level: str = "INFO",
    log_file: Optional[str] = None,
    use_rich: bool = True,
) -> None:
    """
    Configure logging for the language module.

    Sets up console logging (with optional Rich formatting) and optional
    file-based logging.

    Args:
        level: Logging level ("DEBUG", "INFO", "WARNING", "ERROR").
        log_file: Optional path to write logs to file.
        use_rich: Whether to use Rich library for colored console output.
    """
    handlers = []

    # Console handler
    if use_rich:
        try:
            from rich.logging import RichHandler
            console_handler = RichHandler(
                rich_tracebacks=True,
                show_path=False,
                markup=True,
            )
            console_handler.setLevel(level)
            handlers.append(console_handler)
        except ImportError:
            use_rich = False

    if not use_rich:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)
        fmt = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%H:%M:%S",
        )
        console_handler.setFormatter(fmt)
        handlers.append(console_handler)

    # File handler (optional)
    if log_file is not None:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(str(log_path), encoding="utf-8")
        file_handler.setLevel("DEBUG")
        detailed_fmt = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s (%(filename)s:%(lineno)d): %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        file_handler.setFormatter(detailed_fmt)
        handlers.append(file_handler)

    # Configure root logger for the language module
    root_logger = logging.getLogger("language_module")
    root_logger.setLevel(level)
    root_logger.handlers.clear()
    for handler in handlers:
        root_logger.addHandler(handler)
    root_logger.propagate = False

    # Quiet noisy third-party loggers
    for noisy_logger in ["transformers", "torch", "datasets", "tokenizers"]:
        logging.getLogger(noisy_logger).setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """
    Get a namespaced logger for a module within the language package.

    Args:
        name: Module name (e.g., "task_tokenizer", "text_encoder").

    Returns:
        Logger instance with the name "language_module.<name>".
    """
    return logging.getLogger(f"language_module.{name}")


class RichProgressLogger:
    """
    Context manager for rich progress display during batch processing.

    Provides a simple wrapper around tqdm or Rich progress bars for
    displaying batch encoding and embedding generation progress.

    Usage:
        with RichProgressLogger("Encoding tasks", total=100) as pbar:
            for batch in batches:
                process(batch)
                pbar.update(len(batch))
    """

    def __init__(
        self,
        description: str = "Processing",
        total: Optional[int] = None,
        unit: str = "item",
    ) -> None:
        """
        Initialize RichProgressLogger.

        Args:
            description: Task description for the progress bar.
            total: Total number of items (for percentage display).
            unit: Unit label (e.g., "sample", "batch").
        """
        self.description = description
        self.total = total
        self.unit = unit
        self._pbar = None

    def __enter__(self) -> "RichProgressLogger":
        try:
            from tqdm import tqdm
            self._pbar = tqdm(
                total=self.total,
                desc=self.description,
                unit=self.unit,
                dynamic_ncols=True,
            )
        except ImportError:
            logger = logging.getLogger("language_module")
            logger.info("%s (progress bar unavailable — install tqdm)", self.description)
        return self

    def update(self, n: int = 1) -> None:
        """Advance the progress bar by n steps."""
        if self._pbar is not None:
            self._pbar.update(n)

    def set_postfix(self, **kwargs) -> None:
        """Update the postfix display (e.g., loss, perplexity)."""
        if self._pbar is not None:
            self._pbar.set_postfix(**kwargs)

    def __exit__(self, *args) -> None:
        if self._pbar is not None:
            self._pbar.close()
