"""
corpus_utils.py
===============
RF-AI2MMUM Language Processing Module — Member B

Utilities for loading, preprocessing, and managing telecom domain corpora
for DAPT training and embedding generation.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Dict, Generator, Iterable, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)


# ─── Standalone Helpers ───────────────────────────────────────────────────────

def load_corpus_lines(
    corpus_path: Union[str, Path],
    skip_comments: bool = True,
    min_length: int = 20,
    max_length: Optional[int] = None,
) -> List[str]:
    """
    Load text lines from a corpus file, filtering short/comment lines.

    Args:
        corpus_path: Path to the corpus .txt file.
        skip_comments: Whether to skip lines starting with '#'.
        min_length: Minimum character length for inclusion.
        max_length: Maximum character length (None = no limit).

    Returns:
        List of cleaned text strings.
    """
    corpus_path = Path(corpus_path)
    if not corpus_path.exists():
        raise FileNotFoundError(f"Corpus file not found: {corpus_path}")

    lines: List[str] = []
    with open(corpus_path, "r", encoding="utf-8") as f:
        for raw_line in f:
            line = raw_line.strip()
            if not line:
                continue
            if skip_comments and (line.startswith("#") or line.startswith("─")):
                continue
            if len(line) < min_length:
                continue
            if max_length is not None and len(line) > max_length:
                line = line[:max_length]
            lines.append(line)

    logger.info("Loaded %d sentences from: %s", len(lines), corpus_path)
    return lines


# ─── CorpusLoader ─────────────────────────────────────────────────────────────

class CorpusLoader:
    """
    Load and iterate over telecom domain corpora from various sources.

    Supports:
      - Plain text files (one sentence per line)
      - JSON Lines files (one JSON object per line with a text field)
      - Directory of text files

    Attributes:
        corpus_path (Path): Root corpus path.
        encoding (str): Text file encoding.
    """

    def __init__(
        self,
        corpus_path: Union[str, Path],
        encoding: str = "utf-8",
        text_field: str = "text",
    ) -> None:
        """
        Initialize CorpusLoader.

        Args:
            corpus_path: Path to a .txt file, .jsonl file, or directory.
            encoding: File encoding.
            text_field: JSON field name containing text (for .jsonl files).
        """
        self.corpus_path = Path(corpus_path)
        self.encoding = encoding
        self.text_field = text_field

    def load(
        self,
        min_length: int = 20,
        max_samples: Optional[int] = None,
    ) -> List[str]:
        """
        Load all text samples from the corpus.

        Args:
            min_length: Minimum character length to include.
            max_samples: Maximum number of samples to return.

        Returns:
            List of text strings.
        """
        if self.corpus_path.is_dir():
            samples = self._load_directory(min_length)
        elif self.corpus_path.suffix == ".jsonl":
            samples = self._load_jsonl(min_length)
        else:
            samples = load_corpus_lines(self.corpus_path, min_length=min_length)

        if max_samples is not None:
            samples = samples[:max_samples]

        logger.info("CorpusLoader: loaded %d samples", len(samples))
        return samples

    def stream(
        self,
        min_length: int = 20,
    ) -> Generator[str, None, None]:
        """
        Stream text samples one at a time (memory efficient for large corpora).

        Args:
            min_length: Minimum character length to yield.

        Yields:
            Text strings.
        """
        if self.corpus_path.is_dir():
            for txt_file in sorted(self.corpus_path.glob("*.txt")):
                yield from self._stream_txt(txt_file, min_length)
        elif self.corpus_path.suffix == ".jsonl":
            yield from self._stream_jsonl(min_length)
        else:
            yield from self._stream_txt(self.corpus_path, min_length)

    def get_stats(self) -> Dict[str, int]:
        """
        Compute corpus statistics.

        Returns:
            Dict with total_samples, total_chars, avg_length.
        """
        samples = self.load()
        total_chars = sum(len(s) for s in samples)
        return {
            "total_samples": len(samples),
            "total_chars": total_chars,
            "avg_length": total_chars // max(len(samples), 1),
            "min_length": min((len(s) for s in samples), default=0),
            "max_length": max((len(s) for s in samples), default=0),
        }

    # ── Private Helpers ────────────────────────────────────────────────────

    def _load_directory(self, min_length: int) -> List[str]:
        all_lines: List[str] = []
        for txt_file in sorted(self.corpus_path.glob("*.txt")):
            all_lines.extend(load_corpus_lines(txt_file, min_length=min_length))
        return all_lines

    def _load_jsonl(self, min_length: int) -> List[str]:
        lines: List[str] = []
        with open(self.corpus_path, "r", encoding=self.encoding) as f:
            for raw in f:
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    obj = json.loads(raw)
                    text = obj.get(self.text_field, "")
                    if isinstance(text, str) and len(text) >= min_length:
                        lines.append(text)
                except json.JSONDecodeError:
                    continue
        return lines

    def _stream_txt(self, path: Path, min_length: int) -> Generator[str, None, None]:
        with open(path, "r", encoding=self.encoding) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and len(line) >= min_length:
                    yield line

    def _stream_jsonl(self, min_length: int) -> Generator[str, None, None]:
        with open(self.corpus_path, "r", encoding=self.encoding) as f:
            for raw in f:
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    obj = json.loads(raw)
                    text = obj.get(self.text_field, "")
                    if isinstance(text, str) and len(text) >= min_length:
                        yield text
                except json.JSONDecodeError:
                    continue


# ─── CorpusPreprocessor ───────────────────────────────────────────────────────

class CorpusPreprocessor:
    """
    Preprocess telecom domain text for tokenization and DAPT training.

    Applies a configurable pipeline of text cleaning operations including:
      - Whitespace normalization
      - URL and citation removal
      - Acronym expansion (for known telecom acronyms)
      - Sentence splitting
    """

    # Common telecom acronyms and their expansions
    ACRONYM_EXPANSIONS: Dict[str, str] = {
        r"\bOFDM\b": "orthogonal frequency division multiplexing",
        r"\bMIMO\b": "multiple input multiple output",
        r"\bBERT\b": "bidirectional encoder representations from transformers",
        r"\b5G NR\b": "5G new radio",
        r"\bNR\b": "new radio",
        r"\bMLM\b": "masked language modeling",
        r"\bDAPT\b": "domain adaptive pre-training",
        r"\bSNR\b": "signal to noise ratio",
        r"\bSINR\b": "signal to interference plus noise ratio",
        r"\bBLER\b": "block error rate",
        r"\bBER\b": "bit error rate",
        r"\bCSI\b": "channel state information",
        r"\bLDPC\b": "low density parity check",
    }

    def __init__(
        self,
        lowercase: bool = True,
        remove_urls: bool = True,
        remove_citations: bool = True,
        expand_acronyms: bool = False,
        normalize_whitespace: bool = True,
    ) -> None:
        """
        Initialize CorpusPreprocessor.

        Args:
            lowercase: Whether to lowercase text.
            remove_urls: Whether to remove URLs.
            remove_citations: Whether to remove citation brackets like [1].
            expand_acronyms: Whether to expand known telecom acronyms.
            normalize_whitespace: Whether to collapse multiple spaces.
        """
        self.lowercase = lowercase
        self.remove_urls = remove_urls
        self.remove_citations = remove_citations
        self.expand_acronyms = expand_acronyms
        self.normalize_whitespace = normalize_whitespace

    def process(self, text: str) -> str:
        """
        Apply the full preprocessing pipeline to a single text string.

        Args:
            text: Raw input text.

        Returns:
            Preprocessed text string.
        """
        if self.remove_urls:
            text = re.sub(r"http\S+|www\.\S+", "", text)
        if self.remove_citations:
            text = re.sub(r"\[\d+(?:,\s*\d+)*\]", "", text)
        if self.expand_acronyms:
            for pattern, expansion in self.ACRONYM_EXPANSIONS.items():
                text = re.sub(pattern, expansion, text)
        if self.normalize_whitespace:
            text = " ".join(text.split())
        if self.lowercase:
            text = text.lower()
        return text.strip()

    def process_batch(self, texts: List[str]) -> List[str]:
        """
        Apply preprocessing to a list of texts.

        Args:
            texts: List of raw text strings.

        Returns:
            List of preprocessed strings.
        """
        return [self.process(t) for t in texts]

    def split_into_sentences(self, text: str) -> List[str]:
        """
        Simple rule-based sentence splitter for technical text.

        Args:
            text: Input paragraph or document.

        Returns:
            List of sentence strings.
        """
        # Split on '. ' or '.\n' followed by capital letter or digit
        sentences = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])", text)
        return [s.strip() for s in sentences if len(s.strip()) > 10]
