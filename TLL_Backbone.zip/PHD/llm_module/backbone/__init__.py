"""Backbone package: frozen Telecom LLM + LoRA configuration."""

from .llm_backbone import LLMBackbone, LLMBackboneError
from .lora_config import LoRAConfigManager, LoRAConfigError

__all__ = [
    "LLMBackbone",
    "LLMBackboneError",
    "LoRAConfigManager",
    "LoRAConfigError",
]
