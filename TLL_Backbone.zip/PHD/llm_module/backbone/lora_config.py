"""
lora_config.py

PEFT LoRA configuration management for the Telecom LLM backbone — Member D.

Provides `LoRAConfigManager`, a thin wrapper around `peft.LoraConfig` and
`peft.get_peft_model` that:
  - Builds a LoRA configuration with configurable rank/alpha/dropout/targets.
  - Applies LoRA adapters to a frozen base model.
  - Saves and loads adapter weights independently of the frozen base model.

Author: Member D — LLM Backbone & Multi-modal Understanding Engineer
"""

from __future__ import annotations

import logging
import os
from typing import List, Optional

import torch.nn as nn
from peft import LoraConfig, PeftModel, TaskType, get_peft_model

logger = logging.getLogger(__name__)


class LoRAConfigError(Exception):
    """Raised when LoRA configuration or application fails."""


# Default target module names per model family. These names correspond to
# the linear projection layers within self-attention (and optionally MLP)
# blocks of common decoder-only architectures.
_DEFAULT_TARGET_MODULES = {
    "llama": ["q_proj", "k_proj", "v_proj", "o_proj"],
    "mistral": ["q_proj", "k_proj", "v_proj", "o_proj"],
    "qwen2": ["q_proj", "k_proj", "v_proj", "o_proj"],
    "qwen": ["c_attn", "c_proj"],
}

_FALLBACK_TARGET_MODULES = ["q_proj", "k_proj", "v_proj", "o_proj"]


class LoRAConfigManager:
    """
    Manages PEFT LoRA configuration and application for a frozen LLM backbone.

    Parameters
    ----------
    rank : int, default 16
        LoRA rank (r). Controls the dimensionality of the low-rank update
        matrices.
    alpha : int, default 32
        LoRA scaling factor. The effective scaling applied to the LoRA
        update is `alpha / rank`.
    dropout : float, default 0.05
        Dropout probability applied to LoRA layers.
    target_modules : Optional[List[str]]
        Names of linear submodules to wrap with LoRA adapters. If None,
        a default set is chosen based on `model_type`.
    bias : str, default "none"
        Bias training strategy passed to `LoraConfig` ("none", "all",
        or "lora_only").
    model_type : str, default ""
        Lower-cased HuggingFace `model_type` string, used to select
        sensible default target modules when `target_modules` is None.
    task_type : TaskType, default TaskType.FEATURE_EXTRACTION
        PEFT task type. `FEATURE_EXTRACTION` is appropriate when the model
        is used as an embedding/hidden-state producer rather than for
        text generation via `.generate()`.
    """

    def __init__(
        self,
        rank: int = 16,
        alpha: int = 32,
        dropout: float = 0.05,
        target_modules: Optional[List[str]] = None,
        bias: str = "none",
        model_type: str = "",
        task_type: TaskType = TaskType.FEATURE_EXTRACTION,
    ) -> None:
        if rank <= 0:
            raise LoRAConfigError(f"LoRA rank must be positive, got {rank}.")
        if alpha <= 0:
            raise LoRAConfigError(f"LoRA alpha must be positive, got {alpha}.")
        if not (0.0 <= dropout < 1.0):
            raise LoRAConfigError(
                f"LoRA dropout must be in [0, 1), got {dropout}."
            )

        self.rank = rank
        self.alpha = alpha
        self.dropout = dropout
        self.bias = bias
        self.task_type = task_type

        if target_modules is None:
            resolved_targets = _FALLBACK_TARGET_MODULES
            for family, modules in _DEFAULT_TARGET_MODULES.items():
                if family in model_type:
                    resolved_targets = modules
                    break
            self.target_modules = resolved_targets
        else:
            self.target_modules = target_modules

        logger.info(
            "LoRAConfigManager initialized: rank=%d, alpha=%d, dropout=%.3f, "
            "target_modules=%s",
            self.rank,
            self.alpha,
            self.dropout,
            self.target_modules,
        )

        self.peft_config = LoraConfig(
            r=self.rank,
            lora_alpha=self.alpha,
            lora_dropout=self.dropout,
            bias=self.bias,
            target_modules=self.target_modules,
            task_type=self.task_type,
        )

    def apply_lora(self, model: nn.Module) -> nn.Module:
        """
        Wrap `model` with PEFT LoRA adapters.

        Parameters
        ----------
        model : nn.Module
            The (already frozen) base model to which LoRA adapters will
            be attached.

        Returns
        -------
        nn.Module
            A `PeftModel` instance wrapping `model` with trainable LoRA
            adapter parameters injected into the configured target modules.

        Raises
        ------
        LoRAConfigError
            If LoRA application fails (e.g. target modules not found).
        """
        try:
            peft_model = get_peft_model(model, self.peft_config)
        except Exception as exc:  # noqa: BLE001
            raise LoRAConfigError(
                f"Failed to apply LoRA configuration to model: {exc}"
            ) from exc

        trainable_params = sum(
            p.numel() for p in peft_model.parameters() if p.requires_grad
        )
        total_params = sum(p.numel() for p in peft_model.parameters())
        logger.info(
            "LoRA applied: %d / %d parameters trainable (%.4f%%).",
            trainable_params,
            total_params,
            100.0 * trainable_params / max(total_params, 1),
        )

        if trainable_params == 0:
            raise LoRAConfigError(
                "LoRA application resulted in zero trainable parameters. "
                f"Check that target_modules={self.target_modules} exist in "
                "the model architecture."
            )

        return peft_model

    @staticmethod
    def save_adapter(model: nn.Module, save_directory: str) -> None:
        """
        Save LoRA adapter weights to disk.

        Parameters
        ----------
        model : nn.Module
            A `PeftModel` instance with LoRA adapters applied.
        save_directory : str
            Directory path where adapter weights and config will be saved.

        Raises
        ------
        LoRAConfigError
            If `model` is not a `PeftModel` or saving fails.
        """
        if not isinstance(model, PeftModel):
            raise LoRAConfigError(
                "save_adapter expects a PeftModel instance; got "
                f"{type(model).__name__}."
            )
        try:
            os.makedirs(save_directory, exist_ok=True)
            model.save_pretrained(save_directory)
            logger.info("LoRA adapter weights saved to '%s'.", save_directory)
        except Exception as exc:  # noqa: BLE001
            raise LoRAConfigError(
                f"Failed to save LoRA adapter to '{save_directory}': {exc}"
            ) from exc

    @staticmethod
    def load_adapter(base_model: nn.Module, adapter_directory: str) -> nn.Module:
        """
        Load LoRA adapter weights onto a base model.

        Parameters
        ----------
        base_model : nn.Module
            The frozen base model (without adapters) to attach the saved
            adapters to.
        adapter_directory : str
            Directory path containing previously saved adapter weights
            (as produced by `save_adapter`).

        Returns
        -------
        nn.Module
            A `PeftModel` instance with the loaded adapter weights.

        Raises
        ------
        LoRAConfigError
            If the adapter directory does not exist or loading fails.
        """
        if not os.path.isdir(adapter_directory):
            raise LoRAConfigError(
                f"Adapter directory '{adapter_directory}' does not exist."
            )
        try:
            peft_model = PeftModel.from_pretrained(base_model, adapter_directory)
            logger.info("LoRA adapter weights loaded from '%s'.", adapter_directory)
            return peft_model
        except Exception as exc:  # noqa: BLE001
            raise LoRAConfigError(
                f"Failed to load LoRA adapter from '{adapter_directory}': {exc}"
            ) from exc
