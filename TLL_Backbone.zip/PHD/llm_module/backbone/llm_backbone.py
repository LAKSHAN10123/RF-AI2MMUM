"""
llm_backbone.py

Telecom LLM Backbone (Frozen + LoRA) for RF-AI2MMUM — Member D.

This module loads a HuggingFace causal language model (LLaMA / Qwen / Mistral
family or any compatible architecture), freezes all base parameters, and
optionally applies LoRA adapters via PEFT for parameter-efficient fine-tuning.

The backbone consumes the fused multi-modal embedding `z_fused` (B, d_llm)
produced by Member C and the tokenized task instruction ids
`task_instruction_ids` (B, seq_len), and produces contextualised hidden
states that are passed downstream to the multi-modal understanding block
and the expert router.

Author: Member D — LLM Backbone & Multi-modal Understanding Engineer
"""

from __future__ import annotations

import logging
from typing import Optional, Dict, Any

import torch
import torch.nn as nn
from transformers import (
    AutoModel,
    AutoModelForCausalLM,
    AutoConfig,
    AutoTokenizer,
    BitsAndBytesConfig,
)

from .lora_config import LoRAConfigManager

logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
)


SUPPORTED_MODEL_FAMILIES = ("llama", "qwen", "qwen2", "mistral")


class LLMBackboneError(Exception):
    """Custom exception raised for LLM backbone configuration/loading errors."""


class LLMBackbone(nn.Module):
    """
    Frozen Telecom LLM backbone with optional LoRA adapters.

    The backbone wraps a HuggingFace `AutoModel` (or `AutoModelForCausalLM`)
    instance. All base-model parameters are frozen by default. LoRA adapters
    can be injected via `lora_config.py` to enable parameter-efficient
    fine-tuning of attention projection matrices.

    Parameters
    ----------
    model_name : str
        HuggingFace model identifier or local path
        (e.g. "meta-llama/Llama-2-7b-hf", "Qwen/Qwen2-7B", "mistralai/Mistral-7B-v0.1").
    hidden_size : int
        Expected hidden dimensionality (d_llm) of the backbone. Used for
        validation against the loaded model's config.
    use_lora : bool, default True
        Whether to apply LoRA adapters on top of the frozen backbone.
    lora_rank : int, default 16
        LoRA rank.
    lora_alpha : int, default 32
        LoRA scaling factor.
    lora_dropout : float, default 0.05
        LoRA dropout probability.
    target_modules : Optional[list[str]]
        Names of linear modules to apply LoRA to. If None, a sensible
        default is chosen based on the detected model family.
    load_in_4bit : bool, default False
        Whether to load the base model using 4-bit quantisation
        (bitsandbytes). Useful for fitting 7B models on consumer GPUs.
    torch_dtype : torch.dtype, default torch.float16
        Data type used for model weights when not using 4-bit quantisation.
    device : Optional[str]
        Target device ("cuda", "cpu", "mps"). If None, auto-detected.
    use_causal_lm : bool, default False
        If True, loads `AutoModelForCausalLM` (full LM head). If False,
        loads `AutoModel` (encoder/base transformer only), which is
        typically what is required to obtain hidden states for fusion
        with `z_fused`.
    trust_remote_code : bool, default False
        Passed through to HuggingFace `from_pretrained`.

    Raises
    ------
    LLMBackboneError
        If the model cannot be loaded, the model family is unsupported,
        or the loaded hidden size does not match `hidden_size`.
    """

    def __init__(
        self,
        model_name: str,
        hidden_size: int = 4096,
        use_lora: bool = True,
        lora_rank: int = 16,
        lora_alpha: int = 32,
        lora_dropout: float = 0.05,
        target_modules: Optional[list] = None,
        load_in_4bit: bool = False,
        torch_dtype: torch.dtype = torch.float16,
        device: Optional[str] = None,
        use_causal_lm: bool = False,
        trust_remote_code: bool = False,
    ) -> None:
        super().__init__()

        self.model_name = model_name
        self.hidden_size = hidden_size
        self.use_lora = use_lora
        self.use_causal_lm = use_causal_lm
        self.torch_dtype = torch_dtype

        self.device = device or (
            "cuda" if torch.cuda.is_available() else "cpu"
        )

        logger.info("Initializing LLMBackbone with model_name=%s", model_name)

        # ------------------------------------------------------------
        # 1. Load model configuration and validate model family
        # ------------------------------------------------------------
        try:
            self.model_config = AutoConfig.from_pretrained(
                model_name, trust_remote_code=trust_remote_code
            )
        except Exception as exc:  # noqa: BLE001
            raise LLMBackboneError(
                f"Failed to load configuration for model '{model_name}': {exc}"
            ) from exc

        model_type = getattr(self.model_config, "model_type", "").lower()
        if not any(family in model_type for family in SUPPORTED_MODEL_FAMILIES):
            logger.warning(
                "Model type '%s' is not in the explicitly supported family "
                "list %s. Proceeding anyway, but behaviour is unverified.",
                model_type,
                SUPPORTED_MODEL_FAMILIES,
            )

        config_hidden_size = getattr(self.model_config, "hidden_size", None)
        if config_hidden_size is not None and config_hidden_size != hidden_size:
            logger.warning(
                "Configured hidden_size=%d does not match model config "
                "hidden_size=%d. The provided hidden_size will be used for "
                "downstream projection layers; ensure adapters account for "
                "this mismatch.",
                hidden_size,
                config_hidden_size,
            )

        # ------------------------------------------------------------
        # 2. Build quantisation config (optional)
        # ------------------------------------------------------------
        quantization_config: Optional[BitsAndBytesConfig] = None
        if load_in_4bit:
            try:
                quantization_config = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_compute_dtype=torch_dtype,
                    bnb_4bit_use_double_quant=True,
                    bnb_4bit_quant_type="nf4",
                )
                logger.info("4-bit quantisation enabled (NF4, double-quant).")
            except Exception as exc:  # noqa: BLE001
                raise LLMBackboneError(
                    f"Failed to construct BitsAndBytesConfig: {exc}"
                ) from exc

        # ------------------------------------------------------------
        # 3. Load the base model
        # ------------------------------------------------------------
        model_cls = AutoModelForCausalLM if use_causal_lm else AutoModel
        try:
            load_kwargs: Dict[str, Any] = {
                "trust_remote_code": trust_remote_code,
            }
            if quantization_config is not None:
                load_kwargs["quantization_config"] = quantization_config
                load_kwargs["device_map"] = "auto"
            else:
                load_kwargs["torch_dtype"] = torch_dtype

            self.model = model_cls.from_pretrained(model_name, **load_kwargs)
        except Exception as exc:  # noqa: BLE001
            raise LLMBackboneError(
                f"Failed to load model weights for '{model_name}': {exc}"
            ) from exc

        logger.info("Base model '%s' loaded successfully.", model_name)

        # ------------------------------------------------------------
        # 4. Freeze all base model parameters
        # ------------------------------------------------------------
        self._freeze_backbone()

        # ------------------------------------------------------------
        # 5. Apply LoRA adapters (optional)
        # ------------------------------------------------------------
        self.lora_manager: Optional[LoRAConfigManager] = None
        if use_lora:
            self.lora_manager = LoRAConfigManager(
                rank=lora_rank,
                alpha=lora_alpha,
                dropout=lora_dropout,
                target_modules=target_modules,
                model_type=model_type,
            )
            self.model = self.lora_manager.apply_lora(self.model)
            logger.info(
                "LoRA adapters applied (rank=%d, alpha=%d, dropout=%.3f).",
                lora_rank,
                lora_alpha,
                lora_dropout,
            )

        # ------------------------------------------------------------
        # 6. Move to device (skip if device_map="auto" was used for 4-bit)
        # ------------------------------------------------------------
        if quantization_config is None:
            try:
                self.model.to(self.device)
            except Exception as exc:  # noqa: BLE001
                raise LLMBackboneError(
                    f"Failed to move model to device '{self.device}': {exc}"
                ) from exc

        logger.info("LLMBackbone ready on device '%s'.", self.device)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _freeze_backbone(self) -> None:
        """Freeze all parameters of the loaded base model."""
        frozen_count = 0
        for param in self.model.parameters():
            param.requires_grad = False
            frozen_count += 1
        logger.info("Frozen %d base-model parameter tensors.", frozen_count)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def get_input_embeddings_layer(self) -> nn.Module:
        """
        Return the model's input embedding layer.

        Returns
        -------
        nn.Module
            The token embedding layer of the underlying model.

        Raises
        ------
        LLMBackboneError
            If the embedding layer cannot be located.
        """
        try:
            return self.model.get_input_embeddings()
        except Exception as exc:  # noqa: BLE001
            raise LLMBackboneError(
                f"Could not retrieve input embeddings layer: {exc}"
            ) from exc

    def count_trainable_parameters(self) -> Dict[str, int]:
        """
        Count trainable vs total parameters.

        Returns
        -------
        Dict[str, int]
            Dictionary with keys 'trainable', 'total', and 'percentage'
            (percentage as an integer, scaled by 10000 for two decimal
            places of precision when divided by 100).
        """
        trainable = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        total = sum(p.numel() for p in self.model.parameters())
        percentage = int((trainable / total) * 10000) if total > 0 else 0
        return {"trainable": trainable, "total": total, "percentage": percentage}

    def forward(
        self,
        z_fused: torch.Tensor,
        task_instruction_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Forward pass through the frozen (+ LoRA) LLM backbone.

        The fused multi-modal embedding `z_fused` is treated as a sequence
        of "soft prompt" embeddings (prepended) and concatenated with the
        token embeddings derived from `task_instruction_ids`. The combined
        sequence is passed through the transformer backbone and the final
        hidden states are returned.

        Parameters
        ----------
        z_fused : torch.Tensor
            Fused multi-modal embedding of shape (B, d_llm) or
            (B, P, d_llm) where P is a number of prefix positions.
        task_instruction_ids : torch.Tensor
            Token ids of shape (B, seq_len).
        attention_mask : Optional[torch.Tensor]
            Attention mask of shape (B, seq_len) corresponding to
            `task_instruction_ids`. If None, an all-ones mask is used.

        Returns
        -------
        torch.Tensor
            Last hidden states of shape (B, P + seq_len, hidden_size).

        Raises
        ------
        LLMBackboneError
            If input shapes are invalid or the forward pass fails.
        """
        if z_fused.dim() == 2:
            # (B, d_llm) -> (B, 1, d_llm) : single prefix token
            z_fused = z_fused.unsqueeze(1)
        elif z_fused.dim() != 3:
            raise LLMBackboneError(
                f"z_fused must have 2 or 3 dimensions, got shape {tuple(z_fused.shape)}"
            )

        if task_instruction_ids.dim() != 2:
            raise LLMBackboneError(
                "task_instruction_ids must have shape (B, seq_len), got "
                f"{tuple(task_instruction_ids.shape)}"
            )

        batch_size_z, prefix_len, d_llm = z_fused.shape
        batch_size_ids, seq_len = task_instruction_ids.shape

        if batch_size_z != batch_size_ids:
            raise LLMBackboneError(
                f"Batch size mismatch: z_fused has batch {batch_size_z}, "
                f"task_instruction_ids has batch {batch_size_ids}."
            )

        try:
            # Obtain token embeddings for the instruction ids
            embedding_layer = self.get_input_embeddings_layer()
            instruction_embeds = embedding_layer(task_instruction_ids.to(self.device))

            z_fused = z_fused.to(device=self.device, dtype=instruction_embeds.dtype)

            # Concatenate prefix (z_fused) with instruction token embeddings
            inputs_embeds = torch.cat([z_fused, instruction_embeds], dim=1)

            if attention_mask is None:
                attention_mask = torch.ones(
                    (batch_size_ids, seq_len),
                    dtype=torch.long,
                    device=self.device,
                )
            else:
                attention_mask = attention_mask.to(self.device)

            prefix_mask = torch.ones(
                (batch_size_ids, prefix_len),
                dtype=attention_mask.dtype,
                device=self.device,
            )
            full_attention_mask = torch.cat([prefix_mask, attention_mask], dim=1)

            outputs = self.model(
                inputs_embeds=inputs_embeds,
                attention_mask=full_attention_mask,
                output_hidden_states=True,
                return_dict=True,
            )

            if hasattr(outputs, "last_hidden_state"):
                hidden_states = outputs.last_hidden_state
            elif hasattr(outputs, "hidden_states") and outputs.hidden_states is not None:
                hidden_states = outputs.hidden_states[-1]
            else:
                raise LLMBackboneError(
                    "Model output does not contain 'last_hidden_state' or "
                    "'hidden_states'."
                )

            return hidden_states

        except LLMBackboneError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise LLMBackboneError(f"Forward pass failed: {exc}") from exc
