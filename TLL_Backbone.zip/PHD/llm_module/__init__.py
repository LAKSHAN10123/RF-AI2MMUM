"""
llm_module — Member D: LLM Backbone & Multi-modal Understanding Engineer.

Exposes `MemberDModule`, the unified entry point implementing:

    def forward(z_fused, task_instruction_ids) -> expert_features
"""

from .member_d_module import MemberDModule, MemberDModuleError

__all__ = ["MemberDModule", "MemberDModuleError"]
