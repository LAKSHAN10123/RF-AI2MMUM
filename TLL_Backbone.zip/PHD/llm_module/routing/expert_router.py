"""
expert_router.py

Context-aware Dynamic Expert Router for RF-AI2MMUM — Member D.

Implements `ExpertRouter`, an MLP-gating-based Mixture-of-Experts router
that takes a pooled multi-modal representation `z_understood`
(B, d_model) and dispatches it through four task-specific expert networks:
  - beam_prediction
  - channel_estimation
  - signal_identification
  - path_loss

The router uses a context-aware MLP gating network to compute soft gate
weights over the four experts, applies top-k sparsification (top-2 by
default) for computational efficiency, and produces per-task expert
feature tensors of shape (B, d_head) consumed by Member E's task heads.

Author: Member D — LLM Backbone & Multi-modal Understanding Engineer
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)

TASK_NAMES: List[str] = [
    "beam_prediction",
    "channel_estimation",
    "signal_identification",
    "path_loss",
]


class ExpertRouterError(Exception):
    """Raised on invalid configuration or forward-pass errors."""


class ExpertNetwork(nn.Module):
    """
    A single task-specific expert: a 2-layer MLP projecting from `d_model`
    to `d_head`.

    Parameters
    ----------
    d_model : int
        Input dimensionality (matches the pooled multi-modal representation).
    d_head : int
        Output dimensionality of the expert's feature vector.
    d_hidden : int
        Hidden layer dimensionality.
    dropout : float, default 0.1
        Dropout probability applied after the hidden activation.
    """

    def __init__(self, d_model: int, d_head: int, d_hidden: int, dropout: float = 0.1) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_model, d_hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_hidden, d_head),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Project `x` of shape (B, d_model) to shape (B, d_head)."""
        return self.net(x)


class GatingNetwork(nn.Module):
    """
    Context-aware MLP gating network producing per-expert logits.

    Parameters
    ----------
    d_model : int
        Input dimensionality of the pooled multi-modal representation.
    num_experts : int
        Number of experts (tasks) to gate over.
    d_hidden : int
        Hidden layer dimensionality of the gating MLP.
    dropout : float, default 0.1
        Dropout probability applied within the gating MLP.
    """

    def __init__(self, d_model: int, num_experts: int, d_hidden: int, dropout: float = 0.1) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_model, d_hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_hidden, num_experts),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Compute raw gating logits of shape (B, num_experts) from `x` (B, d_model)."""
        return self.net(x)


class ExpertRouter(nn.Module):
    """
    Context-aware Dynamic Expert Router with soft gating + top-k sparsification.

    Given the pooled multi-modal representation `z_understood` (B, d_model),
    the router computes:
      1. Gating logits via `GatingNetwork` -> softmax -> soft gate weights
         over the `num_experts` tasks.
      2. Top-k sparsification: only the top-k gate weights (per sample) are
         retained and renormalised; the rest are zeroed.
      3. Each expert network produces a feature vector of shape (B, d_head).
      4. Each expert's output is scaled by its (sparsified) gate weight.

    The final output is a dictionary mapping each task name to its scaled
    expert feature tensor of shape (B, d_head).

    Parameters
    ----------
    d_model : int, default 4096
        Input dimensionality of `z_understood`.
    d_head : int, default 256
        Output feature dimensionality per expert (matches Member E's
        `ExpertFeatures` dataclass field shapes, e.g. (B, 256)).
    d_hidden : int, default 1024
        Hidden dimensionality used in both the gating network and each
        expert network.
    top_k : int, default 2
        Number of experts to keep active (non-zero gate weight) per sample.
    dropout : float, default 0.1
        Dropout probability used in the gating network and expert networks.
    task_names : Optional[List[str]]
        Ordered list of task names corresponding to experts. Defaults to
        `TASK_NAMES` (beam_prediction, channel_estimation,
        signal_identification, path_loss).

    Raises
    ------
    ExpertRouterError
        If `top_k` is not in the valid range `[1, num_experts]` or other
        configuration values are invalid.
    """

    def __init__(
        self,
        d_model: int = 4096,
        d_head: int = 256,
        d_hidden: int = 1024,
        top_k: int = 2,
        dropout: float = 0.1,
        task_names: Optional[List[str]] = None,
    ) -> None:
        super().__init__()

        self.task_names = task_names if task_names is not None else list(TASK_NAMES)
        self.num_experts = len(self.task_names)

        if d_model <= 0 or d_head <= 0 or d_hidden <= 0:
            raise ExpertRouterError(
                "d_model, d_head, and d_hidden must all be positive integers."
            )
        if not (1 <= top_k <= self.num_experts):
            raise ExpertRouterError(
                f"top_k must be in [1, {self.num_experts}], got {top_k}."
            )

        self.d_model = d_model
        self.d_head = d_head
        self.top_k = top_k

        self.gating_network = GatingNetwork(d_model, self.num_experts, d_hidden, dropout)

        self.experts = nn.ModuleDict(
            {
                name: ExpertNetwork(d_model, d_head, d_hidden, dropout)
                for name in self.task_names
            }
        )

        logger.info(
            "ExpertRouter initialized: d_model=%d, d_head=%d, d_hidden=%d, "
            "top_k=%d, tasks=%s",
            d_model,
            d_head,
            d_hidden,
            top_k,
            self.task_names,
        )

    def _compute_gates(self, z_understood: torch.Tensor) -> torch.Tensor:
        """
        Compute sparsified, renormalised soft gate weights.

        Parameters
        ----------
        z_understood : torch.Tensor
            Pooled multi-modal representation of shape (B, d_model).

        Returns
        -------
        torch.Tensor
            Gate weight tensor of shape (B, num_experts), where exactly
            `top_k` entries per row are non-zero and the non-zero entries
            sum to 1.
        """
        logits = self.gating_network(z_understood)  # (B, num_experts)
        soft_gates = F.softmax(logits, dim=-1)  # (B, num_experts)

        if self.top_k == self.num_experts:
            return soft_gates

        topk_values, topk_indices = torch.topk(soft_gates, self.top_k, dim=-1)
        sparse_gates = torch.zeros_like(soft_gates)
        sparse_gates.scatter_(dim=-1, index=topk_indices, src=topk_values)

        # Renormalise so the active gates sum to 1
        denom = sparse_gates.sum(dim=-1, keepdim=True).clamp(min=1e-8)
        sparse_gates = sparse_gates / denom

        return sparse_gates

    def forward(self, z_understood: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Route `z_understood` through gated task-specific experts.

        Parameters
        ----------
        z_understood : torch.Tensor
            Pooled multi-modal representation of shape (B, d_model).

        Returns
        -------
        Dict[str, torch.Tensor]
            Dictionary with keys "beam_prediction", "channel_estimation",
            "signal_identification", and "path_loss" (or the configured
            `task_names`), each mapping to a tensor of shape (B, d_head)
            representing that task's gated expert features.

        Raises
        ------
        ExpertRouterError
            If `z_understood` does not have shape (B, d_model).
        """
        if z_understood.dim() != 2:
            raise ExpertRouterError(
                "z_understood must have shape (B, d_model), got shape "
                f"{tuple(z_understood.shape)}."
            )
        if z_understood.size(-1) != self.d_model:
            raise ExpertRouterError(
                f"Last dimension of z_understood ({z_understood.size(-1)}) "
                f"does not match configured d_model ({self.d_model})."
            )

        gates = self._compute_gates(z_understood)  # (B, num_experts)

        expert_features: Dict[str, torch.Tensor] = {}
        for idx, task_name in enumerate(self.task_names):
            expert_out = self.experts[task_name](z_understood)  # (B, d_head)
            gate_weight = gates[:, idx].unsqueeze(-1)  # (B, 1)
            expert_features[task_name] = expert_out * gate_weight

        return expert_features
