"""
member_d_module.py

Unified Member D module for RF-AI2MMUM.

Combines:
  - `LLMBackbone` (frozen Telecom LLM + LoRA)
  - `MultiModalUnderstanding` (transformer encoder + pooling)
  - `ExpertRouter` (context-aware dynamic expert routing)

into a single `nn.Module` exposing the unified interface required by the
project's interface contract:

    def forward(z_fused, task_instruction_ids) -> expert_features

where `expert_features` is a dict:
    {
        "beam_prediction": tensor(B, d_head),
        "channel_estimation": tensor(B, d_head),
        "signal_identification": tensor(B, d_head),
        "path_loss": tensor(B, d_head),
    }

This dict is directly compatible with Member E's `ExpertFeatures`
dataclass and task heads.

Author: Member D — LLM Backbone & Multi-modal Understanding Engineer
"""

from __future__ import annotations

import logging
from typing import Dict, Optional

import torch
import torch.nn as nn

from .backbone.llm_backbone import LLMBackbone, LLMBackboneError
from .understanding.multimodal_understanding import (
    MultiModalUnderstanding,
    MultiModalUnderstandingError,
)
from .routing.expert_router import ExpertRouter, ExpertRouterError

logger = logging.getLogger(__name__)


class MemberDModuleError(Exception):
    """Raised on configuration or forward-pass errors in the unified module."""


class MemberDModule(nn.Module):
    """
    Unified Member D module: LLM backbone -> multi-modal understanding -> router.

    Parameters
    ----------
    model_name : str
        HuggingFace model identifier for the frozen Telecom LLM backbone.
    hidden_size : int, default 4096
        LLM hidden dimensionality (d_llm), matching `z_fused`'s feature
        dimension and Member C's output.
    use_lora : bool, default True
        Whether to apply LoRA adapters to the backbone.
    lora_rank : int, default 16
        LoRA rank.
    lora_alpha : int, default 32
        LoRA alpha (scaling factor).
    lora_dropout : float, default 0.05
        LoRA dropout probability.
    load_in_4bit : bool, default False
        Whether to load the backbone with 4-bit quantisation.
    torch_dtype : torch.dtype, default torch.float16
        Data type for backbone weights when not using 4-bit quantisation.
    device : Optional[str]
        Target device. If None, auto-detected.
    understanding_num_heads : int, default 8
        Number of attention heads in the multi-modal understanding block.
    understanding_d_ff : int, default 8192
        Feed-forward hidden size in the multi-modal understanding block.
    understanding_num_layers : int, default 2
        Number of transformer encoder layers in the understanding block.
    understanding_dropout : float, default 0.1
        Dropout probability in the understanding block.
    router_d_head : int, default 256
        Output feature dimensionality per expert in the router.
    router_d_hidden : int, default 1024
        Hidden dimensionality of the router's gating and expert networks.
    router_top_k : int, default 2
        Number of experts kept active per sample (top-k soft gating).
    router_dropout : float, default 0.1
        Dropout probability in the router's networks.

    Raises
    ------
    MemberDModuleError
        If any sub-component fails to initialize.
    """

    def __init__(
        self,
        model_name: str,
        hidden_size: int = 4096,
        use_lora: bool = True,
        lora_rank: int = 16,
        lora_alpha: int = 32,
        lora_dropout: float = 0.05,
        load_in_4bit: bool = False,
        torch_dtype: torch.dtype = torch.float16,
        device: Optional[str] = None,
        understanding_num_heads: int = 8,
        understanding_d_ff: int = 8192,
        understanding_num_layers: int = 2,
        understanding_dropout: float = 0.1,
        router_d_head: int = 256,
        router_d_hidden: int = 1024,
        router_top_k: int = 2,
        router_dropout: float = 0.1,
    ) -> None:
        super().__init__()

        try:
            self.backbone = LLMBackbone(
                model_name=model_name,
                hidden_size=hidden_size,
                use_lora=use_lora,
                lora_rank=lora_rank,
                lora_alpha=lora_alpha,
                lora_dropout=lora_dropout,
                load_in_4bit=load_in_4bit,
                torch_dtype=torch_dtype,
                device=device,
            )
        except LLMBackboneError as exc:
            raise MemberDModuleError(f"Failed to initialize LLMBackbone: {exc}") from exc

        try:
            self.understanding = MultiModalUnderstanding(
                d_model=hidden_size,
                num_heads=understanding_num_heads,
                d_ff=understanding_d_ff,
                num_layers=understanding_num_layers,
                dropout=understanding_dropout,
            )
        except MultiModalUnderstandingError as exc:
            raise MemberDModuleError(
                f"Failed to initialize MultiModalUnderstanding: {exc}"
            ) from exc

        try:
            self.router = ExpertRouter(
                d_model=hidden_size,
                d_head=router_d_head,
                d_hidden=router_d_hidden,
                top_k=router_top_k,
                dropout=router_dropout,
            )
        except ExpertRouterError as exc:
            raise MemberDModuleError(f"Failed to initialize ExpertRouter: {exc}") from exc

        self.device = self.backbone.device

        # Determine the compute dtype actually used by the backbone's
        # parameters (e.g. float16 when loaded with torch_dtype=float16 or
        # 4-bit quantisation). The understanding and router sub-modules must
        # match this dtype, otherwise operations like LayerNorm will raise
        # "expected scalar type Half but found Float" when mixed with the
        # backbone's hidden states.
        try:
            backbone_dtype = next(self.backbone.model.parameters()).dtype
        except StopIteration:
            backbone_dtype = torch_dtype
        self.compute_dtype = backbone_dtype

        # Move understanding and router sub-modules to the same device and
        # dtype as the backbone. They remain trainable (not frozen).
        self.understanding.to(device=self.device, dtype=self.compute_dtype)
        self.router.to(device=self.device, dtype=self.compute_dtype)

        logger.info("MemberDModule fully initialized on device '%s'.", self.device)

    def forward(
        self,
        z_fused: torch.Tensor,
        task_instruction_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Unified forward interface for Member D.

        Parameters
        ----------
        z_fused : torch.Tensor
            Fused multi-modal embedding from Member C of shape
            (B, d_llm) or (B, P, d_llm).
        task_instruction_ids : torch.Tensor
            Tokenized task instruction ids of shape (B, seq_len).
        attention_mask : Optional[torch.Tensor]
            Optional attention mask of shape (B, seq_len) for
            `task_instruction_ids`. If provided, it is extended internally
            to account for the prefix introduced by `z_fused` and is also
            used for masked pooling in the understanding block.

        Returns
        -------
        Dict[str, torch.Tensor]
            `expert_features` dictionary with keys "beam_prediction",
            "channel_estimation", "signal_identification", and
            "path_loss", each a tensor of shape (B, d_head). This is
            directly compatible with Member E's `ExpertFeatures` dataclass.

        Raises
        ------
        MemberDModuleError
            If any stage of the pipeline fails.
        """
        try:
            hidden_states = self.backbone(
                z_fused=z_fused,
                task_instruction_ids=task_instruction_ids,
                attention_mask=attention_mask,
            )
        except LLMBackboneError as exc:
            raise MemberDModuleError(f"Backbone forward failed: {exc}") from exc

        # Ensure dtype consistency between the (possibly 4-bit/half) backbone
        # output and the understanding/router sub-modules.
        hidden_states = hidden_states.to(dtype=self.compute_dtype)

        # Ensure the attention mask lives on the same device as
        # hidden_states/the model. The backbone itself moves
        # task_instruction_ids internally, but attention_mask may still be
        # on CPU if the caller did not move it.
        if attention_mask is not None:
            attention_mask = attention_mask.to(device=hidden_states.device)

        # Build a pooling mask that accounts for the prefix length added by
        # the backbone (z_fused contributes 1 or P positions).
        pooling_mask: Optional[torch.Tensor] = None
        if attention_mask is not None:
            prefix_len = hidden_states.size(1) - attention_mask.size(1)
            if prefix_len < 0:
                raise MemberDModuleError(
                    "Computed negative prefix length; hidden_states "
                    f"sequence length ({hidden_states.size(1)}) is shorter "
                    f"than attention_mask sequence length "
                    f"({attention_mask.size(1)})."
                )
            prefix_mask = torch.ones(
                (attention_mask.size(0), prefix_len),
                dtype=attention_mask.dtype,
                device=attention_mask.device,
            )
            pooling_mask = torch.cat([prefix_mask, attention_mask], dim=1)

        try:
            z_understood = self.understanding(hidden_states, pooling_mask)
        except MultiModalUnderstandingError as exc:
            raise MemberDModuleError(f"Understanding forward failed: {exc}") from exc

        try:
            expert_features = self.router(z_understood)
        except ExpertRouterError as exc:
            raise MemberDModuleError(f"Router forward failed: {exc}") from exc

        return expert_features