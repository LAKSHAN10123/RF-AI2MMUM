# Member D — LLM Backbone & Multi-modal Understanding Module

**Project:** RF-AI2MMUM — A Unified RF–Language Multi-Modal Framework for Intelligent and Generalizable PHY-Layer Processing in 6G Networks

**Owner:** Member D — LLM Backbone & Multi-modal Understanding Engineer

---

## 1. Purpose

This module implements the **LLM-centric core** of RF-AI2MMUM. It receives the
fused RF-language multi-modal embedding (`z_fused`) produced by Member C's
fusion/alignment module, processes it through a **frozen Telecom LLM backbone**
augmented with **LoRA adapters**, refines the resulting hidden states with a
**Multi-modal Feature Understanding** transformer block, and dispatches the
pooled representation through a **context-aware Dynamic Expert Router** to
produce per-task `expert_features` consumed by Member E's task heads.

## 2. Architecture

```
z_fused (B, 4096) ──┐
                     ├─► [Frozen LLM Backbone + LoRA] ─► hidden_states (B, 1+L, 4096)
task_instruction_ids ┘                                          │
(B, L)                                                           ▼
                                          [Multi-modal Understanding]
                                       (Self-Attn + FFN, residual + LN, x N)
                                                          │
                                                          ▼
                                              z_understood (B, 4096)
                                                          │
                                                          ▼
                                        [Context-aware Dynamic Expert Router]
                                       (MLP gating, soft + top-k sparsified)
                                                          │
                              ┌───────────────┬───────────────┬───────────────┐
                              ▼               ▼               ▼               ▼
                     beam_prediction  channel_estimation  signal_id     path_loss
                       (B, 256)          (B, 256)          (B, 256)      (B, 256)
```

### Components

| File | Description |
|---|---|
| `backbone/llm_backbone.py` | Loads & freezes a HuggingFace LLaMA/Qwen/Mistral model; concatenates `z_fused` (as a soft prefix) with instruction token embeddings; returns hidden states. |
| `backbone/lora_config.py` | PEFT `LoraConfig` builder, `apply_lora()`, adapter save/load. |
| `understanding/multimodal_understanding.py` | Transformer encoder (Multi-Head Attention + FeedForward, residual + LayerNorm) followed by masked mean pooling. |
| `routing/expert_router.py` | MLP gating network with soft + top-k sparsified routing across 4 task experts. |
| `member_d_module.py` | Unified `MemberDModule` exposing `forward(z_fused, task_instruction_ids) -> expert_features`. |
| `utils/helper.py` | Logging, seeding, device detection, checkpoint I/O, parameter counting. |
| `config/llm_config.yaml` | All configurable hyperparameters. |
| `tests/test_backbone.py` | Full pytest suite using a tiny synthetic LLaMA model for fast CI. |

## 3. Installation

```bash
cd llm_module
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

> **Note:** `flash-attn` and `bitsandbytes` require a CUDA-capable GPU and
> matching toolkit versions. On CPU-only machines, set `load_in_4bit: false`
> in `config/llm_config.yaml` and skip flash-attn (it is not imported
> directly by this module — `transformers` will fall back to standard
> attention automatically).

## 4. How to Run

### 4.1 Quick smoke test (unified module)

```python
import torch
from llm_module import MemberDModule

module = MemberDModule(
    model_name="mistralai/Mistral-7B-v0.1",  # or any LLaMA/Qwen/Mistral model
    hidden_size=4096,
    use_lora=True,
    lora_rank=16,
    lora_alpha=32,
    load_in_4bit=True,   # recommended for 7B models on consumer GPUs
)

batch_size, seq_len = 2, 32
z_fused = torch.randn(batch_size, 4096)
task_instruction_ids = torch.randint(0, 32000, (batch_size, seq_len))
attention_mask = torch.ones(batch_size, seq_len, dtype=torch.long)

expert_features = module(z_fused, task_instruction_ids, attention_mask)

for task, tensor in expert_features.items():
    print(task, tensor.shape)  # (B, 256) for each of the 4 tasks
```

### 4.2 Running tests

```bash
cd llm_module
pytest tests/test_backbone.py -v
```

The test suite builds a tiny synthetic LLaMA model on the fly (no internet
download required) so it runs quickly on both CPU and GPU.

## 5. Expected Inputs

| Name | Shape | Description | Source |
|---|---|---|---|
| `z_fused` | `(B, 4096)` or `(B, P, 4096)` | Fused RF-language embedding | Member C |
| `task_instruction_ids` | `(B, seq_len)` | Tokenized PHY-layer task instruction | Member B / shared tokenizer |
| `attention_mask` (optional) | `(B, seq_len)` | Padding mask for instruction tokens | Member B |

## 6. Expected Outputs

`expert_features: Dict[str, torch.Tensor]`, compatible with Member E's
`ExpertFeatures` dataclass:

| Key | Shape |
|---|---|
| `beam_prediction` | `(B, 256)` |
| `channel_estimation` | `(B, 256)` |
| `signal_identification` | `(B, 256)` |
| `path_loss` | `(B, 256)` |

## 7. Folder Structure

```
llm_module/
├── backbone/
│   ├── __init__.py
│   ├── llm_backbone.py       # Frozen LLM loader + forward()
│   └── lora_config.py        # PEFT LoRA config & apply/save/load
├── understanding/
│   ├── __init__.py
│   └── multimodal_understanding.py  # Transformer encoder + pooling
├── routing/
│   ├── __init__.py
│   └── expert_router.py      # MLP gating + top-k MoE routing
├── tests/
│   ├── __init__.py
│   └── test_backbone.py      # Full pytest suite
├── config/
│   └── llm_config.yaml       # All hyperparameters
├── utils/
│   ├── __init__.py
│   └── helper.py             # logging, seeding, device, checkpoints
├── member_d_module.py         # Unified forward() interface
├── __init__.py
├── requirements.txt
└── README.md
```

## 8. Configuration

All hyperparameters (model name, LoRA rank/alpha/dropout, understanding
layer dimensions, router top-k, device, batch size, etc.) are defined in
`config/llm_config.yaml`. Load it with PyYAML and pass values into
`MemberDModule(...)`.

## 9. Integration Notes for Member E

- Import `MemberDModule` from `llm_module`.
- Call `module(z_fused, task_instruction_ids, attention_mask)`.
- The returned dict's keys/shapes map 1:1 onto `interfaces.io_contracts.ExpertFeatures`
  (`channel_est`, `beam_pred`, `signal_id`, `path_loss` fields of shape `(B, 256)`
  — note: this module uses the descriptive task names
  `channel_estimation`, `beam_prediction`, `signal_identification`,
  `path_loss`; map these to the dataclass field names as needed).
