from dataclasses import dataclass
import torch

@dataclass
class RFEmbedding:
    tensor: torch.Tensor         # shape (B, 512)
    channel_ctx: torch.Tensor    # shape (B, 128)

@dataclass
class LangEmbedding:
    tensor: torch.Tensor         # shape (B, 768)
    attention_mask: torch.Tensor # shape (B, seq_len)

@dataclass
class FusedEmbedding:
    z_fused: torch.Tensor        # shape (B, 4096)

@dataclass
class ExpertFeatures:
    channel_est: torch.Tensor    # (B, 256)
    beam_pred: torch.Tensor      # (B, 256)
    signal_id: torch.Tensor      # (B, 256)
    path_loss: torch.Tensor      # (B, 256)

@dataclass
class Predictions:
    channel_est: torch.Tensor    # (B, Nr, Nt)
    beam_idx: torch.Tensor       # (B,)
    signal_id: torch.Tensor      # (B, C)
    path_loss: torch.Tensor      # (B, 1)
