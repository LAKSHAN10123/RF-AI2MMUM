"""
adapter_layers.py — Member C
Down-projects RF (512) and Language (768) embeddings to shared dim (256).
"""

import torch
import torch.nn as nn


class RFAdapter(nn.Module):
    """Projects RF embedding (B, 512) -> (B, d_shared)"""

    def __init__(self, d_rf: int = 512, d_shared: int = 256, dropout: float = 0.1):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Linear(d_rf, d_shared),
            nn.LayerNorm(d_shared),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

    def forward(self, rf_emb: torch.Tensor) -> torch.Tensor:
        # rf_emb: (B, 512) -> (B, 256)
        return self.proj(rf_emb)


class LangAdapter(nn.Module):
    """Projects Language embedding (B, 768) -> (B, d_shared)"""

    def __init__(self, d_lang: int = 768, d_shared: int = 256, dropout: float = 0.1):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Linear(d_lang, d_shared),
            nn.LayerNorm(d_shared),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

    def forward(self, lang_emb: torch.Tensor) -> torch.Tensor:
        # lang_emb: (B, 768) -> (B, 256)
        return self.proj(lang_emb)


class UpProjectionAdapter(nn.Module):
    """Projects shared dim (B, d_shared) -> LLM dim (B, d_llm)"""

    def __init__(self, d_shared: int = 256, d_llm: int = 4096, dropout: float = 0.1):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Linear(d_shared, d_llm),
            nn.LayerNorm(d_llm),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, 256) -> (B, 4096)
        return self.proj(x)
