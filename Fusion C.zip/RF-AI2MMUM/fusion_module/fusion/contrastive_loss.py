"""
contrastive_loss.py — Member C
InfoNCE contrastive loss to align RF and language embeddings.
Matching RF+instruction pairs are pulled together,
non-matching pairs are pushed apart.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class InfoNCELoss(nn.Module):
    def __init__(self, temperature: float = 0.07):
        super().__init__()
        self.temperature = temperature

    def forward(self, rf_emb: torch.Tensor, lang_emb: torch.Tensor) -> torch.Tensor:
        """
        rf_emb:   (B, d) — RF projected embeddings
        lang_emb: (B, d) — Language projected embeddings
        Diagonal = matching pairs (positive).
        Off-diagonal = non-matching (negative).
        """
        B = rf_emb.size(0)

        # L2 normalise
        rf_norm   = F.normalize(rf_emb,   dim=-1)   # (B, d)
        lang_norm = F.normalize(lang_emb, dim=-1)   # (B, d)

        # Similarity matrix (B, B)
        logits = torch.matmul(rf_norm, lang_norm.T) / self.temperature

        # Labels: diagonal = correct pairs
        labels = torch.arange(B, device=rf_emb.device)

        # Symmetric loss (RF->Lang + Lang->RF)
        loss_rf   = F.cross_entropy(logits,   labels)
        loss_lang = F.cross_entropy(logits.T, labels)

        return (loss_rf + loss_lang) / 2.0


class NTXentLoss(nn.Module):
    """NT-Xent loss (alternative to InfoNCE, used in SimCLR)"""

    def __init__(self, temperature: float = 0.5):
        super().__init__()
        self.temperature = temperature
        self.criterion = nn.CrossEntropyLoss()

    def forward(self, z1: torch.Tensor, z2: torch.Tensor) -> torch.Tensor:
        B = z1.size(0)
        z = torch.cat([z1, z2], dim=0)          # (2B, d)
        z = F.normalize(z, dim=-1)

        sim = torch.matmul(z, z.T) / self.temperature  # (2B, 2B)

        # Remove self-similarity
        mask = torch.eye(2 * B, dtype=torch.bool, device=z.device)
        sim.masked_fill_(mask, float('-inf'))

        # Positive pairs: (i, i+B) and (i+B, i)
        labels = torch.cat([
            torch.arange(B, 2 * B, device=z.device),
            torch.arange(0, B,     device=z.device),
        ])

        return self.criterion(sim, labels)
