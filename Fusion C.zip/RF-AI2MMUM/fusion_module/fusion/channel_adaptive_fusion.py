"""
channel_adaptive_fusion.py — Member C  ★ CORE FILE ★
Combines RF + Language embeddings into z_fused (B, 4096).
This is the final output fed to Member D's LLM backbone.

Pipeline:
  rf_emb(B,512) + lang_emb(B,768)
      → adapters → (B,256) each
      → cross-attention → aligned(B,256)
      → channel-adaptive weighted sum
      → up-projection → z_fused(B,4096)
"""

import torch
import torch.nn as nn

from fusion_module.alignment.adapter_layers import RFAdapter, LangAdapter, UpProjectionAdapter
from fusion_module.alignment.cross_modal_alignment import CrossModalAlignment
from interfaces.io_contracts import RFEmbedding, LangEmbedding, FusedEmbedding


class ChannelAdaptiveFusion(nn.Module):
    def __init__(
        self,
        d_rf: int = 512,
        d_lang: int = 768,
        d_ctx: int = 128,
        d_shared: int = 256,
        d_llm: int = 4096,
        n_heads: int = 8,
        dropout: float = 0.1,
    ):
        super().__init__()

        # Step 1: Down-project both embeddings to shared dim
        self.rf_adapter   = RFAdapter(d_rf, d_shared, dropout)
        self.lang_adapter = LangAdapter(d_lang, d_shared, dropout)

        # Step 2: Cross-modal attention (lang queries RF)
        self.cross_attn = CrossModalAlignment(d_shared, n_heads, dropout)

        # Step 3: Channel-adaptive gating weights
        # Uses channel context (B,128) to predict w1, w2
        self.gate_network = nn.Sequential(
            nn.Linear(d_ctx + d_shared * 2, 64),
            nn.ReLU(),
            nn.Linear(64, 2),
            nn.Softmax(dim=-1),   # w1 + w2 = 1
        )

        # Step 4: Up-project to LLM dim
        self.up_proj = UpProjectionAdapter(d_shared, d_llm, dropout)

        # Residual projection for skip connection
        self.residual_proj = nn.Linear(d_shared * 2, d_shared)

    def forward(
        self,
        rf_input: RFEmbedding,
        lang_input: LangEmbedding,
    ) -> FusedEmbedding:
        """
        rf_input.tensor:      (B, 512)
        rf_input.channel_ctx: (B, 128)
        lang_input.tensor:    (B, 768)
        returns FusedEmbedding with z_fused: (B, 4096)
        """
        rf_emb      = rf_input.tensor        # (B, 512)
        channel_ctx = rf_input.channel_ctx   # (B, 128)
        lang_emb    = lang_input.tensor      # (B, 768)

        # Step 1: Adapt to shared dim
        rf_proj   = self.rf_adapter(rf_emb)     # (B, 256)
        lang_proj = self.lang_adapter(lang_emb) # (B, 256)

        # Step 2: Cross-attention alignment
        aligned = self.cross_attn(rf_proj, lang_proj)  # (B, 256)

        # Step 3: Channel-adaptive gating
        gate_input = torch.cat([channel_ctx, rf_proj, lang_proj], dim=-1)  # (B, 128+256+256)
        weights = self.gate_network(gate_input)   # (B, 2)
        w1, w2  = weights[:, 0:1], weights[:, 1:2]

        # Weighted fusion: z = w1 * rf_adapted + w2 * lang_adapted
        fused = w1 * rf_proj + w2 * aligned      # (B, 256)

        # Residual skip connection
        skip  = self.residual_proj(torch.cat([rf_proj, lang_proj], dim=-1))  # (B, 256)
        fused = fused + skip                     # (B, 256)

        # Step 4: Up-project to LLM dimension
        z_fused = self.up_proj(fused)            # (B, 4096)

        return FusedEmbedding(z_fused=z_fused)
