"""
test_fusion.py — Member C
Unit tests for all fusion & alignment modules.
Uses mock tensors — no real data needed.
Run: pytest fusion_module/tests/test_fusion.py -v
"""

import pytest
import torch

from interfaces.io_contracts import RFEmbedding, LangEmbedding, FusedEmbedding
from fusion_module.alignment.adapter_layers import RFAdapter, LangAdapter, UpProjectionAdapter
from fusion_module.alignment.cross_modal_alignment import CrossModalAlignment
from fusion_module.alignment.prefix_tuning import PrefixTuning
from fusion_module.fusion.contrastive_loss import InfoNCELoss, NTXentLoss
from fusion_module.fusion.channel_adaptive_fusion import ChannelAdaptiveFusion

# ── Mock data ──────────────────────────────────────────────────────────────
B = 4   # batch size

@pytest.fixture
def mock_rf():
    return RFEmbedding(
        tensor=torch.randn(B, 512),
        channel_ctx=torch.randn(B, 128),
    )

@pytest.fixture
def mock_lang():
    return LangEmbedding(
        tensor=torch.randn(B, 768),
        attention_mask=torch.ones(B, 32),
    )

# ── Adapter tests ──────────────────────────────────────────────────────────
def test_rf_adapter_shape():
    model = RFAdapter(d_rf=512, d_shared=256)
    x = torch.randn(B, 512)
    out = model(x)
    assert out.shape == (B, 256), f"Expected (B,256), got {out.shape}"

def test_lang_adapter_shape():
    model = LangAdapter(d_lang=768, d_shared=256)
    x = torch.randn(B, 768)
    out = model(x)
    assert out.shape == (B, 256), f"Expected (B,256), got {out.shape}"

def test_up_projection_shape():
    model = UpProjectionAdapter(d_shared=256, d_llm=4096)
    x = torch.randn(B, 256)
    out = model(x)
    assert out.shape == (B, 4096), f"Expected (B,4096), got {out.shape}"

# ── Cross-attention tests ──────────────────────────────────────────────────
def test_cross_modal_alignment_shape():
    model = CrossModalAlignment(d_model=256, n_heads=8)
    rf   = torch.randn(B, 256)
    lang = torch.randn(B, 256)
    out  = model(rf, lang)
    assert out.shape == (B, 256), f"Expected (B,256), got {out.shape}"

# ── Contrastive loss tests ─────────────────────────────────────────────────
def test_infonce_loss():
    loss_fn = InfoNCELoss(temperature=0.07)
    rf   = torch.randn(B, 256)
    lang = torch.randn(B, 256)
    loss = loss_fn(rf, lang)
    assert loss.item() > 0, "Loss should be positive"
    assert not torch.isnan(loss), "Loss is NaN"

def test_ntxent_loss():
    loss_fn = NTXentLoss(temperature=0.5)
    z1 = torch.randn(B, 256)
    z2 = torch.randn(B, 256)
    loss = loss_fn(z1, z2)
    assert loss.item() > 0
    assert not torch.isnan(loss)

# ── Prefix tuning tests ────────────────────────────────────────────────────
def test_prefix_tuning_shape():
    model = PrefixTuning(num_prefix_tokens=10, d_llm=4096)
    z_fused = torch.randn(B, 4096)
    out = model(z_fused)
    assert out.shape == (B, 11, 4096), f"Expected (B,11,4096), got {out.shape}"

def test_prefix_trainable_params():
    model = PrefixTuning(num_prefix_tokens=10, d_llm=4096)
    params = model.get_trainable_params()
    assert len(params) == 1
    assert params[0].shape == (10, 4096)

# ── Full fusion pipeline test ──────────────────────────────────────────────
def test_channel_adaptive_fusion_shape(mock_rf, mock_lang):
    model = ChannelAdaptiveFusion()
    out   = model(mock_rf, mock_lang)
    assert isinstance(out, FusedEmbedding)
    assert out.z_fused.shape == (B, 4096), f"Expected (B,4096), got {out.z_fused.shape}"

def test_fusion_no_nan(mock_rf, mock_lang):
    model = ChannelAdaptiveFusion()
    out   = model(mock_rf, mock_lang)
    assert not torch.isnan(out.z_fused).any(), "z_fused contains NaN"

def test_fusion_gradients(mock_rf, mock_lang):
    model = ChannelAdaptiveFusion()
    out   = model(mock_rf, mock_lang)
    loss  = out.z_fused.sum()
    loss.backward()
    # Check gradients exist
    for name, param in model.named_parameters():
        assert param.grad is not None, f"No gradient for {name}"

# ── Run summary ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
