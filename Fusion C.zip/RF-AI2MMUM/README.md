# RF-AI2MMUM — Member C: Fusion & Alignment Module

## Your Role
Cross-modal Fusion & Alignment Architect

## Files
| File | Purpose |
|------|---------|
| `interfaces/io_contracts.py` | Shared I/O dataclasses (frozen) |
| `fusion_module/alignment/adapter_layers.py` | Down-project RF(512)+Lang(768) → shared(256) |
| `fusion_module/alignment/cross_modal_alignment.py` | Cross-attention (Q=lang, K/V=RF) |
| `fusion_module/fusion/contrastive_loss.py` | InfoNCE contrastive loss |
| `fusion_module/alignment/prefix_tuning.py` | Learnable prefix tokens for LLM |
| `fusion_module/fusion/channel_adaptive_fusion.py` | ★ Main file — outputs z_fused(B,4096) |
| `fusion_module/config/fusion_config.yaml` | Hyperparameters |
| `fusion_module/tests/test_fusion.py` | Unit tests |

## Run Tests
```bash
pytest fusion_module/tests/test_fusion.py -v
```

## Input / Output
- **Input:** `RFEmbedding(B,512)` from Member A + `LangEmbedding(B,768)` from Member B
- **Output:** `FusedEmbedding(z_fused=(B,4096))` → to Member D

## GitHub Branch
```bash
git checkout -b feature/cross-modal-fusion
```
