# integrated_pipeline\fusion_module_pkg\alignment\__init__.py
