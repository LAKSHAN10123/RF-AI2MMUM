# integrated_pipeline\fusion_module_pkg\__init__.py
