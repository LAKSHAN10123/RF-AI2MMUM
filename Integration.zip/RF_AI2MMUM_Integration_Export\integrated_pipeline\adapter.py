"""
adapter.py — Integration Layer Bridge
======================================
RF-AI2MMUM Project — Member C ↔ Member D Adapter

PipelineAdapter bridges the output of Member C's ChannelAdaptiveFusion
(FusedEmbedding) with the input expected by Member D's MemberDModule
(z_fused tensor).

Key responsibilities:
  1. Dtype conversion: Member C outputs float32; Member D's backbone may
     operate in float16 or bfloat16. This adapter casts z_fused to the
     correct compute dtype to prevent "expected scalar type Half but found
     Float" errors.
  2. Device placement: Ensures z_fused is on the same device as the
     backbone model.
  3. Optional PrefixTuning: If use_prefix_tuning=True, learnable prefix
     tokens are prepended to z_fused before passing to the backbone.
     This converts z_fused from (B, d_llm) to (B, P+1, d_llm).
  4. Tensor validation: Shape and dtype checks with clear error messages.

Issues fixed by this module
----------------------------
  - Issue #6: dtype mismatch (float32 → float16/bfloat16)
  - Device mismatch: moves tensors to target device automatically
"""

from __future__ import annotations

import logging
from typing import Optional

import torch
import torch.nn as nn

from interfaces.io_contracts import FusedEmbedding
from fusion_module_pkg.alignment.prefix_tuning import PrefixTuning

logger = logging.getLogger(__name__)


class PipelineAdapterError(Exception):
    """Raised when adapter encounters incompatible inputs."""


class PipelineAdapter(nn.Module):
    """
    Dtype/device bridge between Member C (Fusion) and Member D (LLM Backbone).

    Parameters
    ----------
    d_llm : int, default 4096
        LLM hidden dimensionality. Must match Member C's d_llm and Member D's
        hidden_size.
    target_dtype : torch.dtype, default torch.float32
        Target dtype for z_fused. Set this to match Member D's backbone dtype
        (e.g., torch.float16 if the backbone uses float16 weights).
    target_device : str, default "cpu"
        Target device for tensor placement. Should match the backbone device.
    use_prefix_tuning : bool, default False
        Whether to prepend learnable prefix tokens to z_fused before passing
        to the LLM backbone. When True, output shape is (B, P+1, d_llm)
        instead of (B, d_llm).
    num_prefix_tokens : int, default 10
        Number of learnable prefix tokens. Only used if use_prefix_tuning=True.
    prefix_dropout : float, default 0.1
        Dropout applied to prefix tokens.
    """

    def __init__(
        self,
        d_llm: int = 4096,
        target_dtype: torch.dtype = torch.float32,
        target_device: str = "cpu",
        use_prefix_tuning: bool = False,
        num_prefix_tokens: int = 10,
        prefix_dropout: float = 0.1,
    ) -> None:
        super().__init__()

        self.d_llm = d_llm
        self.target_dtype = target_dtype
        self.target_device = target_device
        self.use_prefix_tuning = use_prefix_tuning

        if use_prefix_tuning:
            self.prefix_tuning = PrefixTuning(
                num_prefix_tokens=num_prefix_tokens,
                d_llm=d_llm,
                dropout=prefix_dropout,
            )
            logger.info(
                "PipelineAdapter: PrefixTuning enabled with %d prefix tokens.",
                num_prefix_tokens,
            )
        else:
            self.prefix_tuning = None
            logger.info("PipelineAdapter: PrefixTuning disabled.")

        logger.info(
            "PipelineAdapter initialized: d_llm=%d, target_dtype=%s, target_device=%s",
            d_llm,
            target_dtype,
            target_device,
        )

    def forward(self, fused_embedding: FusedEmbedding) -> torch.Tensor:
        """
        Convert FusedEmbedding from Member C to a tensor ready for Member D.

        Parameters
        ----------
        fused_embedding : FusedEmbedding
            Output of ChannelAdaptiveFusion. z_fused has shape (B, d_llm).

        Returns
        -------
        torch.Tensor
            - If use_prefix_tuning=False: shape (B, d_llm)
            - If use_prefix_tuning=True:  shape (B, num_prefix_tokens+1, d_llm)
            Always on target_device with target_dtype.

        Raises
        ------
        PipelineAdapterError
            If z_fused has unexpected shape or contains NaN/Inf values.
        """
        z_fused = fused_embedding.z_fused  # (B, d_llm)

        # ── Validation ──────────────────────────────────────────────────
        if z_fused.dim() != 2:
            raise PipelineAdapterError(
                f"Expected z_fused to be 2D (B, d_llm), got shape {tuple(z_fused.shape)}. "
                "ChannelAdaptiveFusion should always produce a 2D tensor."
            )

        if z_fused.size(-1) != self.d_llm:
            raise PipelineAdapterError(
                f"z_fused last dim {z_fused.size(-1)} != configured d_llm {self.d_llm}. "
                "Check that fusion_config.yaml d_llm matches llm_config.yaml hidden_size."
            )

        if not torch.isfinite(z_fused).all():
            n_nan = torch.isnan(z_fused).sum().item()
            n_inf = torch.isinf(z_fused).sum().item()
            raise PipelineAdapterError(
                f"z_fused contains {n_nan} NaN and {n_inf} Inf values. "
                "Check Member C fusion pipeline for numerical instability."
            )

        # ── Device + Dtype Conversion (Issue #6 fix) ─────────────────────
        z_fused = z_fused.to(device=self.target_device, dtype=self.target_dtype)

        logger.debug(
            "PipelineAdapter: z_fused adapted → shape=%s, dtype=%s, device=%s",
            tuple(z_fused.shape),
            z_fused.dtype,
            z_fused.device,
        )

        # ── Optional Prefix Tuning ────────────────────────────────────────
        if self.prefix_tuning is not None:
            z_fused = self.prefix_tuning(z_fused)  # (B, P+1, d_llm)

        return z_fused

    def update_target(self, device: str, dtype: torch.dtype) -> None:
        """
        Dynamically update the target device and dtype.

        Call this after the backbone is moved to a new device/dtype.
        """
        self.target_device = device
        self.target_dtype = dtype
        if self.prefix_tuning is not None:
            self.prefix_tuning.to(device=device, dtype=dtype)
        logger.info(
            "PipelineAdapter: target updated → device=%s, dtype=%s", device, dtype
        )
