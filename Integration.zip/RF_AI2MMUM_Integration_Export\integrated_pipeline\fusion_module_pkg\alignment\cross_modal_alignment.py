"""
cross_modal_alignment.py — Member C (Integration Copy)
=======================================================
Cross-attention: Language queries RF features.
  Q = language, K = RF, V = RF
  Input:  rf_proj (B, 256), lang_proj (B, 256)
  Output: aligned (B, 256)

Dependency: einops (pip install einops)
"""

import torch
import torch.nn as nn
from einops import rearrange


class CrossModalAlignment(nn.Module):
    def __init__(self, d_model: int = 256, n_heads: int = 8, dropout: float = 0.1):
        super().__init__()
        assert d_model % n_heads == 0, "d_model must be divisible by n_heads"

        self.d_model = d_model
        self.n_heads = n_heads
        self.d_head = d_model // n_heads
        self.scale = self.d_head ** -0.5

        # Q from language, K/V from RF
        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.out_proj = nn.Linear(d_model, d_model)

        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_model * 4),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model * 4, d_model),
        )

    def forward(self, rf_proj: torch.Tensor, lang_proj: torch.Tensor) -> torch.Tensor:
        """
        rf_proj:   (B, 256) — from RFAdapter
        lang_proj: (B, 256) — from LangAdapter
        returns:   (B, 256) — aligned features
        """
        # Expand to sequence length 1 for attention: (B, 1, 256)
        rf = rf_proj.unsqueeze(1)
        lang = lang_proj.unsqueeze(1)

        # Q from language, K/V from RF
        Q = self.q_proj(lang)   # (B, 1, 256)
        K = self.k_proj(rf)     # (B, 1, 256)
        V = self.v_proj(rf)     # (B, 1, 256)

        # Multi-head split
        Q = rearrange(Q, 'b n (h d) -> b h n d', h=self.n_heads)
        K = rearrange(K, 'b n (h d) -> b h n d', h=self.n_heads)
        V = rearrange(V, 'b n (h d) -> b h n d', h=self.n_heads)

        # Scaled dot-product attention
        attn = torch.einsum('bhid,bhjd->bhij', Q, K) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.dropout(attn)

        out = torch.einsum('bhij,bhjd->bhid', attn, V)
        out = rearrange(out, 'b h n d -> b n (h d)')  # (B, 1, 256)
        out = self.out_proj(out).squeeze(1)            # (B, 256)

        # Residual + norm
        out = self.norm1(out + lang_proj)

        # FFN + residual
        out = self.norm2(out + self.ffn(out))

        return out  # (B, 256)
