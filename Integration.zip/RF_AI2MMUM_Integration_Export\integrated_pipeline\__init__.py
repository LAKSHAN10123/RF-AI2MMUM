"""
integrated_pipeline — Member C + Member D integrated module.

Exposes:
  - FusionLLMPipeline  : end-to-end pipeline (Fusion → LLM Backbone → Expert Router)
  - PipelineAdapter    : dtype/device bridge between Member C and Member D
"""

from .pipeline import FusionLLMPipeline
from .adapter import PipelineAdapter
from .interfaces.io_contracts import (
    RFEmbedding,
    LangEmbedding,
    FusedEmbedding,
    ExpertFeatures,
    Predictions,
)

__all__ = [
    "FusionLLMPipeline",
    "PipelineAdapter",
    "RFEmbedding",
    "LangEmbedding",
    "FusedEmbedding",
    "ExpertFeatures",
    "Predictions",
]
