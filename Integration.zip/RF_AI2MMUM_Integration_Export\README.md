# RF-AI2MMUM — Integrated Pipeline (Member C + Member D)

This repository contains the integrated pipeline bridging **Member C's Fusion & Alignment Module** with **Member D's Telecom LLM Backbone & Expert Routing Module**.

## Structure

- `integrated_pipeline/`: The core integrated module package.
  - `pipeline.py`: The main `FusionLLMPipeline` class.
  - `adapter.py`: The `PipelineAdapter` bridging dtype and device differences.
  - `interfaces/io_contracts.py`: Shared data classes (e.g., `RFEmbedding`, `FusedEmbedding`, `ExpertFeatures`).
  - `configs/integration_config.yaml`: Configuration for the full pipeline.
  - `fusion_module_pkg/`: Repackaged Member C code with correct relative imports.
  - `llm_module/`: Member D's code.
- `tests/integration/test_cd_integration.py`: A comprehensive integration test suite (43 tests).
- `requirements.txt`: Python dependencies required to run the pipeline.

## Usage

### 1. Install Dependencies
```bash
python -m venv venv
# On Windows: venv\Scripts\activate
# On Linux/Mac: source venv/bin/activate
pip install -r requirements.txt
```

### 2. Run Tests
The integration tests use a mock local LLaMA model and do not require downloading large HF weights.
```bash
export PYTHONPATH=".;./integrated_pipeline"  # Linux/Mac
# $env:PYTHONPATH = ".;.\integrated_pipeline" # Windows PowerShell
python -m pytest tests/integration/test_cd_integration.py -v
```

### 3. Run Demo
The demo runs a forward pass using the mock backbone and prints the output shapes.
```bash
python integrated_pipeline/pipeline.py
```
