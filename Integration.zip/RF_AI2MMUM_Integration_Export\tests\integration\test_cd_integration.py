"""
test_cd_integration.py
======================
RF-AI2MMUM — Integration Tests: Member C (Fusion) + Member D (LLM Backbone)

Tests the complete integrated pipeline using mock inputs.
No real HuggingFace model download is required — a tiny randomly-initialized
LLaMA model is created in a temp directory for all LLM-related tests.

Run with:
    pytest tests/integration/test_cd_integration.py -v

Test Coverage:
    1. Individual Member C components (fusion module)
    2. Individual Member D components (backbone, router, understanding)
    3. PipelineAdapter (dtype/device bridge)
    4. Full end-to-end FusionLLMPipeline
    5. ExpertFeatures dataclass conversion
    6. Shape validations at every stage
    7. NaN / Inf checks
    8. Error handling / bad inputs
    9. Gradient flow
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import pytest
import torch

# ── Path Setup ───────────────────────────────────────────────────────────────
# Make integrated_pipeline package importable regardless of where pytest runs.
_WORKSPACE = Path(__file__).resolve().parents[2]
_INTEG_PKG = _WORKSPACE / "integrated_pipeline"

for _p in [str(_WORKSPACE), str(_INTEG_PKG)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

# ── Imports ───────────────────────────────────────────────────────────────────
from interfaces.io_contracts import (
    RFEmbedding,
    LangEmbedding,
    FusedEmbedding,
    ExpertFeatures,
)
from fusion_module_pkg.alignment.adapter_layers import (
    RFAdapter,
    LangAdapter,
    UpProjectionAdapter,
)
from fusion_module_pkg.alignment.cross_modal_alignment import CrossModalAlignment
from fusion_module_pkg.alignment.prefix_tuning import PrefixTuning
from fusion_module_pkg.fusion.channel_adaptive_fusion import ChannelAdaptiveFusion
from fusion_module_pkg.fusion.contrastive_loss import InfoNCELoss, NTXentLoss
from llm_module.understanding.multimodal_understanding import MultiModalUnderstanding
from llm_module.routing.expert_router import ExpertRouter, TASK_NAMES
from llm_module.backbone.llm_backbone import LLMBackbone
from adapter import PipelineAdapter, PipelineAdapterError
from pipeline import FusionLLMPipeline, FusionLLMPipelineError


# ─────────────────────────────────────────────────────────────────────────────
# Constants / Fixtures
# ─────────────────────────────────────────────────────────────────────────────

B = 2           # batch size
SEQ_LEN = 6    # task instruction sequence length

# Tiny model dims (avoids 4096-dim models in tests for speed)
TINY_D = 64     # mock LLM hidden size
TINY_VOCAB = 100
TINY_D_SHARED = 32


@pytest.fixture(scope="module")
def tiny_llama_path() -> str:
    """Create a tiny LLaMA model in a temp dir and return the path."""
    from transformers import LlamaConfig, LlamaModel

    config = LlamaConfig(
        vocab_size=TINY_VOCAB,
        hidden_size=TINY_D,
        intermediate_size=TINY_D * 2,
        num_hidden_layers=2,
        num_attention_heads=4,
        num_key_value_heads=4,
        max_position_embeddings=128,
    )
    model = LlamaModel(config)
    tmp_dir = tempfile.mkdtemp(prefix="test_integ_llama_")
    model.save_pretrained(tmp_dir)
    config.save_pretrained(tmp_dir)
    return tmp_dir


@pytest.fixture(scope="module")
def mock_pipeline(tiny_llama_path: str) -> FusionLLMPipeline:
    """Full integrated pipeline using a tiny mock LLaMA model."""
    pipeline = FusionLLMPipeline(
        model_name=tiny_llama_path,
        hidden_size=TINY_D,
        d_rf=512,
        d_lang=768,
        d_ctx=128,
        d_shared=TINY_D_SHARED,
        n_heads_fusion=4,
        fusion_dropout=0.0,
        use_prefix_tuning=False,
        use_lora=True,
        lora_rank=4,
        lora_alpha=8,
        lora_dropout=0.0,
        load_in_4bit=False,
        torch_dtype=torch.float32,
        device="cpu",
        understanding_num_heads=4,
        understanding_d_ff=TINY_D * 2,
        understanding_num_layers=1,
        understanding_dropout=0.0,
        router_d_head=32,
        router_d_hidden=64,
        router_top_k=2,
        router_dropout=0.0,
    )
    return pipeline


@pytest.fixture
def rf_input() -> RFEmbedding:
    return RFEmbedding(
        tensor=torch.randn(B, 512),
        channel_ctx=torch.randn(B, 128),
    )


@pytest.fixture
def lang_input() -> LangEmbedding:
    return LangEmbedding(
        tensor=torch.randn(B, 768),
        attention_mask=torch.ones(B, SEQ_LEN, dtype=torch.long),
    )


@pytest.fixture
def task_ids() -> torch.Tensor:
    return torch.randint(0, TINY_VOCAB, (B, SEQ_LEN))


@pytest.fixture
def attn_mask() -> torch.Tensor:
    return torch.ones(B, SEQ_LEN, dtype=torch.long)


# ─────────────────────────────────────────────────────────────────────────────
# 1. Member C — Individual Component Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestMemberCComponents:
    """Tests for individual Member C fusion components."""

    def test_rf_adapter_shape(self):
        model = RFAdapter(d_rf=512, d_shared=256)
        x = torch.randn(B, 512)
        out = model(x)
        assert out.shape == (B, 256), f"Expected (B,256), got {out.shape}"

    def test_lang_adapter_shape(self):
        model = LangAdapter(d_lang=768, d_shared=256)
        x = torch.randn(B, 768)
        out = model(x)
        assert out.shape == (B, 256), f"Expected (B,256), got {out.shape}"

    def test_up_projection_adapter_shape(self):
        model = UpProjectionAdapter(d_shared=256, d_llm=4096)
        x = torch.randn(B, 256)
        out = model(x)
        assert out.shape == (B, 4096), f"Expected (B,4096), got {out.shape}"

    def test_cross_modal_alignment_shape(self):
        model = CrossModalAlignment(d_model=256, n_heads=8)
        rf = torch.randn(B, 256)
        lang = torch.randn(B, 256)
        out = model(rf, lang)
        assert out.shape == (B, 256), f"Expected (B,256), got {out.shape}"

    def test_cross_modal_alignment_no_nan(self):
        model = CrossModalAlignment(d_model=256, n_heads=8)
        rf = torch.randn(B, 256)
        lang = torch.randn(B, 256)
        out = model(rf, lang)
        assert not torch.isnan(out).any(), "CrossModalAlignment produced NaN"

    def test_prefix_tuning_shape(self):
        model = PrefixTuning(num_prefix_tokens=10, d_llm=4096)
        z_fused = torch.randn(B, 4096)
        out = model(z_fused)
        assert out.shape == (B, 11, 4096), f"Expected (B,11,4096), got {out.shape}"

    def test_prefix_tuning_trainable_params(self):
        model = PrefixTuning(num_prefix_tokens=10, d_llm=4096)
        params = model.get_trainable_params()
        assert len(params) == 1
        assert params[0].shape == (10, 4096)

    def test_infonce_loss_positive(self):
        loss_fn = InfoNCELoss(temperature=0.07)
        rf = torch.randn(B, 256)
        lang = torch.randn(B, 256)
        loss = loss_fn(rf, lang)
        assert loss.item() > 0
        assert not torch.isnan(loss)

    def test_ntxent_loss_positive(self):
        loss_fn = NTXentLoss(temperature=0.5)
        z1 = torch.randn(B, 256)
        z2 = torch.randn(B, 256)
        loss = loss_fn(z1, z2)
        assert loss.item() > 0
        assert not torch.isnan(loss)


# ─────────────────────────────────────────────────────────────────────────────
# 2. Member C — Full Fusion Pipeline (ChannelAdaptiveFusion)
# ─────────────────────────────────────────────────────────────────────────────

class TestChannelAdaptiveFusion:
    """Tests for the main Member C fusion module."""

    @pytest.fixture(scope="class")
    def fusion_model(self) -> ChannelAdaptiveFusion:
        return ChannelAdaptiveFusion(
            d_rf=512, d_lang=768, d_ctx=128, d_shared=256, d_llm=4096
        )

    def test_output_is_fused_embedding(self, fusion_model, rf_input, lang_input):
        out = fusion_model(rf_input, lang_input)
        assert isinstance(out, FusedEmbedding), "Output must be FusedEmbedding dataclass"

    def test_z_fused_shape(self, fusion_model, rf_input, lang_input):
        out = fusion_model(rf_input, lang_input)
        assert out.z_fused.shape == (B, 4096), (
            f"Expected z_fused shape (B,4096), got {out.z_fused.shape}"
        )

    def test_z_fused_no_nan(self, fusion_model, rf_input, lang_input):
        out = fusion_model(rf_input, lang_input)
        assert not torch.isnan(out.z_fused).any(), "z_fused contains NaN values"

    def test_z_fused_no_inf(self, fusion_model, rf_input, lang_input):
        out = fusion_model(rf_input, lang_input)
        assert torch.isfinite(out.z_fused).all(), "z_fused contains Inf values"

    def test_gradients_flow_through_fusion(self, fusion_model, rf_input, lang_input):
        out = fusion_model(rf_input, lang_input)
        loss = out.z_fused.sum()
        loss.backward()
        for name, param in fusion_model.named_parameters():
            assert param.grad is not None, f"No gradient for parameter: {name}"


# ─────────────────────────────────────────────────────────────────────────────
# 3. Member D — Individual Component Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestMemberDComponents:
    """Tests for individual Member D sub-components."""

    def test_multimodal_understanding_shape(self):
        mmu = MultiModalUnderstanding(d_model=TINY_D, num_heads=4, d_ff=128, num_layers=1)
        hs = torch.randn(B, 7, TINY_D)
        out = mmu(hs)
        assert out.shape == (B, TINY_D), f"Expected (B,{TINY_D}), got {out.shape}"

    def test_multimodal_understanding_with_mask(self):
        mmu = MultiModalUnderstanding(d_model=TINY_D, num_heads=4, d_ff=128, num_layers=1)
        hs = torch.randn(B, 5, TINY_D)
        mask = torch.tensor([[1, 1, 1, 0, 0], [1, 1, 1, 1, 1]])
        out = mmu(hs, mask)
        assert out.shape == (B, TINY_D)

    def test_expert_router_output_keys(self):
        router = ExpertRouter(d_model=TINY_D, d_head=32, d_hidden=64, top_k=2)
        z = torch.randn(B, TINY_D)
        feats = router(z)
        assert set(feats.keys()) == set(TASK_NAMES), (
            f"Router keys {set(feats.keys())} != {set(TASK_NAMES)}"
        )

    def test_expert_router_output_shapes(self):
        d_head = 32
        router = ExpertRouter(d_model=TINY_D, d_head=d_head, d_hidden=64, top_k=2)
        z = torch.randn(B, TINY_D)
        feats = router(z)
        for task, feat in feats.items():
            assert feat.shape == (B, d_head), f"{task}: expected ({B},{d_head}), got {feat.shape}"

    def test_expert_router_no_nan(self):
        router = ExpertRouter(d_model=TINY_D, d_head=32, d_hidden=64, top_k=2)
        z = torch.randn(B, TINY_D)
        feats = router(z)
        for task, feat in feats.items():
            assert not torch.isnan(feat).any(), f"{task} contains NaN"

    def test_llm_backbone_freeze(self, tiny_llama_path):
        backbone = LLMBackbone(
            model_name=tiny_llama_path,
            hidden_size=TINY_D,
            use_lora=False,
            device="cpu",
        )
        for param in backbone.model.parameters():
            assert not param.requires_grad, "Base model should be frozen"

    def test_llm_backbone_lora_trainable(self, tiny_llama_path):
        backbone = LLMBackbone(
            model_name=tiny_llama_path,
            hidden_size=TINY_D,
            use_lora=True,
            lora_rank=4,
            lora_alpha=8,
            lora_dropout=0.0,
            torch_dtype=torch.float32,
            device="cpu",
        )
        counts = backbone.count_trainable_parameters()
        assert counts["trainable"] > 0, "LoRA should create trainable params"
        assert counts["trainable"] < counts["total"], "Not all params should be trainable"

    def test_llm_backbone_forward_shape(self, tiny_llama_path):
        backbone = LLMBackbone(
            model_name=tiny_llama_path,
            hidden_size=TINY_D,
            use_lora=False,
            torch_dtype=torch.float32,
            device="cpu",
        )
        z_fused = torch.randn(B, TINY_D)
        task_ids = torch.randint(0, TINY_VOCAB, (B, SEQ_LEN))
        hs = backbone(z_fused=z_fused, task_instruction_ids=task_ids)
        # Expected: (B, 1 + SEQ_LEN, TINY_D) — z_fused adds 1 prefix position
        assert hs.shape == (B, 1 + SEQ_LEN, TINY_D), (
            f"Expected ({B},{1+SEQ_LEN},{TINY_D}), got {hs.shape}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# 4. PipelineAdapter Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestPipelineAdapter:
    """Tests for the dtype/device bridge adapter."""

    def test_adapter_passthrough_float32(self):
        adapter = PipelineAdapter(d_llm=4096, target_dtype=torch.float32, target_device="cpu")
        z = torch.randn(B, 4096)
        out = adapter(FusedEmbedding(z_fused=z))
        assert out.shape == (B, 4096)
        assert out.dtype == torch.float32

    def test_adapter_dtype_cast_float16(self):
        """Adapter must cast float32 fusion output to float16 for backbone."""
        adapter = PipelineAdapter(d_llm=4096, target_dtype=torch.float16, target_device="cpu")
        z = torch.randn(B, 4096, dtype=torch.float32)
        out = adapter(FusedEmbedding(z_fused=z))
        assert out.dtype == torch.float16, (
            f"Issue #6: dtype not cast; expected float16, got {out.dtype}"
        )

    def test_adapter_rejects_3d_input(self):
        adapter = PipelineAdapter(d_llm=4096)
        bad_z = torch.randn(B, 1, 4096)  # 3D - should fail
        with pytest.raises(PipelineAdapterError):
            adapter(FusedEmbedding(z_fused=bad_z))

    def test_adapter_rejects_wrong_dim_size(self):
        adapter = PipelineAdapter(d_llm=4096)
        bad_z = torch.randn(B, 2048)  # wrong last dim
        with pytest.raises(PipelineAdapterError):
            adapter(FusedEmbedding(z_fused=bad_z))

    def test_adapter_rejects_nan(self):
        adapter = PipelineAdapter(d_llm=4096)
        bad_z = torch.full((B, 4096), float("nan"))
        with pytest.raises(PipelineAdapterError):
            adapter(FusedEmbedding(z_fused=bad_z))

    def test_adapter_with_prefix_tuning(self):
        adapter = PipelineAdapter(
            d_llm=256,  # small dim for test speed
            target_dtype=torch.float32,
            target_device="cpu",
            use_prefix_tuning=True,
            num_prefix_tokens=5,
        )
        z = torch.randn(B, 256)
        out = adapter(FusedEmbedding(z_fused=z))
        # With prefix tuning: (B, P+1, d_llm) = (B, 6, 256)
        assert out.shape == (B, 6, 256), (
            f"Expected (B,6,256) with prefix tuning, got {out.shape}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# 5. Full End-to-End Integration Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestEndToEndIntegration:
    """Full pipeline integration tests: Member C → Adapter → Member D."""

    def test_pipeline_forward_returns_all_task_keys(
        self, mock_pipeline, rf_input, lang_input, task_ids, attn_mask
    ):
        """Pipeline must return all 4 expert task keys."""
        with torch.no_grad():
            feats = mock_pipeline(
                rf_input=rf_input,
                lang_input=lang_input,
                task_instruction_ids=task_ids,
                attention_mask=attn_mask,
            )
        assert set(feats.keys()) == set(TASK_NAMES), (
            f"Missing task keys: {set(TASK_NAMES) - set(feats.keys())}"
        )

    def test_pipeline_output_shapes(
        self, mock_pipeline, rf_input, lang_input, task_ids, attn_mask
    ):
        """Each expert feature tensor must have shape (B, d_head=32)."""
        with torch.no_grad():
            feats = mock_pipeline(
                rf_input=rf_input,
                lang_input=lang_input,
                task_instruction_ids=task_ids,
                attention_mask=attn_mask,
            )
        for task, feat in feats.items():
            assert feat.shape == (B, 32), (
                f"Task '{task}': expected ({B},32), got {feat.shape}"
            )

    def test_pipeline_no_nan_in_output(
        self, mock_pipeline, rf_input, lang_input, task_ids, attn_mask
    ):
        """No NaN values must appear in expert feature outputs."""
        with torch.no_grad():
            feats = mock_pipeline(
                rf_input=rf_input,
                lang_input=lang_input,
                task_instruction_ids=task_ids,
                attention_mask=attn_mask,
            )
        for task, feat in feats.items():
            nan_count = torch.isnan(feat).sum().item()
            assert nan_count == 0, f"Task '{task}' contains {nan_count} NaN values"

    def test_pipeline_all_finite_outputs(
        self, mock_pipeline, rf_input, lang_input, task_ids, attn_mask
    ):
        """All expert feature values must be finite (no Inf)."""
        with torch.no_grad():
            feats = mock_pipeline(
                rf_input=rf_input,
                lang_input=lang_input,
                task_instruction_ids=task_ids,
                attention_mask=attn_mask,
            )
        for task, feat in feats.items():
            assert torch.isfinite(feat).all(), f"Task '{task}' contains Inf values"

    def test_pipeline_without_attention_mask(
        self, mock_pipeline, rf_input, lang_input, task_ids
    ):
        """Pipeline should work without explicit attention_mask."""
        with torch.no_grad():
            feats = mock_pipeline(
                rf_input=rf_input,
                lang_input=lang_input,
                task_instruction_ids=task_ids,
                attention_mask=None,
            )
        assert set(feats.keys()) == set(TASK_NAMES)

    def test_pipeline_return_intermediate(
        self, mock_pipeline, rf_input, lang_input, task_ids, attn_mask
    ):
        """return_intermediate=True should provide z_fused and z_adapted."""
        with torch.no_grad():
            feats, intermediates = mock_pipeline(
                rf_input=rf_input,
                lang_input=lang_input,
                task_instruction_ids=task_ids,
                attention_mask=attn_mask,
                return_intermediate=True,
            )
        assert "z_fused" in intermediates
        assert "z_adapted" in intermediates
        assert intermediates["z_fused"].shape == (B, TINY_D)
        assert intermediates["z_adapted"].shape[0] == B

    def test_pipeline_expert_features_dataclass(
        self, mock_pipeline, rf_input, lang_input, task_ids, attn_mask
    ):
        """get_expert_features_dataclass() must return an ExpertFeatures object."""
        with torch.no_grad():
            ef = mock_pipeline.get_expert_features_dataclass(
                rf_input=rf_input,
                lang_input=lang_input,
                task_instruction_ids=task_ids,
                attention_mask=attn_mask,
            )
        assert isinstance(ef, ExpertFeatures)
        assert ef.channel_est.shape == (B, 32)
        assert ef.beam_pred.shape   == (B, 32)
        assert ef.signal_id.shape   == (B, 32)
        assert ef.path_loss.shape   == (B, 32)


# ─────────────────────────────────────────────────────────────────────────────
# 6. IO Contract Compatibility Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestIOContractCompatibility:
    """
    Verify that Member C's output type is EXACTLY compatible with
    Member D's input type, and ExpertFeatures matches the io_contracts spec.
    """

    def test_fused_embedding_z_fused_is_tensor(self):
        fe = FusedEmbedding(z_fused=torch.randn(B, 4096))
        assert isinstance(fe.z_fused, torch.Tensor)

    def test_fused_embedding_shape_4096(self):
        fe = FusedEmbedding(z_fused=torch.randn(B, 4096))
        assert fe.z_fused.shape == (B, 4096), (
            "FusedEmbedding.z_fused must be (B, 4096) for Member D"
        )

    def test_expert_features_from_router_dict(self):
        d = {
            "channel_estimation":    torch.randn(B, 256),
            "beam_prediction":       torch.randn(B, 256),
            "signal_identification": torch.randn(B, 256),
            "path_loss":             torch.randn(B, 256),
        }
        ef = ExpertFeatures.from_router_dict(d)
        assert ef.channel_est.shape == (B, 256)
        assert ef.beam_pred.shape   == (B, 256)
        assert ef.signal_id.shape   == (B, 256)
        assert ef.path_loss.shape   == (B, 256)

    def test_expert_features_from_router_dict_missing_key(self):
        d = {
            "channel_estimation":    torch.randn(B, 256),
            "beam_prediction":       torch.randn(B, 256),
            # signal_identification and path_loss missing
        }
        with pytest.raises(KeyError):
            ExpertFeatures.from_router_dict(d)


# ─────────────────────────────────────────────────────────────────────────────
# 7. Pipeline Parameter Count
# ─────────────────────────────────────────────────────────────────────────────

class TestPipelineParameterCount:
    def test_count_parameters_returns_expected_keys(self, mock_pipeline):
        counts = mock_pipeline.count_parameters()
        assert "total" in counts
        assert "trainable" in counts
        assert "fusion_total" in counts
        assert "llm_total" in counts

    def test_fusion_params_all_trainable(self, mock_pipeline):
        """All ChannelAdaptiveFusion params should be trainable."""
        fusion_total = sum(p.numel() for p in mock_pipeline.fusion.parameters())
        fusion_trainable = sum(
            p.numel() for p in mock_pipeline.fusion.parameters() if p.requires_grad
        )
        assert fusion_total == fusion_trainable, (
            "All fusion module params should be trainable"
        )

    def test_lora_reduces_trainable_ratio(self, mock_pipeline):
        """With LoRA, trainable params should be << total LLM params."""
        counts = mock_pipeline.count_parameters()
        ratio = counts["trainable"] / max(counts["total"], 1)
        assert ratio < 1.0, "Not all params should be trainable"


# ─────────────────────────────────────────────────────────────────────────────
# 8. GPU Tests (skipped if CUDA unavailable)
# ─────────────────────────────────────────────────────────────────────────────

class TestGPUCompatibility:
    @pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
    def test_pipeline_runs_on_cuda(self, tiny_llama_path):
        pipeline = FusionLLMPipeline(
            model_name=tiny_llama_path,
            hidden_size=TINY_D,
            d_rf=512, d_lang=768, d_ctx=128,
            d_shared=TINY_D_SHARED,
            n_heads_fusion=4,
            use_lora=True,
            lora_rank=4, lora_alpha=8, lora_dropout=0.0,
            torch_dtype=torch.float16,
            device="cuda",
            understanding_num_heads=4,
            understanding_d_ff=TINY_D * 2,
            understanding_num_layers=1,
            router_d_head=32, router_d_hidden=64, router_top_k=2,
        )
        rf_input = RFEmbedding(
            tensor=torch.randn(B, 512),
            channel_ctx=torch.randn(B, 128),
        )
        lang_input = LangEmbedding(
            tensor=torch.randn(B, 768),
            attention_mask=torch.ones(B, SEQ_LEN, dtype=torch.long),
        )
        ids = torch.randint(0, TINY_VOCAB, (B, SEQ_LEN))
        mask = torch.ones(B, SEQ_LEN, dtype=torch.long)

        with torch.no_grad():
            feats = pipeline(
                rf_input=rf_input,
                lang_input=lang_input,
                task_instruction_ids=ids,
                attention_mask=mask,
            )
        for task, feat in feats.items():
            assert feat.is_cuda, f"Task {task} output should be on CUDA"


# ─────────────────────────────────────────────────────────────────────────────
# Runner
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
