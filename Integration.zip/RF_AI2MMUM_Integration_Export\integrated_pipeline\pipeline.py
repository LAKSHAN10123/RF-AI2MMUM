"""
pipeline.py — Unified Fusion + LLM Backbone Pipeline
======================================================
RF-AI2MMUM Project — Member C + Member D Integration

FusionLLMPipeline integrates:
  1. Member C's ChannelAdaptiveFusion:
       (RFEmbedding, LangEmbedding) → FusedEmbedding(z_fused: [B, 4096])

  2. PipelineAdapter:
       FusedEmbedding → z_fused tensor (with dtype/device correction)

  3. Member D's MemberDModule:
       (z_fused, task_instruction_ids) → expert_features dict

Output:
  Dict{
    "beam_prediction":       Tensor(B, 256),
    "channel_estimation":    Tensor(B, 256),
    "signal_identification": Tensor(B, 256),
    "path_loss":             Tensor(B, 256),
  }

Which can be converted to ExpertFeatures via ExpertFeatures.from_router_dict().

Usage
-----
  # Option A: Provide a real HuggingFace model
  pipeline = FusionLLMPipeline.from_config(
      "integrated_pipeline/configs/integration_config.yaml",
      model_name="mistralai/Mistral-7B-v0.1",
  )

  # Option B: Use a tiny mock model for testing (no download needed)
  pipeline = FusionLLMPipeline.build_mock_pipeline()

  # Forward pass
  expert_features = pipeline(
      rf_input=RFEmbedding(tensor=rf_tensor, channel_ctx=ctx_tensor),
      lang_input=LangEmbedding(tensor=lang_tensor, attention_mask=mask),
      task_instruction_ids=token_ids,
  )
"""

from __future__ import annotations

import logging
import os
import sys
import tempfile
from pathlib import Path
from typing import Dict, Optional

import torch
import torch.nn as nn
import yaml

# Ensure the integrated_pipeline package root is on sys.path so all
# sub-packages (fusion_module_pkg, llm_module, interfaces) can be found.
_PKG_ROOT = str(Path(__file__).resolve().parent.parent)
if _PKG_ROOT not in sys.path:
    sys.path.insert(0, _PKG_ROOT)

from interfaces.io_contracts import (
    RFEmbedding,
    LangEmbedding,
    FusedEmbedding,
    ExpertFeatures,
)
from fusion_module_pkg.fusion.channel_adaptive_fusion import ChannelAdaptiveFusion
from llm_module.member_d_module import MemberDModule, MemberDModuleError
from adapter import PipelineAdapter

logger = logging.getLogger(__name__)


class FusionLLMPipelineError(Exception):
    """Raised on pipeline configuration or forward-pass errors."""


class FusionLLMPipeline(nn.Module):
    """
    End-to-end pipeline: RF+Language → Fusion → LLM Backbone → Expert Features.

    Parameters
    ----------
    model_name : str
        HuggingFace model identifier for the LLM backbone. Must be a valid
        model path/identifier that AutoModel can load.
    hidden_size : int, default 4096
        LLM hidden dimensionality (d_llm). Must match fusion d_llm.
    d_rf : int, default 512
        RF embedding dimension (Member A output).
    d_lang : int, default 768
        Language embedding dimension (Member B output).
    d_ctx : int, default 128
        Channel context dimension.
    d_shared : int, default 256
        Shared projection dimension in the fusion module.
    n_heads_fusion : int, default 8
        Cross-attention heads in the fusion module.
    fusion_dropout : float, default 0.1
        Dropout in the fusion module.
    use_prefix_tuning : bool, default False
        Whether to prepend learnable prefix tokens to z_fused before the
        LLM backbone. Adds PrefixTuning from Member C.
    num_prefix_tokens : int, default 10
        Number of prefix tokens. Only used if use_prefix_tuning=True.
    use_lora : bool, default True
        Whether to apply LoRA to the backbone.
    lora_rank : int, default 16
        LoRA rank.
    lora_alpha : int, default 32
        LoRA alpha.
    lora_dropout : float, default 0.05
        LoRA dropout.
    load_in_4bit : bool, default False
        Whether to load backbone with 4-bit quantisation.
    torch_dtype : torch.dtype, default torch.float32
        Backbone weight dtype. Use torch.float16 to save GPU memory.
    device : Optional[str], default None
        Target device. Auto-detected if None.
    understanding_num_heads : int, default 8
        Attention heads in MultiModalUnderstanding block.
    understanding_d_ff : int, default 8192
        FFN hidden size in MultiModalUnderstanding.
    understanding_num_layers : int, default 2
        Number of transformer layers in MultiModalUnderstanding.
    router_d_head : int, default 256
        Expert output dimension (matches ExpertFeatures field shapes).
    router_d_hidden : int, default 1024
        Hidden dim in gating/expert networks.
    router_top_k : int, default 2
        Top-k sparsification in ExpertRouter.
    """

    def __init__(
        self,
        model_name: str,
        hidden_size: int = 4096,
        d_rf: int = 512,
        d_lang: int = 768,
        d_ctx: int = 128,
        d_shared: int = 256,
        n_heads_fusion: int = 8,
        fusion_dropout: float = 0.1,
        use_prefix_tuning: bool = False,
        num_prefix_tokens: int = 10,
        use_lora: bool = True,
        lora_rank: int = 16,
        lora_alpha: int = 32,
        lora_dropout: float = 0.05,
        load_in_4bit: bool = False,
        torch_dtype: torch.dtype = torch.float32,
        device: Optional[str] = None,
        understanding_num_heads: int = 8,
        understanding_d_ff: int = 8192,
        understanding_num_layers: int = 2,
        understanding_dropout: float = 0.1,
        router_d_head: int = 256,
        router_d_hidden: int = 1024,
        router_top_k: int = 2,
        router_dropout: float = 0.1,
    ) -> None:
        super().__init__()

        self._device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self._torch_dtype = torch_dtype

        logger.info("Initializing FusionLLMPipeline on device='%s'", self._device)

        # ── Step 1: Member C — Channel Adaptive Fusion ────────────────────
        logger.info("[Member C] Initializing ChannelAdaptiveFusion...")
        try:
            self.fusion = ChannelAdaptiveFusion(
                d_rf=d_rf,
                d_lang=d_lang,
                d_ctx=d_ctx,
                d_shared=d_shared,
                d_llm=hidden_size,
                n_heads=n_heads_fusion,
                dropout=fusion_dropout,
            )
            # Fusion runs in float32 on device (dtype conversion done by adapter)
            self.fusion.to(device=self._device)
        except Exception as exc:
            raise FusionLLMPipelineError(
                f"Failed to initialize ChannelAdaptiveFusion: {exc}"
            ) from exc
        logger.info("[Member C] ChannelAdaptiveFusion ready. Output: (B, %d)", hidden_size)

        # ── Step 2: PipelineAdapter ────────────────────────────────────────
        # Adapter bridges float32 fusion output to backbone's compute dtype.
        logger.info("[Adapter] Initializing PipelineAdapter...")
        self.adapter = PipelineAdapter(
            d_llm=hidden_size,
            target_dtype=torch_dtype,
            target_device=self._device,
            use_prefix_tuning=use_prefix_tuning,
            num_prefix_tokens=num_prefix_tokens,
        )

        # ── Step 3: Member D — LLM Backbone + Understanding + Router ──────
        logger.info("[Member D] Initializing MemberDModule (model_name=%s)...", model_name)
        try:
            self.llm_module = MemberDModule(
                model_name=model_name,
                hidden_size=hidden_size,
                use_lora=use_lora,
                lora_rank=lora_rank,
                lora_alpha=lora_alpha,
                lora_dropout=lora_dropout,
                load_in_4bit=load_in_4bit,
                torch_dtype=torch_dtype,
                device=device,
                understanding_num_heads=understanding_num_heads,
                understanding_d_ff=understanding_d_ff,
                understanding_num_layers=understanding_num_layers,
                understanding_dropout=understanding_dropout,
                router_d_head=router_d_head,
                router_d_hidden=router_d_hidden,
                router_top_k=router_top_k,
                router_dropout=router_dropout,
            )
        except MemberDModuleError as exc:
            raise FusionLLMPipelineError(
                f"Failed to initialize MemberDModule: {exc}"
            ) from exc
        except Exception as exc:
            raise FusionLLMPipelineError(
                f"Unexpected error initializing MemberDModule: {exc}"
            ) from exc

        # Sync adapter's target device/dtype with actual backbone device
        actual_device = self.llm_module.device
        try:
            actual_dtype = next(self.llm_module.backbone.model.parameters()).dtype
        except StopIteration:
            actual_dtype = torch_dtype
        self.adapter.update_target(device=actual_device, dtype=actual_dtype)

        logger.info(
            "[Member D] MemberDModule ready. Backbone device=%s, dtype=%s",
            actual_device,
            actual_dtype,
        )
        logger.info("FusionLLMPipeline fully initialized.")

    # ─────────────────────────────────────────────────────────────────────────
    # Factory methods
    # ─────────────────────────────────────────────────────────────────────────

    @classmethod
    def from_config(
        cls,
        config_path: str,
        model_name: Optional[str] = None,
    ) -> "FusionLLMPipeline":
        """
        Build pipeline from integration_config.yaml.

        Parameters
        ----------
        config_path : str
            Path to integration_config.yaml.
        model_name : Optional[str]
            Override the model_name in the config.
        """
        with open(config_path) as f:
            cfg = yaml.safe_load(f)

        fc = cfg["fusion"]
        dc = cfg["backbone"]
        lc = cfg["lora"]
        uc = cfg["understanding"]
        rc = cfg["router"]
        rt = cfg["runtime"]

        dtype_map = {
            "float32": torch.float32,
            "float16": torch.float16,
            "bfloat16": torch.bfloat16,
        }
        torch_dtype = dtype_map.get(dc.get("dtype", "float32"), torch.float32)

        return cls(
            model_name=model_name or dc["model_name"],
            hidden_size=dc["hidden_size"],
            d_rf=fc.get("d_rf", 512),
            d_lang=fc.get("d_lang", 768),
            d_ctx=fc.get("d_ctx", 128),
            d_shared=fc.get("d_shared", 256),
            n_heads_fusion=fc.get("n_heads", 8),
            fusion_dropout=fc.get("dropout", 0.1),
            use_prefix_tuning=fc.get("use_prefix_tuning", False),
            num_prefix_tokens=fc.get("num_prefix_tokens", 10),
            use_lora=lc["enabled"],
            lora_rank=lc["rank"],
            lora_alpha=lc["alpha"],
            lora_dropout=lc["dropout"],
            load_in_4bit=dc.get("load_in_4bit", False),
            torch_dtype=torch_dtype,
            device=rt.get("device", None),
            understanding_num_heads=uc["num_heads"],
            understanding_d_ff=uc["d_ff"],
            understanding_num_layers=uc["num_layers"],
            understanding_dropout=uc.get("dropout", 0.1),
            router_d_head=rc["d_head"],
            router_d_hidden=rc["d_hidden"],
            router_top_k=rc["top_k"],
            router_dropout=rc.get("dropout", 0.1),
        )

    @classmethod
    def build_mock_pipeline(
        cls,
        tiny_hidden_size: int = 64,
        d_rf: int = 512,
        d_lang: int = 768,
        d_ctx: int = 128,
    ) -> "FusionLLMPipeline":
        """
        Build a pipeline using a tiny randomly-initialized LLaMA model.

        This factory method requires NO model download and is suitable for
        integration testing and CI. It creates a tiny 2-layer LLaMA model
        with hidden_size=tiny_hidden_size in a temporary directory and
        loads it via LLMBackbone.

        Parameters
        ----------
        tiny_hidden_size : int, default 64
            Hidden dimension of the mock LLaMA model.
        d_rf : int
            RF embedding dim (used in ChannelAdaptiveFusion; the up-projection
            maps to tiny_hidden_size instead of 4096).
        d_lang : int
            Language embedding dim.
        d_ctx : int
            Channel context dim.

        Returns
        -------
        FusionLLMPipeline
            Fully initialized pipeline using mock model weights.
        """
        from transformers import LlamaConfig, LlamaModel

        logger.info("Building mock pipeline with tiny_hidden_size=%d", tiny_hidden_size)

        # Create tiny LLaMA model
        config = LlamaConfig(
            vocab_size=100,
            hidden_size=tiny_hidden_size,
            intermediate_size=tiny_hidden_size * 2,
            num_hidden_layers=2,
            num_attention_heads=4,
            num_key_value_heads=4,
            max_position_embeddings=128,
        )
        model = LlamaModel(config)
        tmp_dir = tempfile.mkdtemp(prefix="mock_pipeline_llama_")
        model.save_pretrained(tmp_dir)
        config.save_pretrained(tmp_dir)

        logger.info("Mock LLaMA model saved to: %s", tmp_dir)

        return cls(
            model_name=tmp_dir,
            hidden_size=tiny_hidden_size,
            d_rf=d_rf,
            d_lang=d_lang,
            d_ctx=d_ctx,
            d_shared=min(64, tiny_hidden_size),
            n_heads_fusion=4,
            fusion_dropout=0.0,
            use_prefix_tuning=False,
            use_lora=True,
            lora_rank=4,
            lora_alpha=8,
            lora_dropout=0.0,
            load_in_4bit=False,
            torch_dtype=torch.float32,
            device="cpu",
            understanding_num_heads=4,
            understanding_d_ff=tiny_hidden_size * 2,
            understanding_num_layers=1,
            understanding_dropout=0.0,
            router_d_head=32,
            router_d_hidden=64,
            router_top_k=2,
            router_dropout=0.0,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Forward pass
    # ─────────────────────────────────────────────────────────────────────────

    def forward(
        self,
        rf_input: RFEmbedding,
        lang_input: LangEmbedding,
        task_instruction_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        return_intermediate: bool = False,
    ) -> Dict[str, torch.Tensor]:
        """
        Full end-to-end pipeline forward pass.

        Parameters
        ----------
        rf_input : RFEmbedding
            RF signal embedding from Member A.
              .tensor:      (B, 512)
              .channel_ctx: (B, 128)
        lang_input : LangEmbedding
            Language embedding from Member B.
              .tensor:      (B, 768)
              .attention_mask: (B, seq_len)
        task_instruction_ids : torch.Tensor
            Tokenized task instruction ids of shape (B, seq_len).
            Must be on CPU or the backbone device.
        attention_mask : Optional[torch.Tensor]
            Attention mask for task_instruction_ids (B, seq_len).
            If None, defaults to all-ones (all tokens valid).
        return_intermediate : bool, default False
            If True, return a tuple (expert_features, intermediates) where
            intermediates = {"z_fused": Tensor, "z_adapted": Tensor}.

        Returns
        -------
        Dict[str, torch.Tensor]
            expert_features with keys:
              "beam_prediction":       (B, d_head)
              "channel_estimation":    (B, d_head)
              "signal_identification": (B, d_head)
              "path_loss":             (B, d_head)

        Raises
        ------
        FusionLLMPipelineError
            On shape mismatches, NaN values, or any sub-module failure.
        """
        # ── Stage 1: Member C Fusion ──────────────────────────────────────
        try:
            fused_embedding: FusedEmbedding = self.fusion(rf_input, lang_input)
        except Exception as exc:
            raise FusionLLMPipelineError(
                f"[Member C] ChannelAdaptiveFusion forward failed: {exc}"
            ) from exc

        logger.debug(
            "[Stage 1] z_fused: shape=%s, dtype=%s",
            tuple(fused_embedding.z_fused.shape),
            fused_embedding.z_fused.dtype,
        )

        # ── Stage 2: Adapter (dtype + device correction) ─────────────────
        try:
            z_adapted = self.adapter(fused_embedding)
        except Exception as exc:
            raise FusionLLMPipelineError(
                f"[Adapter] PipelineAdapter forward failed: {exc}"
            ) from exc

        logger.debug(
            "[Stage 2] z_adapted: shape=%s, dtype=%s, device=%s",
            tuple(z_adapted.shape),
            z_adapted.dtype,
            z_adapted.device,
        )

        # ── Stage 3: Member D — LLM Backbone + Understanding + Router ──────
        try:
            expert_features: Dict[str, torch.Tensor] = self.llm_module(
                z_fused=z_adapted,
                task_instruction_ids=task_instruction_ids,
                attention_mask=attention_mask,
            )
        except MemberDModuleError as exc:
            raise FusionLLMPipelineError(
                f"[Member D] MemberDModule forward failed: {exc}"
            ) from exc
        except Exception as exc:
            raise FusionLLMPipelineError(
                f"[Member D] Unexpected error in MemberDModule forward: {exc}"
            ) from exc

        logger.debug(
            "[Stage 3] expert_features: %s",
            {k: tuple(v.shape) for k, v in expert_features.items()},
        )

        if return_intermediate:
            return expert_features, {
                "z_fused": fused_embedding.z_fused,
                "z_adapted": z_adapted,
            }

        return expert_features

    def get_expert_features_dataclass(
        self,
        rf_input: RFEmbedding,
        lang_input: LangEmbedding,
        task_instruction_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> ExpertFeatures:
        """
        Convenience wrapper: returns ExpertFeatures dataclass instead of a dict.

        This is the format consumed by Member E's task heads.
        """
        expert_dict = self.forward(
            rf_input=rf_input,
            lang_input=lang_input,
            task_instruction_ids=task_instruction_ids,
            attention_mask=attention_mask,
        )
        return ExpertFeatures.from_router_dict(expert_dict)

    # ─────────────────────────────────────────────────────────────────────────
    # Utility methods
    # ─────────────────────────────────────────────────────────────────────────

    def count_parameters(self) -> Dict[str, int]:
        """Count total and trainable parameters across the full pipeline."""
        total_all = sum(p.numel() for p in self.parameters())
        trainable_all = sum(p.numel() for p in self.parameters() if p.requires_grad)

        fusion_total = sum(p.numel() for p in self.fusion.parameters())
        llm_total = sum(p.numel() for p in self.llm_module.parameters())
        llm_trainable = sum(
            p.numel() for p in self.llm_module.parameters() if p.requires_grad
        )

        return {
            "total": total_all,
            "trainable": trainable_all,
            "fusion_total": fusion_total,
            "llm_total": llm_total,
            "llm_trainable": llm_trainable,
        }

    def print_summary(self) -> None:
        """Print a human-readable summary of the pipeline."""
        counts = self.count_parameters()
        print("=" * 60)
        print("FusionLLMPipeline Summary")
        print("=" * 60)
        print(f"  Member C (ChannelAdaptiveFusion)")
        print(f"    Parameters:   {counts['fusion_total']:,}")
        print(f"  Adapter (PipelineAdapter)")
        print(f"    PrefixTuning: {self.adapter.use_prefix_tuning}")
        print(f"  Member D (MemberDModule)")
        print(f"    Total:        {counts['llm_total']:,}")
        print(f"    Trainable:    {counts['llm_trainable']:,}")
        print(f"  Pipeline Totals")
        print(f"    All params:   {counts['total']:,}")
        print(f"    Trainable:    {counts['trainable']:,}")
        print("=" * 60)


# ─────────────────────────────────────────────────────────────────────────────
# Demo / smoke test (run directly)
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys as _sys
    # Fix Windows cp1252 encoding — allow Unicode output in terminal
    if hasattr(_sys.stdout, 'reconfigure'):
        _sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    import logging

    logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")

    print("\n" + "=" * 60)
    print("FusionLLMPipeline - Demo Run (Mock Backbone)")
    print("=" * 60)

    B, SEQ_LEN = 2, 8

    # Build mock pipeline (no download needed)
    pipeline = FusionLLMPipeline.build_mock_pipeline(tiny_hidden_size=64)
    pipeline.eval()
    pipeline.print_summary()

    # Create mock inputs
    rf_input = RFEmbedding(
        tensor=torch.randn(B, 512),
        channel_ctx=torch.randn(B, 128),
    )
    lang_input = LangEmbedding(
        tensor=torch.randn(B, 768),
        attention_mask=torch.ones(B, SEQ_LEN, dtype=torch.long),
    )
    task_instruction_ids = torch.randint(0, 100, (B, SEQ_LEN))
    attention_mask = torch.ones(B, SEQ_LEN, dtype=torch.long)

    print("\nRunning forward pass...")
    with torch.no_grad():
        expert_features, intermediates = pipeline(
            rf_input=rf_input,
            lang_input=lang_input,
            task_instruction_ids=task_instruction_ids,
            attention_mask=attention_mask,
            return_intermediate=True,
        )

    print("\n[OK] Forward pass successful!")
    print(f"   z_fused shape:    {intermediates['z_fused'].shape}")
    print(f"   z_adapted shape:  {intermediates['z_adapted'].shape}")
    print("\nExpert Feature Shapes:")
    for task, feat in expert_features.items():
        nan_count = torch.isnan(feat).sum().item()
        print(f"   {task}: {tuple(feat.shape)}  NaN={nan_count}")

    # Verify ExpertFeatures dataclass
    ef = ExpertFeatures.from_router_dict(expert_features)
    print("\nExpertFeatures dataclass:")
    print(f"   channel_est:  {ef.channel_est.shape}")
    print(f"   beam_pred:    {ef.beam_pred.shape}")
    print(f"   signal_id:    {ef.signal_id.shape}")
    print(f"   path_loss:    {ef.path_loss.shape}")
    print("\n" + "=" * 60)
