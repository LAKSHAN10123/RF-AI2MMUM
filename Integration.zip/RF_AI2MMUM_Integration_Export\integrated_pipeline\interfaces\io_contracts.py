"""
io_contracts.py — Canonical Interface Contracts (Integration Layer)
====================================================================
RF-AI2MMUM Project — Shared I/O Dataclasses

This is the single authoritative copy of all shared interface contracts
used between Member C (Fusion), Member D (LLM Backbone), and Member E
(Task Heads). All integration code imports from here.

Tensor shapes
-------------
  RFEmbedding.tensor        : (B, 512)
  RFEmbedding.channel_ctx   : (B, 128)
  LangEmbedding.tensor      : (B, 768)
  LangEmbedding.attention_mask : (B, seq_len)
  FusedEmbedding.z_fused    : (B, 4096)
  ExpertFeatures.{task}     : (B, 256) each
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch


@dataclass
class RFEmbedding:
    """RF signal embedding produced by Member A."""
    tensor: torch.Tensor        # (B, 512)
    channel_ctx: torch.Tensor   # (B, 128) — channel context for adaptive gating


@dataclass
class LangEmbedding:
    """Language embedding produced by Member B's LanguageEmbeddingInterface."""
    tensor: torch.Tensor            # (B, 768) — pooled sentence embedding
    attention_mask: torch.Tensor    # (B, seq_len) — 1=valid, 0=padding


@dataclass
class FusedEmbedding:
    """Fused multi-modal representation produced by Member C."""
    z_fused: torch.Tensor   # (B, 4096) — ready for Member D's LLM backbone


@dataclass
class ExpertFeatures:
    """
    Per-task expert feature tensors produced by Member D's ExpertRouter.
    These are consumed by Member E's task-specific prediction heads.
    """
    channel_est: torch.Tensor   # (B, 256)
    beam_pred: torch.Tensor     # (B, 256)
    signal_id: torch.Tensor     # (B, 256)
    path_loss: torch.Tensor     # (B, 256)

    @classmethod
    def from_router_dict(cls, d: dict) -> "ExpertFeatures":
        """
        Convert Member D's router output dict into ExpertFeatures dataclass.

        Parameters
        ----------
        d : dict
            Keys: "channel_estimation", "beam_prediction",
                  "signal_identification", "path_loss"
        """
        return cls(
            channel_est=d["channel_estimation"],
            beam_pred=d["beam_prediction"],
            signal_id=d["signal_identification"],
            path_loss=d["path_loss"],
        )


@dataclass
class Predictions:
    """Final task predictions produced by Member E's task heads."""
    channel_est: torch.Tensor   # (B, Nr, Nt)
    beam_idx: torch.Tensor      # (B,)
    signal_id: torch.Tensor     # (B, C)
    path_loss: torch.Tensor     # (B, 1)
