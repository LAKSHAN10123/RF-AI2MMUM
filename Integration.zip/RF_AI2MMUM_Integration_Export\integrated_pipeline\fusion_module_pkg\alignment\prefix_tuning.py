"""
prefix_tuning.py — Member C (Integration Copy)
===============================================
Learnable prefix tokens prepended to LLM input.
Gives the frozen LLM context before reading z_fused.
Only prefix parameters are trainable — LLM stays frozen.
"""

import torch
import torch.nn as nn


class PrefixTuning(nn.Module):
    def __init__(
        self,
        num_prefix_tokens: int = 10,
        d_llm: int = 4096,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.num_prefix_tokens = num_prefix_tokens
        self.d_llm = d_llm

        # Learnable prefix embeddings — only these train
        self.prefix_embeddings = nn.Parameter(
            torch.randn(num_prefix_tokens, d_llm) * 0.02
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, z_fused: torch.Tensor) -> torch.Tensor:
        """
        z_fused: (B, d_llm=4096)
        returns: (B, num_prefix_tokens + 1, d_llm)
                 prefix tokens prepended to z_fused for LLM input
        """
        B = z_fused.size(0)

        # Expand prefix to batch: (B, num_prefix_tokens, d_llm)
        prefix = self.prefix_embeddings.unsqueeze(0).expand(B, -1, -1)
        prefix = self.dropout(prefix)

        # z_fused as sequence token: (B, 1, d_llm)
        z_seq = z_fused.unsqueeze(1)

        # Concatenate: [prefix | z_fused] -> (B, num_prefix+1, d_llm)
        out = torch.cat([prefix, z_seq], dim=1)

        return out

    def get_trainable_params(self):
        """Returns only prefix params — use this for optimizer."""
        return [self.prefix_embeddings]
