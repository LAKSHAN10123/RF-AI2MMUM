"""
helper.py

General-purpose utilities for the Member D LLM module — RF-AI2MMUM.

Provides:
  - `setup_logging`: configure consistent logging across the module.
  - `seed_everything`: reproducibility seeding for Python, NumPy, and PyTorch.
  - `get_device`: device auto-detection (cuda / mps / cpu).
  - `save_checkpoint` / `load_checkpoint`: model & optimizer state persistence.
  - `count_parameters`: total / trainable parameter counting for any module.

Author: Member D — LLM Backbone & Multi-modal Understanding Engineer
"""

from __future__ import annotations

import logging
import os
import random
from typing import Any, Dict, Optional

import numpy as np
import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


class HelperError(Exception):
    """Raised on errors within helper utilities (e.g. checkpoint I/O)."""


def setup_logging(level: int = logging.INFO) -> None:
    """
    Configure root logging format and level for the module.

    Parameters
    ----------
    level : int, default logging.INFO
        Logging verbosity level (e.g. `logging.DEBUG`, `logging.INFO`).
    """
    logging.basicConfig(
        level=level,
        format="[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
        force=True,
    )
    logger.info("Logging configured at level %s.", logging.getLevelName(level))


def seed_everything(seed: int = 42) -> None:
    """
    Seed Python's `random`, NumPy, and PyTorch (CPU + all CUDA devices) for
    reproducibility.

    Parameters
    ----------
    seed : int, default 42
        The random seed value to apply across all libraries.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    logger.info("Global random seed set to %d.", seed)


def get_device(prefer: Optional[str] = None) -> torch.device:
    """
    Auto-detect the best available compute device.

    Parameters
    ----------
    prefer : Optional[str]
        If provided (e.g. "cuda", "cpu", "mps"), this device is returned
        directly without auto-detection, provided it is available.

    Returns
    -------
    torch.device
        The selected device. Preference order when `prefer` is None:
        CUDA -> MPS (Apple Silicon) -> CPU.
    """
    if prefer is not None:
        if prefer == "cuda" and not torch.cuda.is_available():
            logger.warning("CUDA requested but not available; falling back to CPU.")
            return torch.device("cpu")
        if prefer == "mps" and not (
            hasattr(torch.backends, "mps") and torch.backends.mps.is_available()
        ):
            logger.warning("MPS requested but not available; falling back to CPU.")
            return torch.device("cpu")
        return torch.device(prefer)

    if torch.cuda.is_available():
        return torch.device("cuda")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def count_parameters(model: nn.Module) -> Dict[str, int]:
    """
    Count total and trainable parameters in `model`.

    Parameters
    ----------
    model : nn.Module
        The model whose parameters should be counted.

    Returns
    -------
    Dict[str, int]
        Dictionary with keys "total" and "trainable" giving parameter
        counts.
    """
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return {"total": total, "trainable": trainable}


def save_checkpoint(
    model: nn.Module,
    filepath: str,
    optimizer: Optional[torch.optim.Optimizer] = None,
    epoch: Optional[int] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> None:
    """
    Save a model (and optionally optimizer/epoch/extra metadata) checkpoint.

    Parameters
    ----------
    model : nn.Module
        The model whose `state_dict` will be saved.
    filepath : str
        Destination file path (e.g. "checkpoints/llm_module_epoch5.pt").
    optimizer : Optional[torch.optim.Optimizer]
        If provided, the optimizer's `state_dict` is also saved.
    epoch : Optional[int]
        If provided, saved alongside the checkpoint for resuming training.
    extra : Optional[Dict[str, Any]]
        Any additional metadata to store in the checkpoint dictionary.

    Raises
    ------
    HelperError
        If the checkpoint cannot be written to disk.
    """
    checkpoint: Dict[str, Any] = {"model_state_dict": model.state_dict()}

    if optimizer is not None:
        checkpoint["optimizer_state_dict"] = optimizer.state_dict()
    if epoch is not None:
        checkpoint["epoch"] = epoch
    if extra is not None:
        checkpoint["extra"] = extra

    try:
        directory = os.path.dirname(filepath)
        if directory:
            os.makedirs(directory, exist_ok=True)
        torch.save(checkpoint, filepath)
        logger.info("Checkpoint saved to '%s'.", filepath)
    except Exception as exc:  # noqa: BLE001
        raise HelperError(f"Failed to save checkpoint to '{filepath}': {exc}") from exc


def load_checkpoint(
    model: nn.Module,
    filepath: str,
    optimizer: Optional[torch.optim.Optimizer] = None,
    map_location: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Load a model (and optionally optimizer) checkpoint from disk.

    Parameters
    ----------
    model : nn.Module
        The model into which the saved `state_dict` will be loaded
        in-place.
    filepath : str
        Path to the checkpoint file produced by `save_checkpoint`.
    optimizer : Optional[torch.optim.Optimizer]
        If provided and the checkpoint contains optimizer state, it will
        be loaded into this optimizer in-place.
    map_location : Optional[str]
        Device mapping passed to `torch.load` (e.g. "cpu", "cuda").

    Returns
    -------
    Dict[str, Any]
        The full checkpoint dictionary (including "epoch" and "extra"
        keys if present), useful for resuming training.

    Raises
    ------
    HelperError
        If the checkpoint file does not exist or cannot be loaded.
    """
    if not os.path.isfile(filepath):
        raise HelperError(f"Checkpoint file '{filepath}' does not exist.")

    try:
        checkpoint = torch.load(filepath, map_location=map_location)
    except Exception as exc:  # noqa: BLE001
        raise HelperError(f"Failed to load checkpoint from '{filepath}': {exc}") from exc

    if "model_state_dict" not in checkpoint:
        raise HelperError(
            f"Checkpoint '{filepath}' does not contain a 'model_state_dict' key."
        )

    try:
        model.load_state_dict(checkpoint["model_state_dict"])
    except Exception as exc:  # noqa: BLE001
        raise HelperError(f"Failed to load model state_dict: {exc}") from exc

    if optimizer is not None and "optimizer_state_dict" in checkpoint:
        try:
            optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        except Exception as exc:  # noqa: BLE001
            raise HelperError(f"Failed to load optimizer state_dict: {exc}") from exc

    logger.info("Checkpoint loaded from '%s'.", filepath)
    return checkpoint
