"""
test_backbone.py

Pytest test suite for Member D's LLM module — RF-AI2MMUM.

Covers:
  - Model loading (LLMBackbone) — using a tiny mock-config model to avoid
    downloading multi-GB weights during CI.
  - LoRA application via LoRAConfigManager.
  - Forward pass shape validation for LLMBackbone, MultiModalUnderstanding,
    ExpertRouter, and the unified MemberDModule.
  - Mock tensor inputs matching the io_contracts interface
    (z_fused: (B, 4096), task_instruction_ids: (B, seq_len)).
  - GPU compatibility (skipped automatically if CUDA unavailable).
  - Exception handling for invalid inputs/configurations.

Notes
-----
Downloading a real 7B model in CI is impractical. These tests therefore
construct a tiny LLaMA-architecture model from a randomly initialized
`AutoModel.from_config(...)` using a small `LlamaConfig`, saved to a
temporary directory, and loaded via `LLMBackbone` using that local path.
This exercises the exact same code path as loading a real model while
keeping tests fast and CI-friendly.
"""

from __future__ import annotations

import os
import tempfile

import pytest
import torch

from transformers import LlamaConfig, LlamaModel

from llm_module.backbone.llm_backbone import LLMBackbone, LLMBackboneError
from llm_module.backbone.lora_config import LoRAConfigManager, LoRAConfigError
from llm_module.understanding.multimodal_understanding import (
    MultiModalUnderstanding,
    MultiModalUnderstandingError,
)
from llm_module.routing.expert_router import (
    ExpertRouter,
    ExpertRouterError,
    TASK_NAMES,
)
from llm_module.member_d_module import MemberDModule, MemberDModuleError


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

TINY_HIDDEN_SIZE = 64
TINY_NUM_LAYERS = 2
TINY_NUM_HEADS = 4
TINY_INTERMEDIATE_SIZE = 128
TINY_VOCAB_SIZE = 100


@pytest.fixture(scope="module")
def tiny_model_path() -> str:
    """
    Create a tiny randomly-initialized LLaMA model and save it to a
    temporary directory, returning the path for use with
    `AutoModel.from_pretrained` / `AutoConfig.from_pretrained`.
    """
    config = LlamaConfig(
        vocab_size=TINY_VOCAB_SIZE,
        hidden_size=TINY_HIDDEN_SIZE,
        intermediate_size=TINY_INTERMEDIATE_SIZE,
        num_hidden_layers=TINY_NUM_LAYERS,
        num_attention_heads=TINY_NUM_HEADS,
        num_key_value_heads=TINY_NUM_HEADS,
        max_position_embeddings=128,
    )
    model = LlamaModel(config)

    tmp_dir = tempfile.mkdtemp(prefix="tiny_llama_")
    model.save_pretrained(tmp_dir)
    config.save_pretrained(tmp_dir)
    return tmp_dir


@pytest.fixture(scope="module")
def tiny_backbone(tiny_model_path: str) -> LLMBackbone:
    """Instantiate an `LLMBackbone` wrapping the tiny LLaMA model with LoRA."""
    return LLMBackbone(
        model_name=tiny_model_path,
        hidden_size=TINY_HIDDEN_SIZE,
        use_lora=True,
        lora_rank=4,
        lora_alpha=8,
        lora_dropout=0.0,
        load_in_4bit=False,
        torch_dtype=torch.float32,
        device="cpu",
        use_causal_lm=False,
        trust_remote_code=False,
    )


@pytest.fixture(scope="module")
def tiny_backbone_no_lora(tiny_model_path: str) -> LLMBackbone:
    """Instantiate an `LLMBackbone` without LoRA for comparison tests."""
    return LLMBackbone(
        model_name=tiny_model_path,
        hidden_size=TINY_HIDDEN_SIZE,
        use_lora=False,
        device="cpu",
    )


@pytest.fixture()
def mock_z_fused() -> torch.Tensor:
    """Mock fused embedding tensor of shape (B, d_llm)."""
    batch_size = 2
    return torch.randn(batch_size, TINY_HIDDEN_SIZE)


@pytest.fixture()
def mock_task_instruction_ids() -> torch.Tensor:
    """Mock tokenized instruction ids of shape (B, seq_len)."""
    batch_size = 2
    seq_len = 6
    return torch.randint(0, TINY_VOCAB_SIZE, (batch_size, seq_len))


@pytest.fixture()
def mock_attention_mask() -> torch.Tensor:
    """Mock attention mask of shape (B, seq_len), all valid tokens."""
    batch_size = 2
    seq_len = 6
    return torch.ones(batch_size, seq_len, dtype=torch.long)


# ---------------------------------------------------------------------------
# Model loading tests
# ---------------------------------------------------------------------------

class TestModelLoading:
    def test_backbone_loads_successfully(self, tiny_backbone: LLMBackbone) -> None:
        """Backbone should load and report the correct device."""
        assert tiny_backbone.model is not None
        assert tiny_backbone.device == "cpu"

    def test_backbone_invalid_model_name_raises(self) -> None:
        """An invalid/non-existent model identifier should raise LLMBackboneError."""
        with pytest.raises(LLMBackboneError):
            LLMBackbone(
                model_name="this/model-definitely-does-not-exist-12345",
                hidden_size=TINY_HIDDEN_SIZE,
                use_lora=False,
                device="cpu",
            )

    def test_backbone_freezes_base_parameters(self, tiny_backbone_no_lora: LLMBackbone) -> None:
        """All base model parameters should have requires_grad=False when LoRA is disabled."""
        for param in tiny_backbone_no_lora.model.parameters():
            assert param.requires_grad is False


# ---------------------------------------------------------------------------
# LoRA tests
# ---------------------------------------------------------------------------

class TestLoRA:
    def test_lora_applied_creates_trainable_params(self, tiny_backbone: LLMBackbone) -> None:
        """With LoRA enabled, some parameters should be trainable."""
        counts = tiny_backbone.count_trainable_parameters()
        assert counts["trainable"] > 0
        assert counts["trainable"] < counts["total"]

    def test_no_lora_has_zero_trainable_params(self, tiny_backbone_no_lora: LLMBackbone) -> None:
        """Without LoRA, zero parameters should be trainable (fully frozen)."""
        counts = tiny_backbone_no_lora.count_trainable_parameters()
        assert counts["trainable"] == 0

    def test_lora_config_manager_invalid_rank_raises(self) -> None:
        """A non-positive LoRA rank should raise LoRAConfigError."""
        with pytest.raises(LoRAConfigError):
            LoRAConfigManager(rank=0, alpha=8, dropout=0.0, model_type="llama")

    def test_lora_config_manager_invalid_dropout_raises(self) -> None:
        """An out-of-range dropout value should raise LoRAConfigError."""
        with pytest.raises(LoRAConfigError):
            LoRAConfigManager(rank=4, alpha=8, dropout=1.5, model_type="llama")

    def test_lora_save_and_load_adapter(self, tiny_backbone: LLMBackbone) -> None:
        """LoRA adapter weights should be saveable and loadable via LoRAConfigManager."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            adapter_dir = os.path.join(tmp_dir, "adapter")
            LoRAConfigManager.save_adapter(tiny_backbone.model, adapter_dir)
            assert os.path.isdir(adapter_dir)
            assert len(os.listdir(adapter_dir)) > 0


# ---------------------------------------------------------------------------
# Forward pass / shape validation tests
# ---------------------------------------------------------------------------

class TestBackboneForward:
    def test_forward_pass_shape(
        self,
        tiny_backbone: LLMBackbone,
        mock_z_fused: torch.Tensor,
        mock_task_instruction_ids: torch.Tensor,
        mock_attention_mask: torch.Tensor,
    ) -> None:
        """Forward pass should return hidden states of shape (B, P+seq_len, hidden_size)."""
        hidden_states = tiny_backbone(
            z_fused=mock_z_fused,
            task_instruction_ids=mock_task_instruction_ids,
            attention_mask=mock_attention_mask,
        )

        batch_size = mock_z_fused.shape[0]
        seq_len = mock_task_instruction_ids.shape[1]
        prefix_len = 1  # mock_z_fused is (B, hidden_size) -> unsqueezed to (B, 1, hidden_size)

        assert hidden_states.shape == (batch_size, prefix_len + seq_len, TINY_HIDDEN_SIZE)

    def test_forward_pass_without_attention_mask(
        self,
        tiny_backbone: LLMBackbone,
        mock_z_fused: torch.Tensor,
        mock_task_instruction_ids: torch.Tensor,
    ) -> None:
        """Forward pass should work without an explicit attention mask."""
        hidden_states = tiny_backbone(
            z_fused=mock_z_fused,
            task_instruction_ids=mock_task_instruction_ids,
            attention_mask=None,
        )
        assert hidden_states.dim() == 3
        assert hidden_states.shape[-1] == TINY_HIDDEN_SIZE

    def test_forward_pass_with_3d_z_fused(
        self,
        tiny_backbone: LLMBackbone,
        mock_task_instruction_ids: torch.Tensor,
        mock_attention_mask: torch.Tensor,
    ) -> None:
        """Forward pass should accept z_fused with an explicit prefix dimension (B, P, d_llm)."""
        batch_size = 2
        prefix_len = 3
        z_fused_3d = torch.randn(batch_size, prefix_len, TINY_HIDDEN_SIZE)

        hidden_states = tiny_backbone(
            z_fused=z_fused_3d,
            task_instruction_ids=mock_task_instruction_ids,
            attention_mask=mock_attention_mask,
        )

        seq_len = mock_task_instruction_ids.shape[1]
        assert hidden_states.shape == (batch_size, prefix_len + seq_len, TINY_HIDDEN_SIZE)

    def test_forward_pass_invalid_z_fused_dim_raises(
        self,
        tiny_backbone: LLMBackbone,
        mock_task_instruction_ids: torch.Tensor,
    ) -> None:
        """A z_fused tensor with an invalid number of dimensions should raise LLMBackboneError."""
        invalid_z_fused = torch.randn(2, 3, 4, TINY_HIDDEN_SIZE)  # 4D - invalid
        with pytest.raises(LLMBackboneError):
            tiny_backbone(
                z_fused=invalid_z_fused,
                task_instruction_ids=mock_task_instruction_ids,
            )

    def test_forward_pass_batch_size_mismatch_raises(
        self,
        tiny_backbone: LLMBackbone,
        mock_z_fused: torch.Tensor,
    ) -> None:
        """A batch size mismatch between z_fused and task_instruction_ids should raise."""
        mismatched_ids = torch.randint(0, TINY_VOCAB_SIZE, (3, 6))  # batch size 3 vs 2
        with pytest.raises(LLMBackboneError):
            tiny_backbone(
                z_fused=mock_z_fused,
                task_instruction_ids=mismatched_ids,
            )


# ---------------------------------------------------------------------------
# MultiModalUnderstanding tests
# ---------------------------------------------------------------------------

class TestMultiModalUnderstanding:
    def test_understanding_output_shape(self) -> None:
        """Understanding block should pool (B, L, d_model) -> (B, d_model)."""
        d_model = TINY_HIDDEN_SIZE
        understanding = MultiModalUnderstanding(
            d_model=d_model, num_heads=4, d_ff=128, num_layers=2, dropout=0.0
        )
        hidden_states = torch.randn(2, 7, d_model)
        output = understanding(hidden_states)
        assert output.shape == (2, d_model)

    def test_understanding_with_attention_mask(self) -> None:
        """Understanding block should support masked mean pooling."""
        d_model = TINY_HIDDEN_SIZE
        understanding = MultiModalUnderstanding(d_model=d_model, num_heads=4, d_ff=128, num_layers=1)
        hidden_states = torch.randn(2, 5, d_model)
        attention_mask = torch.tensor([[1, 1, 1, 0, 0], [1, 1, 1, 1, 1]])
        output = understanding(hidden_states, attention_mask)
        assert output.shape == (2, d_model)

    def test_understanding_invalid_dim_raises(self) -> None:
        """A 2D hidden_states tensor should raise MultiModalUnderstandingError."""
        understanding = MultiModalUnderstanding(d_model=TINY_HIDDEN_SIZE, num_heads=4, d_ff=128)
        invalid_input = torch.randn(2, TINY_HIDDEN_SIZE)  # missing seq dim
        with pytest.raises(MultiModalUnderstandingError):
            understanding(invalid_input)

    def test_understanding_invalid_num_heads_raises(self) -> None:
        """num_heads not dividing d_model should raise."""
        with pytest.raises(MultiModalUnderstandingError):
            MultiModalUnderstanding(d_model=65, num_heads=4, d_ff=128)


# ---------------------------------------------------------------------------
# ExpertRouter tests
# ---------------------------------------------------------------------------

class TestExpertRouter:
    def test_router_output_keys_and_shapes(self) -> None:
        """Router should return all four task keys with shape (B, d_head)."""
        d_model = TINY_HIDDEN_SIZE
        d_head = 32
        router = ExpertRouter(d_model=d_model, d_head=d_head, d_hidden=64, top_k=2)
        z_understood = torch.randn(3, d_model)

        expert_features = router(z_understood)

        assert set(expert_features.keys()) == set(TASK_NAMES)
        for task_name, tensor in expert_features.items():
            assert tensor.shape == (3, d_head), f"Mismatch for task {task_name}"

    def test_router_top_k_sparsification(self) -> None:
        """With top_k < num_experts, some experts should receive zero gate weight."""
        d_model = TINY_HIDDEN_SIZE
        router = ExpertRouter(d_model=d_model, d_head=16, d_hidden=32, top_k=1)
        z_understood = torch.randn(4, d_model)

        gates = router._compute_gates(z_understood)  # (B, num_experts)
        nonzero_per_row = (gates > 0).sum(dim=-1)
        assert torch.all(nonzero_per_row == 1)

    def test_router_invalid_top_k_raises(self) -> None:
        """top_k outside [1, num_experts] should raise ExpertRouterError."""
        with pytest.raises(ExpertRouterError):
            ExpertRouter(d_model=TINY_HIDDEN_SIZE, d_head=16, d_hidden=32, top_k=10)

    def test_router_invalid_input_dim_raises(self) -> None:
        """A 3D input to the router should raise ExpertRouterError."""
        router = ExpertRouter(d_model=TINY_HIDDEN_SIZE, d_head=16, d_hidden=32, top_k=2)
        invalid_input = torch.randn(2, 5, TINY_HIDDEN_SIZE)
        with pytest.raises(ExpertRouterError):
            router(invalid_input)


# ---------------------------------------------------------------------------
# Unified MemberDModule tests
# ---------------------------------------------------------------------------

class TestMemberDModule:
    @pytest.fixture(scope="class")
    def member_d_module(self, tiny_model_path: str) -> MemberDModule:
        return MemberDModule(
            model_name=tiny_model_path,
            hidden_size=TINY_HIDDEN_SIZE,
            use_lora=True,
            lora_rank=4,
            lora_alpha=8,
            lora_dropout=0.0,
            load_in_4bit=False,
            torch_dtype=torch.float32,
            device="cpu",
            understanding_num_heads=4,
            understanding_d_ff=128,
            understanding_num_layers=1,
            understanding_dropout=0.0,
            router_d_head=32,
            router_d_hidden=64,
            router_top_k=2,
            router_dropout=0.0,
        )

    def test_unified_forward_returns_expected_keys(
        self,
        member_d_module: MemberDModule,
        mock_z_fused: torch.Tensor,
        mock_task_instruction_ids: torch.Tensor,
        mock_attention_mask: torch.Tensor,
    ) -> None:
        """forward(z_fused, task_instruction_ids) should return expert_features dict."""
        expert_features = member_d_module(
            z_fused=mock_z_fused,
            task_instruction_ids=mock_task_instruction_ids,
            attention_mask=mock_attention_mask,
        )

        assert set(expert_features.keys()) == set(TASK_NAMES)
        batch_size = mock_z_fused.shape[0]
        for task_name, tensor in expert_features.items():
            assert tensor.shape == (batch_size, 32), f"Mismatch for {task_name}"
            assert torch.isfinite(tensor).all(), f"Non-finite values in {task_name}"

    def test_unified_forward_without_attention_mask(
        self,
        member_d_module: MemberDModule,
        mock_z_fused: torch.Tensor,
        mock_task_instruction_ids: torch.Tensor,
    ) -> None:
        """forward should also work when attention_mask is None."""
        expert_features = member_d_module(
            z_fused=mock_z_fused,
            task_instruction_ids=mock_task_instruction_ids,
            attention_mask=None,
        )
        assert set(expert_features.keys()) == set(TASK_NAMES)

    def test_unified_forward_invalid_inputs_raise(
        self,
        member_d_module: MemberDModule,
    ) -> None:
        """Invalid input shapes should raise MemberDModuleError."""
        bad_z_fused = torch.randn(2, 3, 4, TINY_HIDDEN_SIZE)  # 4D - invalid
        ids = torch.randint(0, TINY_VOCAB_SIZE, (2, 6))
        with pytest.raises(MemberDModuleError):
            member_d_module(z_fused=bad_z_fused, task_instruction_ids=ids)


# ---------------------------------------------------------------------------
# GPU compatibility tests
# ---------------------------------------------------------------------------

class TestGPUCompatibility:
    @pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
    def test_backbone_on_cuda(self, tiny_model_path: str) -> None:
        """Backbone should load and run on CUDA when available."""
        backbone = LLMBackbone(
            model_name=tiny_model_path,
            hidden_size=TINY_HIDDEN_SIZE,
            use_lora=False,
            torch_dtype=torch.float16,
            device="cuda",
        )
        assert backbone.device == "cuda"

        z_fused = torch.randn(2, TINY_HIDDEN_SIZE)
        ids = torch.randint(0, TINY_VOCAB_SIZE, (2, 6))

        hidden_states = backbone(z_fused=z_fused, task_instruction_ids=ids)
        assert hidden_states.is_cuda

    @pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
    def test_full_module_on_cuda(self, tiny_model_path: str) -> None:
        """The unified MemberDModule should run end-to-end on CUDA."""
        module = MemberDModule(
            model_name=tiny_model_path,
            hidden_size=TINY_HIDDEN_SIZE,
            use_lora=True,
            lora_rank=4,
            lora_alpha=8,
            torch_dtype=torch.float16,
            device="cuda",
            understanding_num_heads=4,
            understanding_d_ff=128,
            understanding_num_layers=1,
            router_d_head=32,
            router_d_hidden=64,
            router_top_k=2,
        )

        z_fused = torch.randn(2, TINY_HIDDEN_SIZE)
        ids = torch.randint(0, TINY_VOCAB_SIZE, (2, 6))
        mask = torch.ones(2, 6, dtype=torch.long)

        expert_features = module(z_fused=z_fused, task_instruction_ids=ids, attention_mask=mask)
        for tensor in expert_features.values():
            assert tensor.is_cuda


# ---------------------------------------------------------------------------
# Helper utilities tests
# ---------------------------------------------------------------------------

class TestHelpers:
    def test_seed_everything_reproducibility(self) -> None:
        """seed_everything should make torch.randn reproducible."""
        from llm_module.utils.helper import seed_everything

        seed_everything(123)
        a = torch.randn(3, 3)

        seed_everything(123)
        b = torch.randn(3, 3)

        assert torch.allclose(a, b)

    def test_get_device_cpu_fallback(self) -> None:
        """Requesting cuda when unavailable should fall back to cpu."""
        from llm_module.utils.helper import get_device

        if not torch.cuda.is_available():
            device = get_device(prefer="cuda")
            assert device.type == "cpu"

    def test_save_and_load_checkpoint(self, tiny_backbone_no_lora: LLMBackbone) -> None:
        """save_checkpoint / load_checkpoint should round-trip a model state_dict."""
        from llm_module.utils.helper import save_checkpoint, load_checkpoint

        with tempfile.TemporaryDirectory() as tmp_dir:
            ckpt_path = os.path.join(tmp_dir, "model.pt")
            save_checkpoint(tiny_backbone_no_lora.model, ckpt_path, epoch=1)
            assert os.path.isfile(ckpt_path)

            checkpoint = load_checkpoint(tiny_backbone_no_lora.model, ckpt_path, map_location="cpu")
            assert checkpoint["epoch"] == 1

    def test_count_parameters(self, tiny_backbone_no_lora: LLMBackbone) -> None:
        """count_parameters should return total >= trainable >= 0."""
        from llm_module.utils.helper import count_parameters

        counts = count_parameters(tiny_backbone_no_lora.model)
        assert counts["total"] >= counts["trainable"] >= 0
